HuntSMP Crimson Blade overlay pack 1.22.3

This required overlay is sent automatically by HuntSMP-1.22.3.jar after the
main HuntSMP resource pack. It contains the animated Crimson Blade, Crimson
Beam, and flying crimson fragment assets.

The sword body remains fixed in every animation frame; only detached aura
fragments rise and fall. Display transforms are tuned for an oversized relic.
