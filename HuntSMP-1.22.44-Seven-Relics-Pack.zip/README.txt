Huntsmp Pack 1.22.1 - Minecraft Java 1.21.11

Install this ZIP as a normal server resource pack or place it in the client's
resourcepacks folder. Keep the ZIP structure unchanged: pack.mcmeta must be at
the root of the ZIP.

Custom items supplied by HuntSMP:
- hunt:mysterious_shard item model
- hunt:red_tracker item model
- server-rendered red dust particles that never replace vanilla particle textures
- animated yellow-gold rift starburst overlay
- original warning swell, rift-style flash, and dropped-item sounds
- stationary glitching shard and fixed compass casing with a rotating needle
- five beveled 32x32 animated Hunt Power relics with gemstone shading and glints
- a separate animated premium Fate Reroller relic and item model
- a static high-resolution Crimson Blade with a separate 16-frame flying aura layer
- animated crimson beam and fragment models used by the Crimson relic ability
- three altar-forged Majestica relics: Creation Splitter, Demon Lord's Great Axe,
  and Ocean's Rage (see BLADES-OF-MAJESTICA-CREDITS.txt)
