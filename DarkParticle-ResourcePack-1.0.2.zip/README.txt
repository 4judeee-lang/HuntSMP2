Dark Particle Resource Pack 1.0.2
=================================

Target Minecraft version: Java Edition 1.21.11
Pack format: 75

Included:
- Animated Watcher Claymore model for the Dark Particle Netherite Sword
- Eight pristine +5 Bliss SMP gem models wired through the 1.21.11 item atlas
- Dark Particle tooltip using Minecraft 1.21.11's exact background silhouette
- Dark-violet frame using Minecraft's exact outline and nine-slice borders

The pack must be used with DarkParticle-1.0.2.jar. The plugin assigns all
custom item-model and tooltip-style components automatically.

Host this ZIP at a direct-download HTTPS URL. DarkParticle can enforce it
directly from plugins/DarkParticle/config.yml, or reuse the URL configured in
server.properties. For the cleanest setup, configure:

resource-pack=<direct-download-url>
resource-pack-sha1=<SHA-1 supplied with the release>
require-resource-pack=true

Review THIRD-PARTY-NOTICES.txt before redistributing or selling this pack.
