HuntSMP Crimson Blade overlay pack 1.22.2

This required overlay is sent automatically by HuntSMP-1.22.2.jar after the
main HuntSMP resource pack. It contains the animated Crimson Blade, Crimson
Beam, and flying crimson fragment assets.
