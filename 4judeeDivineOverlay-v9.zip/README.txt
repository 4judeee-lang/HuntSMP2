HuntSMP weapon overlay v9
- Crimson Blade: Creation Splitter
- Lightning Bolt: Ocean's Rage
- Drill Pickaxe: Talonpick
- Divine Spear: Sunbreak
Place above the complete HuntSMP base pack.
