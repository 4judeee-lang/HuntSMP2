4judee HuntSMP weapon overlay v8

Crimson Blade: Creation Splitter
Lightning Bolt: Ocean's Rage
Drill Pickaxe: Talonpick

Load this above the original full HuntSMP pack.
