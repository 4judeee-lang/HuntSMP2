HuntSMP integrated relic overlay pack 1.22.3

Mapped plugin models:
- hunt:crimson_blade -> Valhakyra
- hunt:lightning_bolt -> Phantomguard Partisan
- hunt:drill_pickaxe -> Talonpick

The original HuntSMP Crimson Beam and fragment assets are preserved.
The imported 3D geometry and display transforms are preserved from
nongko's Fantasy Weapons v1.20A.
