Hunt Mystery — The city remembers.

Unified HuntSMP + HuntMystery resource pack for Minecraft Java 1.21.11.
This single ZIP contains all normal, guardian, Watcher, Eden, restoration, and apocalypse assets.
The apocalypse sky textures are retained under the huntmystery namespace rather than replacing vanilla environment textures permanently. Runtime apocalypse atmosphere is provided by the plugin through particles, weather, lighting, overlays, sounds, and events.
