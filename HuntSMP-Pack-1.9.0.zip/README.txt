Huntsmp Pack - Minecraft Java 1.21.11

Install this ZIP as a normal server resource pack or place it in the client's
resourcepacks folder. Keep the ZIP structure unchanged: pack.mcmeta must be at
the root of the ZIP.

Custom items supplied by HuntSMP:
- hunt:mysterious_shard item model
- hunt:red_tracker item model
- dedicated sharp crimson rune particles used by the private tracking trail
- animated yellow-gold rift starburst overlay
- original warning swell, rift-style flash, and dropped-item sounds
- stationary glitching shard and fixed compass casing with a rotating needle
