# Crimson Blade 1.22.1 visual QA

Primary target: the supplied second screenshot.

- First-person right hand: 2.15 scale, right-biased translation, upward blade angle, handle aligned to the lower-right hand position.
- First-person left hand: mirrored rotation with matching scale and hand alignment.
- Third-person hands: 1.45 scale and handle-first grip; reduced from the first-person scale to avoid body clipping.
- GUI: independently reduced to 0.72 so the complete silhouette remains readable.
- Ground: 1.10 model scale; the plugin supplies controlled hover, rotation, glow, and sparse crimson particles.
- Fixed/ItemDisplay: 1.60 scale with full-bright display settings where the plugin owns the display.
- Static pixels: the connected blade, guard, handle, and pommel exist only in `crimson_blade.png`, which has no animation metadata.
- Animated pixels: all 16 frames are transparent except for detached fragments in `crimson_blade_aura.png`.
- Frame timing: two game ticks per frame, no interpolation and no full-sword movement.
- Texture integrity: 128×128 static source, 128×2048 aura atlas, alpha transparency, nearest-neighbour pixel art, no black background.
- Multiplayer cleanup: one centralized task manages dropped blades; tracked items are removed from the manager on pickup, despawn, chunk unload, plugin disable, or invalidation.

## In-game commands

```text
/hunt altar give Crimson
/hunt altar spawn Crimson
```

## Resource-pack URL

Host `HuntSMP-Pack-1.22.1.zip` at a direct HTTPS URL and place that URL plus the packaged SHA-1 in the HuntSMP resource-pack configuration.
