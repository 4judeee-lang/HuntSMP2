# HuntSMP Crimson Blade 1.22.1

Paper 1.21.11 / Java 21 expansion for HuntSMP 1.21.1.

## Features

- `Crimson Blade` custom high-resolution Netherite Sword model with a completely static blade and separate 16-frame detached aura.
- Press `F` while holding it in the main hand to fire a piercing crimson beam.
- Beam: 3.5 hearts (7 health points) of true damage.
- Bleed: 0.5 heart (1 health point) of true damage once per second for 3 seconds.
- HuntSMP grace and trusted-player protection are respected.
- Every player kill made with the blade increases Sharpness by one, capped at Sharpness VII.
- Tuned first-person, left-hand, third-person, GUI, ground, fixed, and head transforms.
- Dropped blades glow, hover, rotate slowly, emit sparse crimson fragments, and restore vanilla physics on pickup, chunk unload, or plugin shutdown.
- Animated held fragments, beam ItemDisplays, impact particles, sounds, and automatic transient-display cleanup.
- Persistent Crimson altar with exact stacked ingredient consumption and global craft announcement.

## Commands

- `/hunt altar give Crimson` — give the blade directly (admin/op).
- `/hunt altar spawn Crimson` — spawn its forge altar (admin/op).
- `/hunt altar remove` — removes the looked-at Crimson altar; normal HuntSMP altars still use the original handler.

## Altar recipe

- 3 Wither Skeleton Skulls
- 1 Nether Star
- 64 Crimson Nylium
- 3 Netherite Ingots
- 32 Quartz Blocks

## Building

Use Java 21 and Maven:

```bash
mvn clean package
```

The plugin depends on the existing `HuntSMP` plugin and uses its true-damage/trust/grace pipeline.

The complete texture source, 16 unpacked animation frames, regeneration script, visual QA checklist, and Blockbench source are included in this source archive.
