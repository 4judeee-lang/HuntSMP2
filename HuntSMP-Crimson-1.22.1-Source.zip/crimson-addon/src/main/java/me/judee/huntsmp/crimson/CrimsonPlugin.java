package me.judee.huntsmp.crimson;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

/** Entry point for the Crimson Blade HuntSMP expansion. */
public final class CrimsonPlugin extends JavaPlugin {
    private CrimsonService crimsonService;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        if (Bukkit.getPluginManager().getPlugin("HuntSMP") == null) {
            getLogger().severe("HuntSMP was not found. Disabling the Crimson Blade expansion.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        crimsonService = new CrimsonService(this, new HuntBridge(this));
        Bukkit.getPluginManager().registerEvents(crimsonService, this);
        crimsonService.start();
        getLogger().info("Crimson Blade relic loaded.");
    }

    @Override
    public void onDisable() {
        if (crimsonService != null) {
            crimsonService.shutdown();
        }
    }
}
