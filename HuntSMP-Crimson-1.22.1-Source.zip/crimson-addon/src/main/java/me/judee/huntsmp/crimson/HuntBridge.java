package me.judee.huntsmp.crimson;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.bukkit.GameMode;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * Calls HuntSMP's existing true-damage pipeline so grace, cancellable damage
 * events, death attribution, and the server's combat rules remain consistent.
 */
final class HuntBridge {
    private final CrimsonPlugin plugin;
    private final Plugin huntPlugin;
    private final Method damageMethod;
    private final Method trustMethod;

    HuntBridge(CrimsonPlugin plugin) {
        this.plugin = plugin;
        this.huntPlugin = plugin.getServer().getPluginManager().getPlugin("HuntSMP");
        this.damageMethod = findMethod("dealHuntDamage", Player.class, Player.class, double.class, DamageType.class);
        this.trustMethod = findMethod("isDamageBlockedByTrust", Player.class, Player.class);
    }

    boolean damage(Player attacker, Player victim, double healthPoints) {
        if (attacker == null || victim == null || attacker.equals(victim) || victim.isDead()
                || victim.isInvulnerable() || victim.getGameMode() == GameMode.CREATIVE
                || victim.getGameMode() == GameMode.SPECTATOR || isTrusted(victim, attacker)) {
            return false;
        }

        if (huntPlugin != null && damageMethod != null) {
            try {
                return Boolean.TRUE.equals(damageMethod.invoke(huntPlugin, attacker, victim, healthPoints, DamageType.MAGIC));
            } catch (IllegalAccessException | InvocationTargetException exception) {
                plugin.getLogger().warning("HuntSMP damage bridge failed; using safe fallback: " + exception.getMessage());
            }
        }

        // This path is only a compatibility fallback. HuntSMP is a hard dependency.
        double applied = Math.min(Math.max(0.0, healthPoints), victim.getHealth());
        if (applied <= 0.0) {
            return false;
        }
        victim.setNoDamageTicks(0);
        victim.damage(0.001, attacker); // Preserve Bukkit's killer attribution.
        victim.setNoDamageTicks(0);
        victim.setHealth(Math.max(0.0, victim.getHealth() - applied));
        return true;
    }

    boolean isTrusted(Player victim, Player attacker) {
        if (huntPlugin == null || trustMethod == null) {
            return false;
        }
        try {
            return Boolean.TRUE.equals(trustMethod.invoke(huntPlugin, victim, attacker));
        } catch (IllegalAccessException | InvocationTargetException exception) {
            plugin.getLogger().warning("HuntSMP trust bridge failed: " + exception.getMessage());
            return false;
        }
    }

    private Method findMethod(String name, Class<?>... parameters) {
        if (huntPlugin == null) {
            return null;
        }
        try {
            Method method = huntPlugin.getClass().getDeclaredMethod(name, parameters);
            method.setAccessible(true);
            return method;
        } catch (NoSuchMethodException exception) {
            plugin.getLogger().severe("Unsupported HuntSMP build: missing method " + name + '.');
            return null;
        }
    }
}
