package me.judee.huntsmp.crimson;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.server.TabCompleteEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import java.time.Duration;

/** Implements the Crimson Blade item, progression, beam, bleed, and altar. */
final class CrimsonService implements Listener {
    private static final Component PREFIX = Component.text("CRIMSON ", NamedTextColor.DARK_RED)
            .decorate(TextDecoration.BOLD)
            .append(Component.text("» ", NamedTextColor.DARK_GRAY).decoration(TextDecoration.BOLD, false));
    private static final String WEAPON_ID = "crimson";
    private static final Particle.DustOptions BEAM_DUST =
            new Particle.DustOptions(Color.fromRGB(215, 12, 66), 1.35F);

    private final CrimsonPlugin plugin;
    private final HuntBridge huntBridge;
    private final NamespacedKey bladeKey;
    private final NamespacedKey legacyBladeKey;
    private final NamespacedKey sharpnessKey;
    private final NamespacedKey huntWeaponKey;
    private final NamespacedKey altarRoleKey;
    private final NamespacedKey altarGroupKey;
    private final NamespacedKey droppedBladeKey;
    private final NamespacedKey droppedOwnerKey;
    private final Set<UUID> altarRelics = new HashSet<>();
    private final Map<UUID, DroppedBlade> droppedBlades = new HashMap<>();
    private final Map<UUID, Long> lastBeamUse = new HashMap<>();
    private final Map<UUID, BukkitTask> activeBleeds = new HashMap<>();
    private final Map<UUID, HitCredit> hitCredits = new HashMap<>();
    private BukkitTask animationTask;

    CrimsonService(CrimsonPlugin plugin, HuntBridge huntBridge) {
        this.plugin = plugin;
        this.huntBridge = huntBridge;
        this.bladeKey = new NamespacedKey("huntsmp", "crimson_blade");
        this.legacyBladeKey = new NamespacedKey(plugin, "crimson_blade");
        this.sharpnessKey = new NamespacedKey(plugin, "crimson_sharpness");
        this.huntWeaponKey = new NamespacedKey("huntsmp", "altar_weapon");
        this.altarRoleKey = new NamespacedKey(plugin, "altar_role");
        this.altarGroupKey = new NamespacedKey(plugin, "altar_group");
        this.droppedBladeKey = new NamespacedKey(plugin, "crimson_dropped_blade");
        this.droppedOwnerKey = new NamespacedKey(plugin, "crimson_dropped_owner");
    }

    void start() {
        for (World world : Bukkit.getWorlds()) {
            for (ItemDisplay display : world.getEntitiesByClass(ItemDisplay.class)) {
                if ("relic".equals(display.getPersistentDataContainer().get(altarRoleKey, PersistentDataType.STRING))) {
                    altarRelics.add(display.getUniqueId());
                }
            }
            for (Item item : world.getEntitiesByClass(Item.class)) {
                if (isBlade(item.getItemStack())) {
                    trackDroppedBlade(item, null);
                }
            }
        }
        long heldPeriod = Math.max(2L, plugin.getConfig().getLong("visuals.held-fragment-period-ticks", 4L));
        animationTask = Bukkit.getScheduler().runTaskTimer(plugin, this::animate, 1L, heldPeriod);
    }

    void shutdown() {
        if (animationTask != null) {
            animationTask.cancel();
        }
        for (BukkitTask task : activeBleeds.values()) {
            task.cancel();
        }
        activeBleeds.clear();
        lastBeamUse.clear();
        hitCredits.clear();
        altarRelics.clear();
        for (UUID itemId : new ArrayList<>(droppedBlades.keySet())) {
            Entity entity = Bukkit.getEntity(itemId);
            if (entity instanceof Item item && item.isValid()) {
                item.setGravity(true);
                item.setGlowing(false);
            }
        }
        droppedBlades.clear();
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onHuntCommand(PlayerCommandPreprocessEvent event) {
        String commandLine = event.getMessage().substring(1).trim();
        if (commandLine.isEmpty()) {
            return;
        }
        String[] parts = commandLine.split("\\s+");
        String root = parts[0].toLowerCase(Locale.ROOT);
        if (root.contains(":")) {
            root = root.substring(root.indexOf(':') + 1);
        }
        if (!root.equals("hunt") || parts.length < 3 || !parts[1].equalsIgnoreCase("altar")) {
            return;
        }

        Player player = event.getPlayer();
        if (parts.length == 3 && parts[2].equalsIgnoreCase("remove")) {
            ItemDisplay base = findLookedAtAltar(player, 12.0);
            if (base != null) {
                event.setCancelled(true);
                if (!canAdmin(player)) {
                    deny(player);
                    return;
                }
                collapseAltar(base, base.getLocation(), null, false);
                player.sendMessage(PREFIX.append(Component.text("The Crimson altar has been removed.", NamedTextColor.GRAY)));
            }
            return;
        }

        if (parts.length == 4
                && (parts[2].equalsIgnoreCase("give") || parts[2].equalsIgnoreCase("spawn"))
                && (parts[3].equalsIgnoreCase("crimson") || parts[3].equalsIgnoreCase("crimson_blade"))) {
            event.setCancelled(true);
            if (!canAdmin(player)) {
                deny(player);
                return;
            }
            if (parts[2].equalsIgnoreCase("give")) {
                giveOrDrop(player, createBlade());
                player.sendMessage(PREFIX.append(Component.text("You received the Crimson Blade.", NamedTextColor.RED)));
                player.playSound(player.getLocation(), Sound.BLOCK_VAULT_EJECT_ITEM, 0.9F, 0.9F);
            } else {
                spawnAltar(player);
            }
        }
    }

    @EventHandler
    public void onTabComplete(TabCompleteEvent event) {
        if (!(event.getSender() instanceof Player player) || !canAdmin(player)) {
            return;
        }
        String buffer = event.getBuffer().toLowerCase(Locale.ROOT);
        if (!buffer.matches("/?(?:[a-z0-9_.-]+:)?hunt\\s+altar\\s+(?:give|spawn)\\s+[^\\s]*")) {
            return;
        }
        String typed = buffer.substring(buffer.lastIndexOf(' ') + 1);
        if ("crimson".startsWith(typed)) {
            List<String> completions = new ArrayList<>(event.getCompletions());
            if (!completions.contains("crimson")) {
                completions.add("crimson");
                completions.sort(String.CASE_INSENSITIVE_ORDER);
                event.setCompletions(completions);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onOffhandTrigger(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        ItemStack blade = player.getInventory().getItemInMainHand();
        if (!isBlade(blade)) {
            return;
        }
        event.setCancelled(true);
        long now = System.currentTimeMillis();
        long lock = Math.max(250L, plugin.getConfig().getLong("beam.anti-double-fire-millis", 750L));
        long previous = lastBeamUse.getOrDefault(player.getUniqueId(), 0L);
        if (now - previous < lock) {
            return;
        }
        lastBeamUse.put(player.getUniqueId(), now);
        fireBeam(player);
    }

    private void fireBeam(Player caster) {
        double range = Math.max(4.0, plugin.getConfig().getDouble("beam.range-blocks", 36.0));
        double radius = Math.max(0.25, plugin.getConfig().getDouble("beam.radius-blocks", 0.9));
        double damage = Math.max(0.0, plugin.getConfig().getDouble("beam.direct-true-damage", 7.0));
        Location eye = caster.getEyeLocation();
        Vector direction = eye.getDirection().normalize();
        RayTraceResult blockHit = caster.getWorld().rayTraceBlocks(eye, direction, range);
        double distance = blockHit == null ? range : eye.toVector().distance(blockHit.getHitPosition());

        List<BeamVictim> victims = new ArrayList<>();
        for (Player target : caster.getWorld().getPlayers()) {
            if (target.equals(caster) || target.isDead() || !caster.canSee(target) || huntBridge.isTrusted(target, caster)) {
                continue;
            }
            Vector relative = target.getLocation().add(0.0, 1.0, 0.0).toVector().subtract(eye.toVector());
            double projection = relative.dot(direction);
            if (projection < 0.0 || projection > distance) {
                continue;
            }
            Vector nearest = eye.toVector().add(direction.clone().multiply(projection));
            double widthSquared = target.getLocation().add(0.0, 1.0, 0.0).toVector().distanceSquared(nearest);
            if (widthSquared <= radius * radius && caster.hasLineOfSight(target)) {
                victims.add(new BeamVictim(target, projection));
            }
        }
        victims.sort(Comparator.comparingDouble(BeamVictim::distance));

        renderBeam(caster, eye, direction, distance);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 0.75F, 1.55F);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.8F, 1.8F);
        caster.sendActionBar(Component.text("CRIMSON BEAM ", NamedTextColor.DARK_RED)
                .append(Component.text("◆ ", NamedTextColor.DARK_GRAY))
                .append(Component.text(victims.size() + " TARGET" + (victims.size() == 1 ? "" : "S"), NamedTextColor.RED)));

        for (BeamVictim beamVictim : victims) {
            Player target = beamVictim.player();
            credit(target, caster);
            if (huntBridge.damage(caster, target, damage)) {
                startBleed(caster, target);
                target.sendActionBar(Component.text("BLEEDING ", NamedTextColor.DARK_RED)
                        .append(Component.text("◆ 3s", NamedTextColor.RED)));
                target.getWorld().playSound(target.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 0.9F, 0.55F);
            }
        }
    }

    private void renderBeam(Player caster, Location start, Vector direction, double distance) {
        double spacing = Math.max(0.75, plugin.getConfig().getDouble("visuals.beam-display-spacing", 1.25));
        long lifetime = Math.max(2L, plugin.getConfig().getLong("visuals.beam-display-lifetime-ticks", 7L));
        List<UUID> displays = new ArrayList<>();
        ItemStack beamModel = modelItem("crimson_beam");
        int maximumDisplays = 32;

        for (double step = 0.5; step <= distance && displays.size() < maximumDisplays; step += spacing) {
            Location point = start.clone().add(direction.clone().multiply(step));
            point.setDirection(direction);
            ItemDisplay display = point.getWorld().spawn(point, ItemDisplay.class, entity -> {
                entity.setItemStack(beamModel);
                entity.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                entity.setBillboard(Display.Billboard.FIXED);
                entity.setBrightness(new Display.Brightness(15, 15));
                entity.setPersistent(false);
                entity.setViewRange(64.0F);
                entity.setGlowing(true);
                entity.setGlowColorOverride(Color.fromRGB(255, 22, 76));
            });
            displays.add(display.getUniqueId());
            point.getWorld().spawnParticle(Particle.DUST, point, 1, 0.02, 0.02, 0.02, 0.0, BEAM_DUST);
        }

        Location impact = start.clone().add(direction.clone().multiply(distance));
        impact.getWorld().spawnParticle(Particle.ITEM, impact, 26, 0.55, 0.55, 0.55, 0.08, modelItem("crimson_fragment"));
        impact.getWorld().spawnParticle(Particle.FLASH, impact, 1);
        impact.getWorld().playSound(impact, Sound.BLOCK_TRIAL_SPAWNER_BREAK, 0.65F, 0.6F);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (UUID id : displays) {
                Entity entity = Bukkit.getEntity(id);
                if (entity != null) {
                    entity.remove();
                }
            }
        }, lifetime);
    }

    private void startBleed(Player attacker, Player target) {
        BukkitTask previous = activeBleeds.remove(target.getUniqueId());
        if (previous != null) {
            previous.cancel();
        }
        int seconds = Math.max(1, plugin.getConfig().getInt("beam.bleed-seconds", 3));
        double damage = Math.max(0.0, plugin.getConfig().getDouble("beam.bleed-true-damage-per-second", 1.0));
        UUID targetId = target.getUniqueId();
        UUID attackerId = attacker.getUniqueId();

        BukkitRunnable runnable = new BukkitRunnable() {
            private int elapsed;

            @Override
            public void run() {
                Player currentTarget = Bukkit.getPlayer(targetId);
                Player currentAttacker = Bukkit.getPlayer(attackerId);
                if (currentTarget == null || currentAttacker == null || currentTarget.isDead()
                        || currentTarget.getWorld() != currentAttacker.getWorld() || elapsed >= seconds) {
                    activeBleeds.remove(targetId);
                    cancel();
                    return;
                }
                elapsed++;
                credit(currentTarget, currentAttacker);
                huntBridge.damage(currentAttacker, currentTarget, damage);
                Location center = currentTarget.getLocation().add(0.0, 1.0, 0.0);
                center.getWorld().spawnParticle(Particle.ITEM, center, 12, 0.45, 0.75, 0.45, 0.06, modelItem("crimson_fragment"));
                center.getWorld().spawnParticle(Particle.DUST, center, 18, 0.4, 0.65, 0.4, 0.02, BEAM_DUST);
                currentTarget.playSound(currentTarget.getLocation(), Sound.ENTITY_PLAYER_HURT, 0.65F, 0.55F);
                if (elapsed >= seconds) {
                    activeBleeds.remove(targetId);
                    cancel();
                }
            }
        };
        activeBleeds.put(targetId, runnable.runTaskTimer(plugin, 20L, 20L));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBladeDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player attacker
                && event.getEntity() instanceof Player victim
                && isBlade(attacker.getInventory().getItemInMainHand())) {
            credit(victim, attacker);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();
        HitCredit credit = hitCredits.remove(dead.getUniqueId());
        Player killer = dead.getKiller();
        if (killer == null && credit != null && credit.expiresAt() >= System.currentTimeMillis()) {
            killer = Bukkit.getPlayer(credit.attacker());
        }
        if (killer == null) {
            return;
        }
        ItemStack blade = findBlade(killer);
        if (blade != null) {
            upgradeSharpness(killer, blade);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBladeDrop(PlayerDropItemEvent event) {
        Item item = event.getItemDrop();
        if (isBlade(item.getItemStack())) {
            trackDroppedBlade(item, event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBladeSpawn(ItemSpawnEvent event) {
        Item item = event.getEntity();
        if (isBlade(item.getItemStack())) {
            trackDroppedBlade(item, null);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBladePickup(EntityPickupItemEvent event) {
        forgetDroppedBlade(event.getItem(), true);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBladeHopperPickup(InventoryPickupItemEvent event) {
        forgetDroppedBlade(event.getItem(), true);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBladeDespawn(ItemDespawnEvent event) {
        droppedBlades.remove(event.getEntity().getUniqueId());
    }

    private void trackDroppedBlade(Item item, Player owner) {
        if (!isBlade(item.getItemStack()) || droppedBlades.containsKey(item.getUniqueId())) {
            return;
        }
        item.setGravity(false);
        item.setGlowing(true);
        item.setVelocity(new Vector());
        item.getPersistentDataContainer().set(droppedBladeKey, PersistentDataType.BYTE, (byte) 1);
        if (owner != null) {
            item.getPersistentDataContainer().set(
                    droppedOwnerKey, PersistentDataType.STRING, owner.getUniqueId().toString());
        }
        double phase = Math.floorMod(item.getUniqueId().hashCode(), 360) * Math.PI / 180.0;
        droppedBlades.put(item.getUniqueId(), new DroppedBlade(item.getLocation().getY(), phase));
    }

    private void forgetDroppedBlade(Item item, boolean restoreVanillaPhysics) {
        if (droppedBlades.remove(item.getUniqueId()) == null) {
            return;
        }
        if (restoreVanillaPhysics && item.isValid()) {
            item.setGravity(true);
            item.setGlowing(false);
        }
    }

    private void credit(Player victim, Player attacker) {
        hitCredits.put(victim.getUniqueId(), new HitCredit(attacker.getUniqueId(), System.currentTimeMillis() + 15_000L));
    }

    private ItemStack findBlade(Player player) {
        ItemStack mainHand = player.getInventory().getItemInMainHand();
        if (isBlade(mainHand)) {
            return mainHand;
        }
        for (ItemStack item : player.getInventory().getStorageContents()) {
            if (isBlade(item)) {
                return item;
            }
        }
        return null;
    }

    private void upgradeSharpness(Player killer, ItemStack blade) {
        int maximum = Math.max(1, plugin.getConfig().getInt("progression.maximum-sharpness", 7));
        ItemMeta meta = blade.getItemMeta();
        int current = meta.getPersistentDataContainer().getOrDefault(sharpnessKey, PersistentDataType.INTEGER, 0);
        if (current >= maximum) {
            killer.sendActionBar(Component.text("CRIMSON BLADE ", NamedTextColor.DARK_RED)
                    .append(Component.text("◆ ", NamedTextColor.DARK_GRAY))
                    .append(Component.text("SHARPNESS VII MAXED", NamedTextColor.RED)));
            return;
        }
        int next = current + 1;
        meta.getPersistentDataContainer().set(sharpnessKey, PersistentDataType.INTEGER, next);
        meta.addEnchant(Enchantment.SHARPNESS, next, true);
        meta.lore(bladeLore(next, maximum));
        blade.setItemMeta(meta);
        killer.showTitle(Title.title(
                Component.text("CRIMSON AWAKENED", NamedTextColor.DARK_RED),
                Component.text("Sharpness " + roman(next), NamedTextColor.RED)
                        .append(Component.text(" / " + roman(maximum), NamedTextColor.DARK_GRAY)),
                Title.Times.times(Duration.ofMillis(250), Duration.ofMillis(1750), Duration.ofMillis(500))));
        killer.playSound(killer.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0F, 0.65F + next * 0.06F);
        killer.getWorld().spawnParticle(Particle.ITEM, killer.getLocation().add(0.0, 1.0, 0.0),
                32, 0.65, 0.8, 0.65, 0.08, modelItem("crimson_fragment"));
    }

    private void animate() {
        long tick = Bukkit.getCurrentTick();
        altarRelics.removeIf(id -> {
            Entity entity = Bukkit.getEntity(id);
            if (!(entity instanceof ItemDisplay display) || !display.isValid()) {
                return true;
            }
            Location location = display.getLocation();
            location.setYaw((tick * 4.4F) % 360.0F);
            location.setY(Math.floor(location.getY()) + 0.82 + Math.sin(tick * 0.1) * 0.13);
            display.teleport(location);
            if (tick % 8L == 0L) {
                display.getWorld().spawnParticle(Particle.ITEM, location, 2, 0.35, 0.32, 0.35, 0.02, modelItem("crimson_fragment"));
            }
            return false;
        });

        droppedBlades.entrySet().removeIf(entry -> {
            Entity entity = Bukkit.getEntity(entry.getKey());
            if (!(entity instanceof Item item) || !item.isValid() || !isBlade(item.getItemStack())) {
                return true;
            }
            Location location = item.getLocation();
            double viewRange = Math.max(8.0, plugin.getConfig().getDouble("visuals.dropped-blade-view-range", 48.0));
            if (item.getWorld().getNearbyPlayers(location, viewRange).isEmpty()) {
                return false;
            }
            DroppedBlade tracked = entry.getValue();
            location.setY(tracked.baseY() + Math.sin(tick * 0.09 + tracked.phase()) * 0.12);
            location.setYaw((tick * 2.4F + (float) Math.toDegrees(tracked.phase())) % 360.0F);
            item.teleport(location);
            item.setVelocity(new Vector());
            long particlePeriod = Math.max(4L,
                    plugin.getConfig().getLong("visuals.dropped-particle-period-ticks", 8L));
            if (tick % particlePeriod == 0L) {
                item.getWorld().spawnParticle(Particle.ITEM, location.clone().add(0.0, 0.2, 0.0),
                        2, 0.32, 0.36, 0.32, 0.015, modelItem("crimson_fragment"));
                item.getWorld().spawnParticle(Particle.DUST, location.clone().add(0.0, 0.2, 0.0),
                        3, 0.28, 0.38, 0.28, 0.005, BEAM_DUST);
            }
            return false;
        });

        ItemStack fragment = modelItem("crimson_fragment");
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!isBlade(player.getInventory().getItemInMainHand())) {
                continue;
            }
            Vector forward = player.getEyeLocation().getDirection().normalize();
            Vector side = forward.clone().crossProduct(new Vector(0.0, 1.0, 0.0));
            if (side.lengthSquared() < 0.001) {
                side = new Vector(1.0, 0.0, 0.0);
            } else {
                side.normalize();
            }
            Location hand = player.getEyeLocation().add(forward.multiply(0.65)).add(side.multiply(0.34)).add(0.0, -0.42, 0.0);
            hand.getWorld().spawnParticle(Particle.ITEM, hand, 1, 0.18, 0.3, 0.18, 0.02, fragment);
            hand.getWorld().spawnParticle(Particle.DUST, hand, 2, 0.16, 0.25, 0.16, 0.01, BEAM_DUST);
        }
        long now = System.currentTimeMillis();
        hitCredits.entrySet().removeIf(entry -> entry.getValue().expiresAt() < now);
    }

    private ItemStack createBlade() {
        ItemStack item = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Crimson Blade", NamedTextColor.DARK_RED)
                .decorate(TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.setItemModel(new NamespacedKey("hunt", "crimson_blade"));
        meta.getPersistentDataContainer().set(bladeKey, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(sharpnessKey, PersistentDataType.INTEGER, 0);
        meta.getPersistentDataContainer().set(huntWeaponKey, PersistentDataType.STRING, WEAPON_ID);
        meta.setEnchantmentGlintOverride(true);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_UNBREAKABLE);
        meta.lore(bladeLore(0, Math.max(1, plugin.getConfig().getInt("progression.maximum-sharpness", 7))));
        item.setItemMeta(meta);
        return item;
    }

    private List<Component> bladeLore(int sharpness, int maximum) {
        return List.of(
                loreLine("CRIMSON RELIC", NamedTextColor.DARK_RED),
                Component.empty(),
                lorePair("F KEY / OFFHAND", "CRIMSON BEAM"),
                lorePair("TRUE DAMAGE", "3.5 HEARTS"),
                lorePair("BLEEDING", "0.5 HEARTS × 3"),
                Component.empty(),
                loreLine("BLOOD AWAKENING  |  SHARPNESS " + roman(sharpness) + "/" + roman(maximum), NamedTextColor.DARK_RED),
                loreLine("Player kills permanently sharpen the blade.", NamedTextColor.GRAY)
        );
    }

    private Component lorePair(String left, String right) {
        return loreLine(left, NamedTextColor.RED)
                .append(Component.text("  |  ", NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false))
                .append(Component.text(right, NamedTextColor.WHITE).decoration(TextDecoration.ITALIC, false));
    }

    private Component loreLine(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private boolean isBlade(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(bladeKey, PersistentDataType.BYTE)
                || item.getItemMeta().getPersistentDataContainer().has(legacyBladeKey, PersistentDataType.BYTE);
    }

    private ItemStack modelItem(String model) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.setItemModel(new NamespacedKey("hunt", model));
        item.setItemMeta(meta);
        return item;
    }

    private void giveOrDrop(Player player, ItemStack item) {
        Map<Integer, ItemStack> overflow = player.getInventory().addItem(item);
        for (ItemStack remaining : overflow.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), remaining);
        }
    }

    private boolean canAdmin(Player player) {
        return player.isOp() || player.hasPermission("hunt.admin");
    }

    private void deny(Player player) {
        player.sendMessage(PREFIX.append(Component.text("You do not have permission to use altar commands.", NamedTextColor.RED)));
    }

    private String roman(int value) {
        return switch (value) {
            case 0 -> "0";
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            default -> Integer.toString(value);
        };
    }

    private void spawnAltar(Player player) {
        Block target = player.getTargetBlockExact(8);
        Location anchor = target == null
                ? player.getLocation().getBlock().getLocation()
                : target.getLocation().add(0.0, 1.0, 0.0);
        Block collision = anchor.getBlock();
        if (!collision.isEmpty() && collision.getType() != Material.BARRIER) {
            player.sendMessage(PREFIX.append(Component.text("That space is blocked.", NamedTextColor.RED)));
            return;
        }
        collision.setType(Material.BARRIER, false);
        String group = UUID.randomUUID().toString();
        Location center = anchor.clone().add(0.5, 0.5, 0.5);

        ItemDisplay base = anchor.getWorld().spawn(center, ItemDisplay.class, display -> {
            display.setItemStack(modelItem("weapon_altar"));
            display.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            display.setBrightness(new Display.Brightness(15, 15));
            display.setPersistent(true);
            tag(display, "base", group);
        });
        base.setPersistent(true);

        ItemDisplay relic = anchor.getWorld().spawn(anchor.clone().add(0.5, 1.85, 0.5), ItemDisplay.class, display -> {
            display.setItemStack(createBlade());
            display.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            display.setBrightness(new Display.Brightness(15, 15));
            display.setBillboard(Display.Billboard.FIXED);
            display.setPersistent(true);
            tag(display, "relic", group);
        });
        altarRelics.add(relic.getUniqueId());
        spawnRecipeText(anchor, group);
        anchor.getWorld().playSound(center, Sound.BLOCK_END_PORTAL_SPAWN, 0.9F, 0.75F);
        anchor.getWorld().spawnParticle(Particle.ITEM, center.clone().add(0.0, 1.2, 0.0),
                48, 0.75, 1.0, 0.75, 0.08, modelItem("crimson_fragment"));
        player.sendMessage(PREFIX.append(Component.text("Crimson Blade altar released.", NamedTextColor.RED)));
    }

    private void spawnRecipeText(Location anchor, String group) {
        List<Component> rows = List.of(
                Component.text("✦  CRIMSON BLADE  ✦", NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD),
                Component.text("F O R G I N G   R E Q U I R E M E N T S", NamedTextColor.DARK_GRAY),
                ingredientRow("x3", "WITHER SKELETON SKULL"),
                ingredientRow("x1", "NETHER STAR"),
                ingredientRow("x64", "CRIMSON NYLIUM"),
                ingredientRow("x3", "NETHERITE INGOT"),
                ingredientRow("x32", "QUARTZ BLOCK"),
                Component.text("RIGHT CLICK THE ALTAR TO FORGE", NamedTextColor.DARK_GRAY)
        );
        for (int index = 0; index < rows.size(); index++) {
            int rowIndex = index;
            TextDisplay text = anchor.getWorld().spawn(
                    anchor.clone().add(0.5, 4.0 - index * 0.22, 0.5), TextDisplay.class, display -> {
                        display.text(rows.get(rowIndex));
                        display.setBillboard(Display.Billboard.CENTER);
                        display.setSeeThrough(false);
                        display.setShadowed(true);
                        display.setLineWidth(320);
                        display.setBackgroundColor(Color.fromARGB(rowIndex <= 1 ? 160 : 96, 8, 0, 4));
                        display.setBrightness(new Display.Brightness(15, 15));
                        display.setPersistent(true);
                        tag(display, "text", group);
                    });
            text.setPersistent(true);
        }
    }

    private Component ingredientRow(String amount, String ingredient) {
        return Component.text("▪  " + amount + "  ", NamedTextColor.RED)
                .append(Component.text(ingredient, NamedTextColor.WHITE));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onAltarForge(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND || event.getAction() != Action.RIGHT_CLICK_BLOCK
                || event.getClickedBlock() == null || event.getClickedBlock().getType() != Material.BARRIER) {
            return;
        }
        Location center = event.getClickedBlock().getLocation().add(0.5, 0.5, 0.5);
        ItemDisplay base = findBaseNear(center);
        if (base == null) {
            return;
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        Map<Material, Integer> costs = recipeCosts();
        List<String> missing = new ArrayList<>();
        for (Map.Entry<Material, Integer> entry : costs.entrySet()) {
            int owned = countMaterial(player, entry.getKey());
            if (owned < entry.getValue()) {
                missing.add((entry.getValue() - owned) + "x " + friendlyName(entry.getKey()));
            }
        }
        if (!missing.isEmpty()) {
            player.sendMessage(PREFIX
                    .append(Component.text("Forging failed. Missing: ", NamedTextColor.RED))
                    .append(Component.text(String.join(" / ", missing), NamedTextColor.WHITE)));
            player.playSound(center, Sound.BLOCK_VAULT_REJECT_REWARDED_PLAYER, 0.8F, 0.7F);
            center.getWorld().spawnParticle(Particle.SMOKE, center.clone().add(0.0, 0.9, 0.0),
                    16, 0.35, 0.45, 0.35, 0.02);
            return;
        }

        for (Map.Entry<Material, Integer> entry : costs.entrySet()) {
            removeMaterial(player, entry.getKey(), entry.getValue());
        }
        giveOrDrop(player, createBlade());
        center.getWorld().playSound(center, Sound.BLOCK_VAULT_EJECT_ITEM, 1.0F, 0.7F);
        center.getWorld().playSound(center, Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.9F, 1.35F);
        center.getWorld().spawnParticle(Particle.ITEM, center.clone().add(0.0, 1.2, 0.0),
                64, 0.7, 0.9, 0.7, 0.1, modelItem("crimson_fragment"));
        collapseAltar(base, center, player, true);
    }

    private Map<Material, Integer> recipeCosts() {
        Map<Material, Integer> costs = new LinkedHashMap<>();
        costs.put(Material.WITHER_SKELETON_SKULL, 3);
        costs.put(Material.NETHER_STAR, 1);
        costs.put(Material.CRIMSON_NYLIUM, 64);
        costs.put(Material.NETHERITE_INGOT, 3);
        costs.put(Material.QUARTZ_BLOCK, 32);
        return costs;
    }

    private int countMaterial(Player player, Material material) {
        int count = 0;
        for (ItemStack item : player.getInventory().getStorageContents()) {
            if (item != null && item.getType() == material) {
                count += item.getAmount();
            }
        }
        return count;
    }

    private void removeMaterial(Player player, Material material, int amount) {
        ItemStack[] contents = player.getInventory().getStorageContents();
        int remaining = amount;
        for (int slot = 0; slot < contents.length && remaining > 0; slot++) {
            ItemStack item = contents[slot];
            if (item == null || item.getType() != material) {
                continue;
            }
            int removed = Math.min(item.getAmount(), remaining);
            remaining -= removed;
            if (removed == item.getAmount()) {
                contents[slot] = null;
            } else {
                item.setAmount(item.getAmount() - removed);
            }
        }
        player.getInventory().setStorageContents(contents);
    }

    private void collapseAltar(ItemDisplay base, Location center, Player crafter, boolean announce) {
        String group = base.getPersistentDataContainer().get(altarGroupKey, PersistentDataType.STRING);
        for (Entity entity : new ArrayList<>(center.getWorld().getEntities())) {
            if (entity instanceof Display display
                    && group != null
                    && group.equals(display.getPersistentDataContainer().get(altarGroupKey, PersistentDataType.STRING))) {
                altarRelics.remove(display.getUniqueId());
                display.remove();
            }
        }
        Block block = center.getBlock();
        if (block.getType() == Material.BARRIER) {
            block.setType(Material.AIR, false);
        }
        center.getWorld().spawnParticle(Particle.ITEM, center.clone().add(0.0, 1.1, 0.0),
                42, 0.75, 1.0, 0.75, 0.08, modelItem("crimson_fragment"));
        center.getWorld().playSound(center, Sound.BLOCK_END_PORTAL_FRAME_FILL, 1.0F, 0.55F);
        if (announce && crafter != null) {
            Component announcement = Component.text("HUNT RELIC ", NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD)
                    .append(Component.text("| ", NamedTextColor.DARK_GRAY).decoration(TextDecoration.BOLD, false))
                    .append(Component.text(crafter.getName(), NamedTextColor.WHITE).decoration(TextDecoration.BOLD, false))
                    .append(Component.text(" has forged the Crimson Blade. ", NamedTextColor.RED).decoration(TextDecoration.BOLD, false))
                    .append(Component.text("The altar has disappeared.", NamedTextColor.GRAY).decoration(TextDecoration.BOLD, false));
            for (Player online : Bukkit.getOnlinePlayers()) {
                online.sendMessage(announcement);
            }
        }
    }

    private ItemDisplay findBaseNear(Location center) {
        for (Entity entity : center.getWorld().getNearbyEntities(center, 0.8, 0.8, 0.8)) {
            if (entity instanceof ItemDisplay display
                    && "base".equals(display.getPersistentDataContainer().get(altarRoleKey, PersistentDataType.STRING))) {
                return display;
            }
        }
        return null;
    }

    private ItemDisplay findLookedAtAltar(Player player, double range) {
        Vector sight = player.getEyeLocation().getDirection().normalize();
        ItemDisplay selected = null;
        double best = Double.NEGATIVE_INFINITY;
        for (ItemDisplay display : player.getWorld().getEntitiesByClass(ItemDisplay.class)) {
            if (!"base".equals(display.getPersistentDataContainer().get(altarRoleKey, PersistentDataType.STRING))) {
                continue;
            }
            Vector offset = display.getLocation().toVector().subtract(player.getEyeLocation().toVector());
            double distance = offset.length();
            if (distance < 0.1 || distance > range) {
                continue;
            }
            double alignment = sight.dot(offset.normalize());
            double score = alignment * 4.0 - distance * 0.08;
            if (alignment >= 0.72 && score > best) {
                best = score;
                selected = display;
            }
        }
        return selected;
    }

    private void tag(Display display, String role, String group) {
        display.getPersistentDataContainer().set(altarRoleKey, PersistentDataType.STRING, role);
        display.getPersistentDataContainer().set(altarGroupKey, PersistentDataType.STRING, group);
    }

    private String friendlyName(Material material) {
        String[] words = material.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            if (!result.isEmpty()) {
                result.append(' ');
            }
            result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return result.toString();
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent event) {
        for (Entity entity : event.getChunk().getEntities()) {
            if (entity instanceof ItemDisplay display
                    && "relic".equals(display.getPersistentDataContainer().get(altarRoleKey, PersistentDataType.STRING))) {
                altarRelics.add(display.getUniqueId());
            } else if (entity instanceof Item item && isBlade(item.getItemStack())) {
                trackDroppedBlade(item, null);
            }
        }
    }

    @EventHandler
    public void onChunkUnload(ChunkUnloadEvent event) {
        for (Entity entity : event.getChunk().getEntities()) {
            if (entity instanceof Item item) {
                forgetDroppedBlade(item, true);
            }
        }
    }

    private record BeamVictim(Player player, double distance) {}

    private record HitCredit(UUID attacker, long expiresAt) {}

    private record DroppedBlade(double baseY, double phase) {}
}
