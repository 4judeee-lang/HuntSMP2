#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
SOURCE="$ROOT/work/crimson-v2-source/crimson_blade_alpha.png"
PACK="$ROOT/crimson-addon/resource-pack-overlay"
ART="$ROOT/crimson-addon/art-source"
TEXTURES="$PACK/assets/hunt/textures/item"
FRAMES="$ART/animation_frames"

mkdir -p "$TEXTURES" "$FRAMES"

# Keep the connected weapon on one immutable texture. Nearest-neighbour scaling
# and palette reduction preserve the reference's deliberately crisp pixel art.
convert "$SOURCE" \
  -trim +repage \
  -filter point -resize 31x112! \
  -dither None -colors 28 \
  -gravity center -background none -extent 128x128 \
  "$TEXTURES/crimson_blade.png"

cp "$TEXTURES/crimson_blade.png" "$ART/crimson_blade_static.png"

palette=("#e01958" "#ff2b87" "#a31f9d" "#59117f" "#c2266d" "#78118d")

for frame in $(seq 0 15); do
  canvas="$FRAMES/crimson_blade_aura_$(printf '%02d' "$frame").png"
  convert -size 128x128 xc:none "$canvas"

  # Six looping tracks. Each fragment rises independently and wraps below the
  # sword; opacity decreases near the top so the loop never flashes.
  for track in $(seq 0 5); do
    phase=$(( (frame * 3 + track * 7) % 48 ))
    y=$(( 108 - phase * 2 ))
    case "$track" in
      0) x=35 ;;
      1) x=91 ;;
      2) x=24 ;;
      3) x=102 ;;
      4) x=37 ;;
      *) x=82 ;;
    esac

    sway_index=$(( (frame + track * 2) % 6 ))
    case "$sway_index" in
      0) sway=-2 ;;
      1) sway=-1 ;;
      2) sway=0 ;;
      3) sway=2 ;;
      4) sway=1 ;;
      *) sway=0 ;;
    esac
    x=$((x + sway))

    if (( y < 18 || y > 112 )); then
      continue
    fi

    color="${palette[$track]}"
    if (( y < 34 )); then
      color="${color}70"
    elif (( y < 50 )); then
      color="${color}b8"
    else
      color="${color}e8"
    fi

    case "$track" in
      0|4)
        convert "$canvas" -fill "$color" \
          -draw "rectangle $x,$y $((x+3)),$((y+7)) rectangle $((x+3)),$((y+5)) $((x+6)),$((y+10))" "$canvas"
        ;;
      1|3)
        convert "$canvas" -fill "$color" \
          -draw "rectangle $x,$y $((x+6)),$((y+3)) rectangle $((x+4)),$((y-3)) $((x+9)),$y" "$canvas"
        ;;
      *)
        convert "$canvas" -fill "$color" \
          -draw "rectangle $x,$y $((x+3)),$((y+3)) rectangle $((x+5)),$((y-5)) $((x+7)),$((y-2))" "$canvas"
        ;;
    esac
  done

  # Two slower rune fragments provide the larger middle/upper aura shapes.
  rune_y=$((86 - (frame * 4 % 68)))
  rune_x=$((frame % 8 < 4 ? 97 : 94))
  convert "$canvas" -fill '#d51d5fd8' \
    -draw "rectangle $rune_x,$rune_y $((rune_x+4)),$((rune_y+10)) rectangle $((rune_x-4)),$((rune_y+8)) $rune_x,$((rune_y+13))" "$canvas"

  shard_y=$((100 - ((frame * 3 + 24) % 72)))
  convert "$canvas" -fill '#641087c8' \
    -draw "rectangle 27,$shard_y 31,$((shard_y+8)) rectangle 31,$((shard_y+6)) 34,$((shard_y+12))" "$canvas"
done

convert "$FRAMES"/crimson_blade_aura_*.png -append "$TEXTURES/crimson_blade_aura.png"

# Small standalone shard used by particles and managed ItemDisplays.
convert -size 32x32 xc:none \
  -fill '#5c0d7f' -draw 'rectangle 7,6 12,16 rectangle 11,13 17,22' \
  -fill '#cc1d63' -draw 'rectangle 12,8 17,17 rectangle 16,15 23,21' \
  -fill '#ff3b89' -draw 'rectangle 15,10 18,14 rectangle 19,16 24,18' \
  "$TEXTURES/crimson_fragment.png"

identify "$TEXTURES/crimson_blade.png" "$TEXTURES/crimson_blade_aura.png" "$TEXTURES/crimson_fragment.png"
