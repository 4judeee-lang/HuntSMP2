# Crimson Blade art source

- `crimson_blade_generated_chroma.png`: generated orthographic source before key removal.
- `crimson_blade_alpha.png`: full-resolution transparent source.
- `crimson_blade_static.png`: 128×128 production static sword.
- `crimson_blade_aura.png`: 128×2048 production atlas containing 16 independent aura frames.
- `animation_frames/`: the 16 unpacked 128×128 frames in playback order.
- `crimson_blade.bbmodel`: editable Blockbench source with separate static and aura planes.

Run `../tools/build_crimson_assets.sh` from any working directory to regenerate the production textures from the alpha source.
