/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.resource;

import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class ResourcePackService {
    private static final UUID PACK_ID = UUID.fromString("57eb91ca-3c88-4b55-a990-07142026f007");
    private static final String PACK_URL = "https://raw.githubusercontent.com/4judeee-lang/HuntSMP2/main/HuntSMP-Pack-1.21.1.zip";
    private static final String PACK_SHA1 = "bef00d5e2a95848aa1d6681fe09032ae824178ea";
    private static final String PROMPT = "The complete HuntSMP resource pack is required.";
    private final JavaPlugin plugin;
    private final Map<UUID, PlayerResourcePackStatusEvent.Status> statuses = new ConcurrentHashMap<UUID, PlayerResourcePackStatusEvent.Status>();

    public ResourcePackService(JavaPlugin javaPlugin) {
        this.plugin = javaPlugin;
    }

    public void sendLater(Player player) {
        this.plugin.getServer().getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            if (player.isOnline()) {
                this.send(player);
            }
        }, 20L);
    }

    public void send(Player player) {
        this.statuses.remove(player.getUniqueId());
        player.addResourcePack(PACK_ID, PACK_URL, HexFormat.of().parseHex(PACK_SHA1), PROMPT, true);
        player.addResourcePack(UUID.fromString("57eb91ca-3c88-4b55-a990-07142026d009"), "https://raw.githubusercontent.com/4judeee-lang/HuntSMP2/main/4judeeDivineOverlay-v9.zip", HexFormat.of().parseHex("e048cff1c6842a1bdc61d949369d05eafc272078"), "The HuntSMP Divine Spear weapon models are required.", true);
    }

    public boolean mayStart(Player player) {
        return this.statuses.get(player.getUniqueId()) == PlayerResourcePackStatusEvent.Status.SUCCESSFULLY_LOADED;
    }

    public void handleStatus(Player player, PlayerResourcePackStatusEvent.Status status) {
        this.statuses.put(player.getUniqueId(), status);
        if (status != PlayerResourcePackStatusEvent.Status.SUCCESSFULLY_LOADED) {
            this.plugin.getLogger().warning("Resource pack status for " + String.valueOf(player.getUniqueId()) + ": " + String.valueOf(status));
        }
    }

    public boolean configurationValid() {
        return true;
    }

    public String validationSummary() {
        return "Complete HuntSMP base pack URL and SHA-1 are pinned and valid.";
    }
}

