/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.camera;

import me.judee.huntrift.camera.ProtocolCameraBridge;
import me.judee.huntrift.rift.RiftFrame;
import me.judee.huntrift.rift.Vec3;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public final class CameraController {
    private final JavaPlugin plugin;
    private final ProtocolCameraBridge bridge;
    private final boolean enabled;
    private final Vector forward;
    private final Vector right;
    private ArmorStand rig;
    private boolean cameraAttached;
    private boolean cameraFailed;
    private Location lastCameraLocation;

    public CameraController(JavaPlugin plugin, ProtocolCameraBridge bridge, Location anchor) {
        this.plugin = plugin;
        this.bridge = bridge;
        this.enabled = plugin.getConfig().getBoolean("camera.enabled", true);
        this.forward = CameraController.horizontalDirection(anchor);
        this.right = new Vector(-this.forward.getZ(), 0.0, this.forward.getX());
    }

    public boolean canProvideCinematicCamera() {
        return this.enabled && this.bridge.isAvailable();
    }

    public void update(Player player, RiftFrame frame) {
        if (!this.enabled || frame.soundPlaybackSeconds() >= 3.133) {
            this.restore(player);
        } else if (this.bridge.isAvailable() && !this.cameraFailed) {
            this.ensureRig(player);
            if (this.rig != null && this.rig.isValid()) {
                Vec3 offset = frame.cameraOffset();
                Location target = player.getLocation().add(0.0, 1.05, 0.0);
                Location camera = target.clone().add(this.right.clone().multiply(offset.x())).add(0.0, offset.y(), 0.0).add(this.forward.clone().multiply(offset.z()));
                double shake = frame.cameraShake();
                if (shake > 0.0) {
                    double phase = (double)frame.referenceFrame() * 1.61803398875;
                    camera.add(Math.sin(phase * 2.7) * shake, Math.cos(phase * 3.1) * shake * 0.65, Math.sin(phase * 4.3) * shake * 0.45);
                }
                camera.setDirection(target.toVector().subtract(camera.toVector()));
                this.rig.teleport(camera);
                this.lastCameraLocation = camera.clone();
                if (!this.cameraAttached) {
                    this.cameraAttached = this.bridge.setCamera(player, (Entity)this.rig);
                    if (!this.cameraAttached) {
                        this.cameraFailed = true;
                        if (this.rig != null && this.rig.isValid()) {
                            this.rig.remove();
                        }
                        this.rig = null;
                        this.plugin.getLogger().warning("Cinematic camera packet was rejected; continuing with the working first-person launch fallback.");
                    }
                }
            }
        }
    }

    public Location cameraLocation() {
        return this.lastCameraLocation == null ? null : this.lastCameraLocation.clone();
    }

    public void restore(Player player) {
        if (this.cameraAttached) {
            this.bridge.setCamera(player, (Entity)player);
            this.cameraAttached = false;
        }
        if (this.rig != null && this.rig.isValid()) {
            this.rig.remove();
        }
        this.rig = null;
    }

    private void ensureRig(Player player) {
        if (this.rig == null || !this.rig.isValid()) {
            this.rig = (ArmorStand)player.getWorld().spawn(player.getLocation(), ArmorStand.class, display -> {
                display.setGravity(false);
                display.setInvulnerable(true);
                display.setPersistent(false);
                display.setSilent(true);
                display.setVisible(false);
                display.setMarker(true);
                display.setSmall(true);
                display.setCollidable(false);
                display.addScoreboardTag("hunt_rift_camera");
            });
        }
    }

    private static Vector horizontalDirection(Location location) {
        Vector direction = location.getDirection().setY(0.0);
        return direction.lengthSquared() < 1.0E-6 ? new Vector(0.0, 0.0, 1.0) : direction.normalize();
    }
}

