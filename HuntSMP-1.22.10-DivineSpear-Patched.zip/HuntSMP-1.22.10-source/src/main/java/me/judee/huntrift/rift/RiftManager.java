/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.rift;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.logging.Level;
import me.judee.huntrift.camera.ProtocolCameraBridge;
import me.judee.huntrift.resource.ResourcePackService;
import me.judee.huntrift.rift.FinishReason;
import me.judee.huntrift.rift.RiftPhase;
import me.judee.huntrift.rift.RiftSession;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public final class RiftManager {
    private final JavaPlugin plugin;
    private final ResourcePackService resourcePacks;
    private final ProtocolCameraBridge cameraBridge;
    private final Consumer<Player> cinematicCompleteCallback;
    private final Map<UUID, RiftSession> sessions = new HashMap<UUID, RiftSession>();
    private final Map<UUID, Long> cooldownUntil = new HashMap<UUID, Long>();
    private final Map<UUID, Location> comparisonAnchors = new HashMap<UUID, Location>();
    private BukkitTask ticker;

    public RiftManager(JavaPlugin plugin, ResourcePackService resourcePacks, ProtocolCameraBridge cameraBridge, Consumer<Player> cinematicCompleteCallback) {
        this.plugin = plugin;
        this.resourcePacks = resourcePacks;
        this.cameraBridge = cameraBridge;
        this.cinematicCompleteCallback = cinematicCompleteCallback;
    }

    public void startTicker() {
        this.ticker = this.plugin.getServer().getScheduler().runTaskTimer((Plugin)this.plugin, this::tick, 0L, 1L);
    }

    public StartResult start(Player player, RiftPhase previewPhase, boolean comparisonMode) {
        Location anchor;
        if (this.sessions.containsKey(player.getUniqueId())) {
            return StartResult.ALREADY_ACTIVE;
        }
        if (player.isDead()) {
            return StartResult.DEAD;
        }
        if (this.remainingCooldownSeconds(player) > 0L) {
            return StartResult.COOLDOWN;
        }
        int maximum = Math.max(1, this.plugin.getConfig().getInt("limits.maximum-simultaneous-rifts", 3));
        if (this.sessions.size() >= maximum) {
            return StartResult.LIMIT_REACHED;
        }
        if (!this.resourcePacks.mayStart(player)) {
            return StartResult.PACK_NOT_LOADED;
        }
        if (this.plugin.getConfig().getBoolean("camera.enabled", true) && this.plugin.getConfig().getBoolean("camera.require-protocollib-for-cinematic-camera", false) && !this.cameraBridge.isAvailable()) {
            return StartResult.CAMERA_UNAVAILABLE;
        }
        Location location = anchor = comparisonMode ? this.comparisonAnchor(player) : player.getLocation().clone();
        if (comparisonMode) {
            anchor.setYaw(0.0f);
            anchor.setPitch(0.0f);
            player.teleport(anchor);
        }
        try {
            RiftSession session = new RiftSession(this.plugin, player, this.cameraBridge, anchor, previewPhase, this.cinematicCompleteCallback);
            this.sessions.put(player.getUniqueId(), session);
            int cooldownSeconds = Math.max(0, this.plugin.getConfig().getInt("rift.cooldown-seconds", 20));
            this.cooldownUntil.put(player.getUniqueId(), System.currentTimeMillis() + (long)cooldownSeconds * 1000L);
            return StartResult.STARTED;
        }
        catch (RuntimeException exception) {
            this.plugin.getLogger().log(Level.SEVERE, "Unable to start rift for " + player.getName(), exception);
            return StartResult.INTERNAL_ERROR;
        }
    }

    public boolean cancel(Player player, FinishReason reason, boolean restoreOriginalPosition) {
        RiftSession session = this.sessions.remove(player.getUniqueId());
        if (session == null) {
            return false;
        }
        session.finish(reason, restoreOriginalPosition);
        return true;
    }

    public RiftSession session(Player player) {
        return this.sessions.get(player.getUniqueId());
    }

    public boolean hasActiveSessions() {
        return !this.sessions.isEmpty();
    }

    public long remainingCooldownSeconds(Player player) {
        long remaining = this.cooldownUntil.getOrDefault(player.getUniqueId(), 0L) - System.currentTimeMillis();
        return remaining <= 0L ? 0L : (remaining + 999L) / 1000L;
    }

    public void handleDeath(PlayerDeathEvent event) {
        Player player = event.getPlayer();
        RiftSession session = this.sessions.remove(player.getUniqueId());
        if (session != null) {
            session.finish(FinishReason.DEATH, false);
        }
    }

    public void handleResourcePackStatus(Player player, String statusName) {
        if (statusName.equals("DECLINED") || statusName.equals("DISCARDED") || statusName.startsWith("FAILED") || statusName.equals("INVALID_URL")) {
            this.cancel(player, FinishReason.RESOURCE_PACK_FAILURE, true);
        }
    }

    public void shutdown() {
        if (this.ticker != null) {
            this.ticker.cancel();
            this.ticker = null;
        }
        for (RiftSession session : new ArrayList<RiftSession>(this.sessions.values())) {
            session.finish(FinishReason.PLUGIN_DISABLE, true);
        }
        this.sessions.clear();
    }

    private void tick() {
        for (Map.Entry<UUID, RiftSession> entry : new ArrayList<Map.Entry<UUID, RiftSession>>(this.sessions.entrySet())) {
            RiftSession session = entry.getValue();
            try {
                if (!session.tick()) continue;
                this.sessions.remove(entry.getKey(), session);
            }
            catch (RuntimeException exception) {
                this.plugin.getLogger().log(Level.SEVERE, "Rift session crashed for " + String.valueOf(entry.getKey()), exception);
                session.finish(FinishReason.INTERNAL_ERROR, true);
                this.sessions.remove(entry.getKey(), session);
            }
        }
    }

    private Location comparisonAnchor(Player player) {
        World world = player.getWorld();
        return this.comparisonAnchors.computeIfAbsent(world.getUID(), ignored -> player.getLocation().clone()).clone();
    }

    public static enum StartResult {
        STARTED,
        ALREADY_ACTIVE,
        COOLDOWN,
        LIMIT_REACHED,
        PACK_NOT_LOADED,
        CAMERA_UNAVAILABLE,
        DEAD,
        INTERNAL_ERROR;

    }
}

