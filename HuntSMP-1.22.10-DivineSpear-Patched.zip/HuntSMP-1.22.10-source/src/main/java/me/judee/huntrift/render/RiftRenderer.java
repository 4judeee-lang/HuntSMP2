/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.render;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.SplittableRandom;
import me.judee.huntrift.render.DisplayPool;
import me.judee.huntrift.render.ParticleBudget;
import me.judee.huntrift.render.ScreenOverlayRenderer;
import me.judee.huntrift.rift.RiftFrame;
import me.judee.huntrift.rift.Vec3;
import me.judee.huntrift.util.Easing;
import me.judee.huntrift.util.TransformUtil;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public final class RiftRenderer {
    private static final int MAX_RUNES = 12;
    private static final int TRAIL_DISPLAYS = 8;
    private static final double GOLDEN_ANGLE = Math.PI * (3.0 - Math.sqrt(5.0));
    private final DisplayPool pool;
    private final ParticleBudget particles;
    private final ScreenOverlayRenderer overlay = new ScreenOverlayRenderer();
    private final Location anchor;
    private final Vector forward;
    private final Vector right;
    private final long seed;
    private final Deque<Location> trailHistory = new ArrayDeque<Location>();

    public RiftRenderer(JavaPlugin plugin, Location anchor, long seed) {
        int maxDisplays = plugin.getConfig().getInt("limits.maximum-displays-per-rift", 80);
        int maxParticles = plugin.getConfig().getInt("limits.maximum-particles-per-tick-per-rift", 450);
        int viewingDistance = plugin.getConfig().getInt("limits.viewing-distance", 96);
        this.pool = new DisplayPool(plugin, maxDisplays, viewingDistance);
        this.particles = new ParticleBudget(maxParticles, viewingDistance);
        this.anchor = anchor.clone();
        this.forward = RiftRenderer.horizontalDirection(anchor);
        this.right = new Vector(-this.forward.getZ(), 0.0, this.forward.getX());
        this.seed = seed;
    }

    public void render(Player player, RiftFrame frame) {
        this.particles.beginTick();
        this.renderShockwave(player, frame);
        this.renderRunes(player, frame);
        this.renderDiamonds(player, frame);
        this.renderLaunchTrail(player, frame);
        this.renderAfterglow(player, frame);
        this.renderParticleAccents(player, frame);
        this.overlay.render(player, frame.overlayFrame());
    }

    private void renderShockwave(Player player, RiftFrame frame) {
        if (!(frame.shockwaveOpacity() <= 0.001) && !(frame.shockwaveRadius() <= 0.001)) {
            Location location = player.getLocation().add(0.0, -1.05, 0.0);
            ItemDisplay ring = this.pool.acquire("shockwave_ring", "shockwave_ring", location, Display.Billboard.FIXED);
            ItemDisplay bloom = this.pool.acquire("shockwave_bloom", "shockwave_bloom", location.clone().add(0.0, 0.025, 0.0), Display.Billboard.FIXED);
            ring.teleport(location);
            bloom.teleport(location.clone().add(0.0, 0.025, 0.0));
            TransformUtil.applyHorizontal(ring, frame.shockwaveRadius() * 2.0, frame.referenceSeconds() * 18.0);
            TransformUtil.applyHorizontal(bloom, frame.shockwaveRadius() * 2.0 * 1.18, -frame.referenceSeconds() * 11.0);
        } else {
            this.pool.remove("shockwave_ring");
            this.pool.remove("shockwave_bloom");
        }
    }

    private void renderRunes(Player player, RiftFrame frame) {
        int visible = Math.min(12, frame.runeCount());
        double sequenceSeconds = frame.soundPlaybackSeconds();
        for (int index = 0; index < 12; ++index) {
            String role = "rune_" + index;
            if (index >= visible) {
                ItemDisplay hidden = this.pool.get(role);
                if (hidden == null) continue;
                TransformUtil.hide(hidden);
                continue;
            }
            double direction = (index & 1) == 0 ? 1.0 : -1.0;
            double angle = (double)index * GOLDEN_ANGLE + sequenceSeconds * (0.42 + (double)index * 0.018) * direction;
            double radius = 5.4 + (double)(index % 3) * 1.35 + Math.sin(sequenceSeconds * 3.4 + (double)index * 1.7) * 0.4;
            double horizontal = Math.cos(angle) * radius;
            double vertical = 1.15 + Math.sin(angle) * radius * 0.68;
            double depth = -1.8 + (double)(index % 3) * 1.15 + Math.sin(sequenceSeconds * 2.1 + (double)index) * 0.35;
            Vec3 offset = new Vec3(horizontal, vertical, depth);
            Location location = this.localToWorld(player.getLocation(), offset);
            ItemDisplay rune = this.pool.acquire(role, "rune_" + index % 8, location, Display.Billboard.CENTER);
            rune.teleport(location);
            double appear = Easing.smoothStep(Easing.range(sequenceSeconds, 0.0, 0.18));
            double fade = 1.0 - Easing.smoothStep(Easing.range(sequenceSeconds, 2.55, 3.133));
            double livePulse = 0.88 + Math.sin(sequenceSeconds * 8.0 + (double)index * 0.83) * 0.12;
            double scale = (2.1 + (double)(index % 4) * 0.62) * Math.max(0.03, appear * fade) * livePulse;
            double roll = Math.toDegrees(angle) + (double)index * 23.0 + sequenceSeconds * (index % 2 == 0 ? 72.0 : -58.0);
            TransformUtil.applyBillboard(rune, scale, scale, roll);
        }
    }

    private void renderDiamonds(Player player, RiftFrame frame) {
        double seconds = frame.soundPlaybackSeconds();
        int count = Math.min(14, Math.max(0, frame.particleCount() / 14));
        for (int index = 0; index < 14; ++index) {
            String role = "diamond_" + index;
            if (index >= count || seconds >= 3.133) {
                ItemDisplay display = this.pool.get(role);
                if (display == null) continue;
                TransformUtil.hide(display);
                continue;
            }
            double angle = (double)index * GOLDEN_ANGLE + seconds * (0.55 + (double)(index % 3) * 0.08);
            double radius = 2.2 + (double)(index % 5) * 0.72;
            Vec3 offset = new Vec3(Math.cos(angle) * radius, 0.7 + Math.sin(angle * 1.4) * 3.2, -0.4 + Math.sin(angle) * radius * 0.45);
            Location location = this.localToWorld(player.getLocation(), offset);
            ItemDisplay display = this.pool.acquire(role, "diamond_spark", location, Display.Billboard.CENTER);
            display.teleport(location);
            double pulse = 0.72 + 0.25 * Math.sin(seconds * 9.0 + (double)index);
            TransformUtil.applyBillboard(display, pulse, pulse, 45.0 + seconds * 25.0 * (index % 2 == 0 ? 1.0 : -1.0));
        }
    }

    private void renderLaunchTrail(Player player, RiftFrame frame) {
        if (frame.trailOpacity() <= 0.001) {
            for (int index = 0; index < 8; ++index) {
                ItemDisplay display = this.pool.get("trail_" + index);
                if (display == null) continue;
                TransformUtil.hide(display);
            }
        } else {
            this.trailHistory.addFirst(player.getLocation().add(0.0, 0.9, 0.0));
            while (this.trailHistory.size() > 32) {
                this.trailHistory.removeLast();
            }
            ArrayList<Location> history = new ArrayList<Location>(this.trailHistory);
            for (int index = 0; index < 8; ++index) {
                int historyIndex = Math.min(history.size() - 1, index * 3);
                Location location = (Location)history.get(historyIndex);
                String model = index < 3 ? "launch_streak" : (index < 6 ? "smoke_dark" : "afterglow_haze");
                ItemDisplay trail = this.pool.acquire("trail_" + index, model, location, Display.Billboard.CENTER);
                trail.teleport(location);
                double scale = Math.max(0.1, (4.8 - (double)index * 0.44) * frame.trailOpacity());
                double stretch = index < 3 ? 2.2 : 1.0;
                TransformUtil.applyBillboard(trail, scale * 0.72, scale * stretch, (double)index * 31.0 + frame.referenceSeconds() * 48.0);
            }
        }
    }

    private void renderAfterglow(Player player, RiftFrame frame) {
        double strength = Math.max(frame.overlayOpacity() - 0.03, 0.0);
        if (!(frame.referenceSeconds() < 1.1) && !(strength <= 0.001)) {
            Location location = player.getLocation().add(0.0, 1.2, 0.0).subtract(this.forward.clone().multiply(1.8));
            ItemDisplay haze = this.pool.acquire("world_haze", "world_haze", location, Display.Billboard.CENTER);
            haze.teleport(location);
            double scale = 7.0 + strength * 11.0;
            TransformUtil.applyBillboard(haze, scale * 1.7, scale, frame.referenceSeconds() * -7.0);
        } else {
            ItemDisplay haze = this.pool.get("world_haze");
            if (haze != null) {
                TransformUtil.hide(haze);
            }
        }
    }

    private void renderParticleAccents(Player player, RiftFrame frame) {
        int requested = frame.particleCount();
        if (requested > 0) {
            Location center = player.getLocation().add(0.0, 1.0, 0.0);
            double sequenceSeconds = frame.soundPlaybackSeconds();
            double spread = sequenceSeconds < 0.1 ? 5.5 : (sequenceSeconds < 1.1 ? 11.5 : (sequenceSeconds < 2.2 ? 9.0 : 6.5));
            int stars = (int)Math.round((double)requested * 0.34);
            int rods = (int)Math.round((double)requested * 0.16);
            int dust = requested - stars - rods;
            this.particles.spawnSimple(center, Particle.FIREWORK, stars, spread, spread * 0.75, spread, 0.035);
            this.particles.spawnSimple(center, Particle.END_ROD, rods, spread * 0.55, spread, spread * 0.55, 0.025);
            this.particles.spawnGoldDust(center, dust, spread, spread, spread, 1.25f);
            SplittableRandom random = new SplittableRandom(this.seed ^ (long)frame.referenceFrame() * -7046029254386353131L);
            int deterministic = this.particles.reserve(Math.min(18, requested / 8));
            for (int index = 0; index < deterministic; ++index) {
                double angle = random.nextDouble(0.0, Math.PI * 2);
                double radius = random.nextDouble(0.4, Math.max(0.5, spread));
                Location spark = center.clone().add(Math.cos(angle) * radius, random.nextDouble(-spread, spread), Math.sin(angle) * radius);
                for (Player viewer : center.getWorld().getPlayers()) {
                    if (!(viewer.getLocation().distanceSquared(center) <= 9216.0)) continue;
                    viewer.spawnParticle(Particle.ELECTRIC_SPARK, spark, 1, 0.0, 0.0, 0.0, 0.0);
                }
            }
        }
    }

    public int activeDisplayCount() {
        return this.pool.size();
    }

    public int particlesThisTick() {
        return this.particles.used();
    }

    public Location riftLocation(RiftFrame frame) {
        return this.localToWorld(this.anchor, frame.riftOffset());
    }

    public void cleanup(Player player) {
        this.overlay.clear(player);
        this.pool.removeAll();
        this.trailHistory.clear();
    }

    private Location localToWorld(Location origin, Vec3 local) {
        return origin.clone().add(this.right.clone().multiply(local.x())).add(0.0, local.y(), 0.0).add(this.forward.clone().multiply(local.z()));
    }

    private static Vector horizontalDirection(Location location) {
        Vector direction = location.getDirection().setY(0.0);
        return direction.lengthSquared() < 1.0E-6 ? new Vector(0.0, 0.0, 1.0) : direction.normalize();
    }
}

