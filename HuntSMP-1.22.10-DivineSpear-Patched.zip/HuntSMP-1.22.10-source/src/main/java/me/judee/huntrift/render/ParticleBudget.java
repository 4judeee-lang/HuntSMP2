/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.render;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;

public final class ParticleBudget {
    private final int maximumPerTick;
    private final double viewingDistanceSquared;
    private int used;

    public ParticleBudget(int maximumPerTick, int viewingDistance) {
        this.maximumPerTick = Math.max(0, maximumPerTick);
        this.viewingDistanceSquared = (double)viewingDistance * (double)viewingDistance;
    }

    public void beginTick() {
        this.used = 0;
    }

    public int used() {
        return this.used;
    }

    public int reserve(int requested) {
        int granted = Math.max(0, Math.min(requested, this.maximumPerTick - this.used));
        this.used += granted;
        return granted;
    }

    public void spawnSimple(Location location, Particle particle, int requested, double offsetX, double offsetY, double offsetZ, double extra) {
        int count = this.reserve(requested);
        if (count > 0) {
            for (Player viewer : location.getWorld().getPlayers()) {
                if (!(viewer.getLocation().distanceSquared(location) <= this.viewingDistanceSquared)) continue;
                viewer.spawnParticle(particle, location, count, offsetX, offsetY, offsetZ, extra);
            }
        }
    }

    public void spawnGoldDust(Location location, int requested, double offsetX, double offsetY, double offsetZ, float size) {
        int count = this.reserve(requested);
        if (count > 0) {
            Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB((int)255, (int)232, (int)158), size);
            for (Player viewer : location.getWorld().getPlayers()) {
                if (!(viewer.getLocation().distanceSquared(location) <= this.viewingDistanceSquared)) continue;
                viewer.spawnParticle(Particle.DUST, location, count, offsetX, offsetY, offsetZ, 0.0, (Object)dust);
            }
        }
    }
}

