/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.rift;

import java.util.Locale;
import java.util.UUID;
import java.util.function.Consumer;
import me.judee.huntrift.audio.AudioController;
import me.judee.huntrift.camera.CameraController;
import me.judee.huntrift.camera.ProtocolCameraBridge;
import me.judee.huntrift.glide.GlideController;
import me.judee.huntrift.render.RiftRenderer;
import me.judee.huntrift.rift.ChunkTicketSet;
import me.judee.huntrift.rift.FinishReason;
import me.judee.huntrift.rift.PlayerStateSnapshot;
import me.judee.huntrift.rift.RiftFrame;
import me.judee.huntrift.rift.RiftPhase;
import me.judee.huntrift.rift.RiftTimeline;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public final class RiftSession {
    private final JavaPlugin plugin;
    private final UUID playerId;
    private final Location anchor;
    private final Vector forward;
    private final PlayerStateSnapshot snapshot;
    private final RiftTimeline timeline;
    private final RiftRenderer renderer;
    private final CameraController camera;
    private final AudioController audio;
    private final GlideController glide;
    private final ChunkTicketSet chunkTickets;
    private final long startNano;
    private final double startSequenceSeconds;
    private final double endSequenceSeconds;
    private final long masterOffsetMilliseconds;
    private final long impactOffsetMilliseconds;
    private final long launchOffsetMilliseconds;
    private final long glideOffsetMilliseconds;
    private final int debugChatInterval;
    private final Consumer<Player> cinematicCompleteCallback;
    private boolean applyingMotion;
    private boolean cinematicComplete;
    private boolean finished;
    private boolean debugEnabled;
    private int serverTicks;
    private RiftFrame lastFrame;
    private FinishReason finishReason;

    public RiftSession(JavaPlugin plugin, Player player, ProtocolCameraBridge bridge, Location requestedAnchor, RiftPhase previewPhase, Consumer<Player> cinematicCompleteCallback) {
        this.plugin = plugin;
        this.playerId = player.getUniqueId();
        this.anchor = requestedAnchor.clone();
        this.forward = RiftSession.horizontalDirection(this.anchor);
        this.snapshot = PlayerStateSnapshot.capture(player);
        double configuredHeight = plugin.getConfig().getDouble("rift.launch-height", 250.0);
        double forwardDistance = plugin.getConfig().getDouble("rift.launch-forward-distance", 12.0);
        this.timeline = new RiftTimeline(configuredHeight, forwardDistance);
        long seed = plugin.getConfig().getLong("rift.deterministic-seed", 1247108165L);
        this.renderer = new RiftRenderer(plugin, this.anchor, seed);
        this.camera = new CameraController(plugin, bridge, this.anchor);
        this.startSequenceSeconds = previewPhase == null ? 0.0 : previewPhase.startSeconds();
        this.endSequenceSeconds = previewPhase == null ? 4.666667 : previewPhase.endSeconds();
        String audioKey = previewPhase == null ? "hunt:rift_sequence" : "";
        this.audio = new AudioController(plugin.getConfig().getLong("timing.audio-offset-milliseconds", 0L), 1.0f, audioKey);
        this.glide = new GlideController(plugin, this.forward);
        this.chunkTickets = new ChunkTicketSet(plugin);
        this.masterOffsetMilliseconds = plugin.getConfig().getLong("timing.master-offset-milliseconds", 0L);
        this.impactOffsetMilliseconds = plugin.getConfig().getLong("timing.impact-offset-milliseconds", 0L);
        this.launchOffsetMilliseconds = plugin.getConfig().getLong("timing.launch-offset-milliseconds", 0L);
        this.glideOffsetMilliseconds = plugin.getConfig().getLong("timing.glide-offset-milliseconds", 0L);
        this.debugChatInterval = Math.max(1, plugin.getConfig().getInt("debug.chat-update-interval-ticks", 20));
        this.cinematicCompleteCallback = cinematicCompleteCallback;
        this.startNano = System.nanoTime();
        try {
            this.begin(player);
        }
        catch (RuntimeException exception) {
            this.renderer.cleanup(player);
            this.camera.restore(player);
            this.audio.stop(player);
            this.chunkTickets.release();
            this.snapshot.restoreAll(player, true);
            throw exception;
        }
    }

    public UUID playerId() {
        return this.playerId;
    }

    public boolean tick() {
        if (this.finished) {
            return true;
        }
        Player player = this.plugin.getServer().getPlayer(this.playerId);
        if (player != null && player.isOnline()) {
            ++this.serverTicks;
            if (!this.cinematicComplete) {
                double realElapsed = (double)(System.nanoTime() - this.startNano) / 1.0E9;
                double sequenceSeconds = this.startSequenceSeconds + realElapsed + (double)this.masterOffsetMilliseconds / 1000.0;
                sequenceSeconds = Math.max(this.startSequenceSeconds, sequenceSeconds);
                RiftFrame masterFrame = this.timeline.sample(sequenceSeconds);
                RiftFrame visualFrame = this.timeline.sample(sequenceSeconds - (double)this.impactOffsetMilliseconds / 1000.0);
                RiftFrame motionFrame = this.timeline.sample(sequenceSeconds - (double)this.launchOffsetMilliseconds / 1000.0);
                this.lastFrame = masterFrame;
                this.audio.tick(player, sequenceSeconds - this.startSequenceSeconds);
                this.applyControlledMotion(player, motionFrame);
                this.camera.update(player, masterFrame);
                this.renderer.render(player, visualFrame);
                double glideAt = 2.833 + (double)this.glideOffsetMilliseconds / 1000.0;
                if (!this.glide.isActive() && sequenceSeconds >= glideAt) {
                    this.beginGlide(player);
                }
                if (this.glide.isActive()) {
                    this.glide.tick(player);
                }
                if (this.debugEnabled) {
                    this.sendDebug(player, masterFrame);
                }
                if (sequenceSeconds >= this.endSequenceSeconds) {
                    this.completeCinematic(player);
                }
                return false;
            }
            if (this.glide.isActive() && !this.glide.tick(player)) {
                return false;
            }
            this.finish(FinishReason.SUCCESS, false);
            return true;
        }
        this.finish(FinishReason.QUIT, false);
        return true;
    }

    private void begin(Player player) {
        int chunkRadius = this.plugin.getConfig().getInt("limits.chunk-ticket-radius", 1);
        this.chunkTickets.acquire(this.anchor, chunkRadius);
        Location destination = this.anchor.clone().add(0.0, this.plugin.getConfig().getDouble("rift.launch-height", 250.0), 0.0);
        this.chunkTickets.acquire(destination, chunkRadius);
        player.setInvulnerable(true);
        player.setCollidable(false);
        player.setGravity(false);
        player.setGliding(false);
        player.setFallDistance(0.0f);
        this.teleportInternally(player, destination);
        player.setVelocity(new Vector());
    }

    private void applyControlledMotion(Player player, RiftFrame frame) {
        if (!this.glide.isActive()) {
            Location target = this.anchor.clone().add(this.forward.clone().multiply(frame.playerForward())).add(0.0, frame.playerHeight(), 0.0);
            target.setYaw(this.anchor.getYaw() + (float)frame.playerYawOffset());
            target.setPitch(this.anchor.getPitch());
            this.teleportInternally(player, target);
            player.setVelocity(this.forward.clone().multiply(frame.forwardVelocityPerTick()).setY(frame.verticalVelocityPerTick()));
            player.setFallDistance(0.0f);
        }
    }

    private void beginGlide(Player player) {
        this.snapshot.restoreForGlide(player);
        this.glide.begin(player);
    }

    private void completeCinematic(Player player) {
        if (!this.cinematicComplete) {
            this.cinematicComplete = true;
            this.renderer.cleanup(player);
            this.camera.restore(player);
            this.audio.stop(player);
            if (!this.glide.isActive()) {
                this.beginGlide(player);
            }
            if (this.cinematicCompleteCallback != null) {
                this.cinematicCompleteCallback.accept(player);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void finish(FinishReason reason, boolean restoreOriginalPosition) {
        if (!this.finished) {
            this.finished = true;
            this.finishReason = reason;
            Player player = this.plugin.getServer().getPlayer(this.playerId);
            if (player != null) {
                this.renderer.cleanup(player);
                this.camera.restore(player);
                this.audio.stop(player);
                this.glide.restore(player);
                if (reason != FinishReason.SUCCESS && reason != FinishReason.DEATH) {
                    this.applyingMotion = true;
                    try {
                        this.snapshot.restoreAll(player, restoreOriginalPosition);
                    }
                    finally {
                        this.applyingMotion = false;
                    }
                } else if (reason == FinishReason.SUCCESS) {
                    this.snapshot.restoreFlagsOnly(player);
                }
            }
            this.chunkTickets.release();
        }
    }

    public FinishReason finishReason() {
        return this.finishReason;
    }

    public boolean isMovementLocked() {
        return !this.finished && !this.glide.isActive();
    }

    public boolean isApplyingMotion() {
        return this.applyingMotion;
    }

    public boolean shouldBlockInventory() {
        return !this.finished && this.isMovementLocked();
    }

    public boolean shouldForceGlide() {
        return this.glide.shouldForceGlide();
    }

    public boolean shouldPreventDamage(EntityDamageEvent.DamageCause cause) {
        return this.finished ? false : !this.glide.isActive() || cause == EntityDamageEvent.DamageCause.FALL || cause == EntityDamageEvent.DamageCause.FLY_INTO_WALL;
    }

    public void toggleDebug(Player requester) {
        this.debugEnabled = !this.debugEnabled;
        requester.sendMessage((Component)Component.text((String)("HuntRift debug " + (this.debugEnabled ? "enabled" : "disabled") + " for " + String.valueOf(this.playerId)), (TextColor)(this.debugEnabled ? NamedTextColor.GREEN : NamedTextColor.YELLOW)));
    }

    public boolean debugEnabled() {
        return this.debugEnabled;
    }

    private void sendDebug(Player player, RiftFrame frame) {
        player.sendActionBar((Component)Component.text((String)String.format(Locale.ROOT, "Rift f=%d  ref=%.3fs  tick=%d+%.2f  %s", frame.referenceFrame(), frame.referenceSeconds(), frame.minecraftTick(), frame.subTickProgress(), frame.phase().id()), (TextColor)NamedTextColor.GOLD));
        if (this.serverTicks % this.debugChatInterval == 0) {
            Location cameraLocation = this.camera.cameraLocation();
            String cameraText = cameraLocation == null ? "first-person" : RiftSession.formatLocation(cameraLocation);
            player.sendMessage((Component)Component.text((String)String.format(Locale.ROOT, "[HuntRift] ref=%.3fs sourceFrame=%d serverTick=%d phase=%s audio=%.3fs%nplayer=%s velocity=%s camera=%s%nrift=disabled shockwave=%.2f overlay=%.2f displays=%d particles=%d", frame.referenceSeconds(), frame.referenceFrame(), this.serverTicks, frame.phase().id(), this.audio.playbackOffsetSeconds(frame.soundPlaybackSeconds()), RiftSession.formatLocation(player.getLocation()), RiftSession.formatVector(player.getVelocity()), cameraText, frame.shockwaveRadius(), frame.overlayOpacity(), this.renderer.activeDisplayCount(), this.renderer.particlesThisTick()), (TextColor)NamedTextColor.GRAY));
        }
    }

    private void teleportInternally(Player player, Location location) {
        this.applyingMotion = true;
        try {
            if (!player.teleport(location, PlayerTeleportEvent.TeleportCause.PLUGIN)) {
                throw new IllegalStateException("Paper rejected the controlled rift teleport to " + RiftSession.formatLocation(location));
            }
        }
        finally {
            this.applyingMotion = false;
        }
    }

    private static Vector horizontalDirection(Location location) {
        Vector result = location.getDirection().setY(0.0);
        return result.lengthSquared() < 1.0E-6 ? new Vector(0.0, 0.0, 1.0) : result.normalize();
    }

    private static String formatLocation(Location location) {
        return String.format(Locale.ROOT, "%.2f,%.2f,%.2f/%.1f,%.1f", location.getX(), location.getY(), location.getZ(), Float.valueOf(location.getYaw()), Float.valueOf(location.getPitch()));
    }

    private static String formatVector(Vector vector) {
        return String.format(Locale.ROOT, "%.3f,%.3f,%.3f", vector.getX(), vector.getY(), vector.getZ());
    }
}

