/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.rift;

public enum FinishReason {
    SUCCESS,
    CANCELLED,
    QUIT,
    DEATH,
    WORLD_CHANGE,
    RESOURCE_PACK_FAILURE,
    PLUGIN_DISABLE,
    INTERNAL_ERROR;

}

