/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.util;

public final class Easing {
    private Easing() {
    }

    public static double clamp01(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }

    public static double lerp(double start, double end, double progress) {
        return start + (end - start) * Easing.clamp01(progress);
    }

    public static double smoothStep(double progress) {
        double p = Easing.clamp01(progress);
        return p * p * (3.0 - 2.0 * p);
    }

    public static double smootherStep(double progress) {
        double p = Easing.clamp01(progress);
        return p * p * p * (p * (p * 6.0 - 15.0) + 10.0);
    }

    public static double easeOutCubic(double progress) {
        double p = 1.0 - Easing.clamp01(progress);
        return 1.0 - p * p * p;
    }

    public static double easeInOutCubic(double progress) {
        double p = Easing.clamp01(progress);
        return p < 0.5 ? 4.0 * p * p * p : 1.0 - Math.pow(-2.0 * p + 2.0, 3.0) / 2.0;
    }

    public static double range(double value, double start, double end) {
        if (end <= start) {
            return value >= end ? 1.0 : 0.0;
        }
        return Easing.clamp01((value - start) / (end - start));
    }
}

