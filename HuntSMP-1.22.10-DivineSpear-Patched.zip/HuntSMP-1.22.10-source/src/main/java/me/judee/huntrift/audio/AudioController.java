/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.audio;

import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;

public final class AudioController {
    private final long offsetMilliseconds;
    private final float volume;
    private final String soundKey;
    private boolean started;
    private double startSequenceSeconds;

    public AudioController(long offsetMilliseconds, float volume, String soundKey) {
        this.offsetMilliseconds = offsetMilliseconds;
        this.volume = volume;
        this.soundKey = soundKey;
    }

    public void tick(Player player, double sequenceSeconds) {
        if (!(this.soundKey.isBlank() || this.started || sequenceSeconds * 1000.0 < (double)Math.max(0L, this.offsetMilliseconds))) {
            player.playSound(player.getLocation(), this.soundKey, SoundCategory.MASTER, this.volume, 1.0f);
            this.started = true;
            this.startSequenceSeconds = sequenceSeconds;
        }
    }

    public double playbackOffsetSeconds(double sequenceSeconds) {
        return this.started ? Math.max(0.0, sequenceSeconds - this.startSequenceSeconds) : 0.0;
    }

    public void stop(Player player) {
        if (this.started && !this.soundKey.isBlank()) {
            player.stopSound(this.soundKey, SoundCategory.MASTER);
            this.started = false;
        }
    }
}

