/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.glide;

import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public final class GlideController {
    private final Vector forward;
    private final double forwardSpeed;
    private final double downwardSpeed;
    private final int maximumTicks;
    private boolean active;
    private boolean restored;
    private int age;

    public GlideController(JavaPlugin plugin, Vector forward) {
        this.forward = forward.clone().setY(0.0).normalize();
        this.forwardSpeed = plugin.getConfig().getDouble("rift.glide-forward-speed", 1.65);
        this.downwardSpeed = plugin.getConfig().getDouble("rift.glide-downward-speed", -0.28);
        this.maximumTicks = Math.max(20, plugin.getConfig().getInt("rift.maximum-glide-seconds", 60) * 20);
    }

    public void begin(Player player) {
        if (!this.active) {
            player.setGravity(true);
            player.setFallDistance(0.0f);
            player.setVelocity(this.forward.clone().multiply(this.forwardSpeed).setY(this.downwardSpeed));
            this.active = true;
            player.setGliding(true);
        }
    }

    public boolean tick(Player player) {
        if (!this.active) {
            return false;
        }
        ++this.age;
        player.setFallDistance(0.0f);
        if (!(this.age > 20 && GlideController.isNearGround(player) || this.age >= this.maximumTicks)) {
            if (!player.isGliding()) {
                player.setGliding(true);
            }
            return false;
        }
        this.restore(player);
        return true;
    }

    public boolean shouldForceGlide() {
        return this.active;
    }

    public boolean isActive() {
        return this.active;
    }

    public void restore(Player player) {
        if (!this.restored) {
            this.active = false;
            player.setGliding(false);
            player.setFallDistance(0.0f);
            this.restored = true;
        }
    }

    private static boolean isNearGround(Player player) {
        Location feet = player.getLocation().add(0.0, 0.1, 0.0);
        return player.getWorld().rayTraceBlocks(feet, new Vector(0.0, -1.0, 0.0), 0.45, FluidCollisionMode.NEVER, true) != null;
    }
}

