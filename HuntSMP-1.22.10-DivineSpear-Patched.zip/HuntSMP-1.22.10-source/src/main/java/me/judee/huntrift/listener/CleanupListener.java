/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.listener;

import me.judee.huntrift.resource.ResourcePackService;
import me.judee.huntrift.rift.FinishReason;
import me.judee.huntrift.rift.RiftManager;
import me.judee.huntrift.rift.RiftSession;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public final class CleanupListener
implements Listener {
    private final RiftManager manager;
    private final ResourcePackService resourcePacks;

    public CleanupListener(RiftManager manager, ResourcePackService resourcePacks) {
        this.manager = manager;
        this.resourcePacks = resourcePacks;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.resourcePacks.sendLater(event.getPlayer());
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        this.manager.cancel(event.getPlayer(), FinishReason.QUIT, false);
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        this.manager.handleDeath(event);
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onWorldChange(PlayerChangedWorldEvent event) {
        this.manager.cancel(event.getPlayer(), FinishReason.WORLD_CHANGE, false);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onTeleport(PlayerTeleportEvent event) {
        RiftSession session = this.manager.session(event.getPlayer());
        if (session != null && session.isMovementLocked() && !session.isApplyingMotion()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onInventoryClick(InventoryClickEvent event) {
        Player player;
        RiftSession session;
        HumanEntity humanEntity = event.getWhoClicked();
        if (humanEntity instanceof Player && (session = this.manager.session(player = (Player)humanEntity)) != null && session.shouldBlockInventory()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onInventoryDrag(InventoryDragEvent event) {
        Player player;
        RiftSession session;
        HumanEntity humanEntity = event.getWhoClicked();
        if (humanEntity instanceof Player && (session = this.manager.session(player = (Player)humanEntity)) != null && session.shouldBlockInventory()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onDrop(PlayerDropItemEvent event) {
        RiftSession session = this.manager.session(event.getPlayer());
        if (session != null && session.shouldBlockInventory()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        RiftSession session = this.manager.session(event.getPlayer());
        if (session != null && session.shouldBlockInventory()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onPickup(EntityPickupItemEvent event) {
        Player player;
        RiftSession session;
        LivingEntity livingEntity = event.getEntity();
        if (livingEntity instanceof Player && (session = this.manager.session(player = (Player)livingEntity)) != null && session.isMovementLocked()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onDamage(EntityDamageEvent event) {
        Player player;
        RiftSession session;
        Entity entity = event.getEntity();
        if (entity instanceof Player && (session = this.manager.session(player = (Player)entity)) != null && session.shouldPreventDamage(event.getCause())) {
            event.setCancelled(true);
            player.setFallDistance(0.0f);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onToggleGlide(EntityToggleGlideEvent event) {
        Entity entity = event.getEntity();
        if (entity instanceof Player) {
            RiftSession session;
            Player player = (Player)entity;
            if (!event.isGliding() && (session = this.manager.session(player)) != null && session.shouldForceGlide()) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onPackStatus(PlayerResourcePackStatusEvent event) {
        this.resourcePacks.handleStatus(event.getPlayer(), event.getStatus());
        this.manager.handleResourcePackStatus(event.getPlayer(), event.getStatus().name());
    }
}

