/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.camera;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class ProtocolCameraBridge {
    private final JavaPlugin plugin;
    private final ProtocolManager manager;
    private final boolean available;
    private boolean warned;

    public ProtocolCameraBridge(JavaPlugin plugin) {
        this.plugin = plugin;
        ProtocolManager detected = null;
        boolean ready = false;
        try {
            Plugin protocolLib = plugin.getServer().getPluginManager().getPlugin("ProtocolLib");
            if (protocolLib != null && protocolLib.isEnabled()) {
                detected = ProtocolLibrary.getProtocolManager();
                ready = detected != null;
            }
        }
        catch (LinkageError | RuntimeException exception) {
            plugin.getLogger().severe("ProtocolLib 5.4.0 camera initialization failed: " + exception.getMessage());
        }
        this.manager = detected;
        this.available = ready;
    }

    public boolean isAvailable() {
        return this.available;
    }

    public boolean setCamera(Player player, Entity target) {
        if (!this.available || this.manager == null || target == null || !target.isValid()) {
            return false;
        }
        try {
            PacketContainer packet = this.manager.createPacket(PacketType.Play.Server.CAMERA);
            packet.getIntegers().write(0, (Object)target.getEntityId());
            this.manager.sendServerPacket(player, packet);
            return true;
        }
        catch (Exception | LinkageError exception) {
            if (!this.warned) {
                this.plugin.getLogger().severe("ProtocolLib camera packet failed: " + exception.getMessage());
                this.warned = true;
            }
            return false;
        }
    }
}

