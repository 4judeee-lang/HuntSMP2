/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.rift;

import me.judee.huntrift.rift.RiftPhase;
import me.judee.huntrift.rift.Vec3;

public record RiftFrame(double referenceSeconds, int referenceFrame, int minecraftTick, double subTickProgress, RiftPhase phase, Vec3 riftOffset, double riftRotationDegrees, double riftScaleX, double riftScaleY, double riftBrightness, double riftGlowScale, Vec3 cameraOffset, double cameraShake, double playerHeight, double playerForward, double playerYawOffset, double verticalVelocityPerTick, double forwardVelocityPerTick, double shockwaveRadius, double shockwaveOpacity, double overlayOpacity, int overlayFrame, int runeCount, int particleCount, double trailOpacity, double soundPlaybackSeconds) {
}

