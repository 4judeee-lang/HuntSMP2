/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.rift;

import java.util.LinkedHashSet;
import java.util.Set;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class ChunkTicketSet {
    private final JavaPlugin plugin;
    private final Set<Chunk> chunks = new LinkedHashSet<Chunk>();

    public ChunkTicketSet(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void acquire(Location location, int radius) {
        World world = location.getWorld();
        int centerX = location.getBlockX() >> 4;
        int centerZ = location.getBlockZ() >> 4;
        int safeRadius = Math.max(0, Math.min(2, radius));
        for (int x = centerX - safeRadius; x <= centerX + safeRadius; ++x) {
            for (int z = centerZ - safeRadius; z <= centerZ + safeRadius; ++z) {
                if (!world.isChunkGenerated(x, z)) continue;
                Chunk chunk = world.getChunkAt(x, z);
                chunk.addPluginChunkTicket((Plugin)this.plugin);
                this.chunks.add(chunk);
            }
        }
    }

    public void release() {
        for (Chunk chunk : this.chunks) {
            if (!chunk.isLoaded()) continue;
            chunk.removePluginChunkTicket((Plugin)this.plugin);
        }
        this.chunks.clear();
    }
}

