/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.rift;

import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.util.Vector;

public final class PlayerStateSnapshot {
    private final Location location;
    private final Vector velocity;
    private final GameMode gameMode;
    private final boolean allowFlight;
    private final boolean flying;
    private final boolean gliding;
    private final boolean gravity;
    private final boolean invulnerable;
    private final boolean collidable;
    private final float fallDistance;
    private final int heldSlot;
    private final ItemStack[] storageContents;
    private final ItemStack[] armorContents;
    private final ItemStack[] extraContents;
    private final UUID spectatorTarget;

    private PlayerStateSnapshot(Player player) {
        PlayerInventory inventory = player.getInventory();
        this.location = player.getLocation().clone();
        this.velocity = player.getVelocity().clone();
        this.gameMode = player.getGameMode();
        this.allowFlight = player.getAllowFlight();
        this.flying = player.isFlying();
        this.gliding = player.isGliding();
        this.gravity = player.hasGravity();
        this.invulnerable = player.isInvulnerable();
        this.collidable = player.isCollidable();
        this.fallDistance = player.getFallDistance();
        this.heldSlot = inventory.getHeldItemSlot();
        this.storageContents = PlayerStateSnapshot.cloneItems(inventory.getStorageContents());
        this.armorContents = PlayerStateSnapshot.cloneItems(inventory.getArmorContents());
        this.extraContents = PlayerStateSnapshot.cloneItems(inventory.getExtraContents());
        Entity target = player.getSpectatorTarget();
        this.spectatorTarget = target == null ? null : target.getUniqueId();
    }

    public static PlayerStateSnapshot capture(Player player) {
        return new PlayerStateSnapshot(player);
    }

    public Location originalLocation() {
        return this.location.clone();
    }

    public Vector originalVelocity() {
        return this.velocity.clone();
    }

    public void restoreAll(Player player, boolean restorePosition) {
        this.restoreInventory(player);
        this.restoreFlags(player);
        if (restorePosition && this.location.getWorld() != null) {
            player.teleport(this.location, PlayerTeleportEvent.TeleportCause.PLUGIN);
            player.setVelocity(this.velocity);
        }
        this.restoreSpectatorTarget(player);
    }

    public void restoreForGlide(Player player) {
        this.restoreFlags(player);
        player.setFallDistance(0.0f);
    }

    public void restoreFlagsOnly(Player player) {
        this.restoreFlags(player);
        this.restoreSpectatorTarget(player);
    }

    private void restoreInventory(Player player) {
        PlayerInventory inventory = player.getInventory();
        inventory.setStorageContents(PlayerStateSnapshot.cloneItems(this.storageContents));
        inventory.setArmorContents(PlayerStateSnapshot.cloneItems(this.armorContents));
        inventory.setExtraContents(PlayerStateSnapshot.cloneItems(this.extraContents));
        inventory.setHeldItemSlot(this.heldSlot);
    }

    private void restoreFlags(Player player) {
        player.setGameMode(this.gameMode);
        player.setAllowFlight(this.allowFlight);
        player.setFlying(this.flying && this.allowFlight);
        player.setGravity(this.gravity);
        player.setInvulnerable(this.invulnerable);
        player.setCollidable(this.collidable);
        player.setFallDistance(this.fallDistance);
        player.setGliding(this.gliding);
    }

    private void restoreSpectatorTarget(Player player) {
        Entity entity;
        if (this.gameMode == GameMode.SPECTATOR && this.spectatorTarget != null && (entity = Bukkit.getEntity((UUID)this.spectatorTarget)) != null && entity.isValid()) {
            player.setSpectatorTarget(entity);
        }
    }

    private static ItemStack[] cloneItems(ItemStack[] source) {
        ItemStack[] result = new ItemStack[source.length];
        for (int index = 0; index < source.length; ++index) {
            result[index] = source[index] == null ? null : source[index].clone();
        }
        return result;
    }
}

