/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.rift;

public record Vec3(double x, double y, double z) {
    public static final Vec3 ZERO = new Vec3(0.0, 0.0, 0.0);

    public Vec3 multiply(double value) {
        return new Vec3(this.x * value, this.y * value, this.z * value);
    }
}

