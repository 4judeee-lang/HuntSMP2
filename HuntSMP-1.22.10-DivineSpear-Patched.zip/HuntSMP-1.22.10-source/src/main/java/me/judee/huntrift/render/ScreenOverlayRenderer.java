/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.render;

import java.time.Duration;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.entity.Player;

public final class ScreenOverlayRenderer {
    private static final Key OVERLAY_FONT = Key.key((String)"hunt", (String)"overlay");
    private static final int FIRST_GLYPH = 57600;
    private static final int FRAME_COUNT = 32;
    private static final Title.Times TIMES = Title.Times.times((Duration)Duration.ZERO, (Duration)Duration.ofMillis(250L), (Duration)Duration.ZERO);
    private int lastFrame = -1;

    public void render(Player player, int requestedFrame) {
        int frame = Math.max(0, Math.min(31, requestedFrame));
        if (frame != this.lastFrame) {
            this.lastFrame = frame;
            if (frame <= 0) {
                player.clearTitle();
            } else {
                String glyphText = new String(Character.toChars(57600 + frame));
                Component glyph = Component.text((String)glyphText).font(OVERLAY_FONT);
                player.showTitle(Title.title((Component)glyph, (Component)Component.empty(), (Title.Times)TIMES));
            }
        }
    }

    public void clear(Player player) {
        this.lastFrame = -1;
        player.clearTitle();
    }
}

