/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.render;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public final class DisplayPool {
    private final JavaPlugin plugin;
    private final int maximumDisplays;
    private final float viewRange;
    private final Map<String, ItemDisplay> displays = new LinkedHashMap<String, ItemDisplay>();

    public DisplayPool(JavaPlugin plugin, int maximumDisplays, int viewingDistance) {
        this.plugin = plugin;
        this.maximumDisplays = Math.max(1, maximumDisplays);
        this.viewRange = Math.max(0.25f, (float)viewingDistance / 64.0f);
    }

    public ItemDisplay acquire(String role, String model, Location location, Display.Billboard billboard) {
        ItemDisplay existing = this.displays.get(role);
        if (existing != null && existing.isValid()) {
            return existing;
        }
        if (this.displays.size() >= this.maximumDisplays) {
            throw new IllegalStateException("Display limit reached for this rift session");
        }
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.setItemModel(new NamespacedKey("hunt", model));
        meta.setHideTooltip(true);
        item.setItemMeta(meta);
        ItemDisplay created = (ItemDisplay)location.getWorld().spawn(location, ItemDisplay.class, display -> {
            display.setItemStack(item);
            display.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            display.setBillboard(billboard);
            display.setBrightness(new Display.Brightness(15, 15));
            display.setInterpolationDelay(0);
            display.setInterpolationDuration(1);
            display.setTeleportDuration(1);
            display.setViewRange(this.viewRange);
            display.setDisplayWidth(48.0f);
            display.setDisplayHeight(48.0f);
            display.setShadowRadius(0.0f);
            display.setShadowStrength(0.0f);
            display.setGravity(false);
            display.setInvulnerable(true);
            display.setPersistent(false);
            display.setSilent(true);
            display.addScoreboardTag("hunt_rift_temporary");
        });
        this.displays.put(role, created);
        return created;
    }

    public ItemDisplay get(String role) {
        return this.displays.get(role);
    }

    public Collection<ItemDisplay> values() {
        return this.displays.values();
    }

    public int size() {
        return this.displays.size();
    }

    public void remove(String role) {
        ItemDisplay display = this.displays.remove(role);
        if (display != null && display.isValid()) {
            display.remove();
        }
    }

    public void removeAll() {
        for (ItemDisplay display : this.displays.values()) {
            if (display == null || !display.isValid()) continue;
            display.remove();
        }
        this.displays.clear();
    }
}

