/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.rift;

import me.judee.huntrift.rift.RiftFrame;
import me.judee.huntrift.rift.RiftPhase;
import me.judee.huntrift.rift.Vec3;
import me.judee.huntrift.util.Easing;

public final class RiftTimeline {
    public static final double SOURCE_FPS = 30.0;
    public static final int SOURCE_FRAME_COUNT = 173;
    public static final int SOURCE_START_FRAME = 33;
    public static final double SOURCE_START_SECONDS = 1.1;
    public static final double SOURCE_END_SECONDS = 5.766667;
    public static final double DURATION_SECONDS = 4.666667;
    public static final double SHOCKWAVE_START_SECONDS = 0.033;
    public static final double AUDIO_PEAK_SECONDS = 0.547;
    public static final double LAUNCH_SWEEP_SECONDS = 1.783;
    public static final double AFTERGLOW_SECONDS = 2.033;
    public static final double GLIDE_START_SECONDS = 2.833;
    public static final double CAMERA_RETURN_SECONDS = 3.133;
    private final double launchHeight;
    private final double launchForwardDistance;

    public RiftTimeline(double launchHeight, double launchForwardDistance) {
        this.launchHeight = launchHeight;
        this.launchForwardDistance = launchForwardDistance;
    }

    public RiftFrame sampleMilliseconds(double milliseconds) {
        return this.sample(milliseconds / 1000.0);
    }

    public RiftFrame sample(double requestedSequenceSeconds) {
        double sequenceSeconds = Math.max(0.0, Math.min(4.666667, requestedSequenceSeconds));
        double referenceSeconds = sequenceSeconds + 1.1;
        int sourceFrame = Math.min(172, Math.max(33, (int)Math.floor(referenceSeconds * 30.0 + 1.0E-9)));
        double minecraftTime = sequenceSeconds * 20.0;
        double tickFloor = Math.floor(minecraftTime + 1.0E-9);
        int minecraftTick = Math.min(93, (int)tickFloor);
        double subTick = Math.max(0.0, minecraftTime - tickFloor);
        RiftPhase phase = RiftPhase.at(sequenceSeconds);
        Vec3 camera = this.cameraOffset(sequenceSeconds);
        PlayerPath player = this.playerPath(sequenceSeconds);
        double shockwaveProgress = Easing.range(sequenceSeconds, 0.033, 0.233);
        double shockwaveOpacity = RiftTimeline.pulse(sequenceSeconds, 0.0, 0.1, 0.45);
        double shockwaveRadius = !(shockwaveProgress <= 0.0) && !(shockwaveOpacity <= 0.0) ? Easing.lerp(0.8, 6.8, Easing.easeOutCubic(shockwaveProgress)) : 0.0;
        double overlayOpacity = RiftTimeline.overlayOpacity(sequenceSeconds);
        int overlayFrame = RiftTimeline.overlayFrame(sequenceSeconds);
        int runeCount = RiftTimeline.runeCount(sequenceSeconds);
        int particleCount = RiftTimeline.particleCount(sequenceSeconds);
        double trailOpacity = RiftTimeline.pulse(sequenceSeconds, 1.783, 2.15, 3.133);
        double cameraShake = RiftTimeline.pulse(sequenceSeconds, 0.033, 0.35, 0.95) * 0.18;
        return new RiftFrame(referenceSeconds, sourceFrame, minecraftTick, subTick, phase, Vec3.ZERO, 0.0, 0.0, 0.0, 0.0, 0.0, camera, cameraShake, player.height, player.forward, player.yawOffset, player.velocityY, player.velocityForward, shockwaveRadius, shockwaveOpacity, overlayOpacity, overlayFrame, runeCount, particleCount, trailOpacity, sequenceSeconds);
    }

    private Vec3 cameraOffset(double seconds) {
        if (seconds < 1.783) {
            double orbit = Easing.smoothStep(Easing.range(seconds, 0.0, 1.783));
            return new Vec3(Easing.lerp(0.15, -0.8, orbit), Easing.lerp(2.4, 2.9, orbit), Easing.lerp(10.8, 9.8, orbit));
        }
        if (seconds < 3.133) {
            double follow = Easing.smoothStep(Easing.range(seconds, 1.783, 3.133));
            return new Vec3(Easing.lerp(-0.8, 0.25, follow), Easing.lerp(2.9, 2.2, follow), Easing.lerp(9.8, 8.6, follow));
        }
        return Vec3.ZERO;
    }

    private PlayerPath playerPath(double seconds) {
        if (seconds < 1.783) {
            double hover = this.launchHeight + Math.sin(seconds * Math.PI * 1.6) * 0.22;
            return new PlayerPath(hover, 0.0, 5.0, this.derivativeHeight(seconds), 0.0);
        }
        if (seconds < 2.833) {
            double progress = Easing.smootherStep(Easing.range(seconds, 1.783, 2.833));
            double forward = Easing.lerp(0.0, this.launchForwardDistance, Easing.easeInOutCubic(progress));
            return new PlayerPath(this.launchHeight, forward, Easing.lerp(5.0, 0.0, progress), 0.0, this.derivativeForward(seconds));
        }
        return new PlayerPath(this.launchHeight, this.launchForwardDistance, 0.0, 0.0, 0.0);
    }

    private double derivativeHeight(double seconds) {
        return Math.cos(seconds * Math.PI * 1.6) * 0.22 * Math.PI * 1.6 / 20.0;
    }

    private double derivativeForward(double seconds) {
        double step = 0.001;
        return (this.forwardOnly(seconds + step) - this.forwardOnly(seconds - step)) / (2.0 * step * 20.0);
    }

    private double forwardOnly(double seconds) {
        if (seconds < 1.783) {
            return 0.0;
        }
        if (seconds < 2.833) {
            double progress = Easing.smootherStep(Easing.range(seconds, 1.783, 2.833));
            return Easing.lerp(0.0, this.launchForwardDistance, Easing.easeInOutCubic(progress));
        }
        return this.launchForwardDistance;
    }

    private static double overlayOpacity(double seconds) {
        double[][] points = new double[][]{{0.0, 0.05}, {0.133, 0.2}, {0.3, 0.5}, {0.467, 0.73}, {0.6, 0.74}, {0.9, 0.55}, {1.1, 0.42}, {1.5, 0.24}, {2.033, 0.13}, {2.833, 0.07}, {3.133, 0.04}, {4.666667, 0.0}};
        return RiftTimeline.interpolatePoints(seconds, points);
    }

    private static int overlayFrame(double seconds) {
        if (seconds <= 0.467) {
            return 1 + (int)Math.round(Easing.range(seconds, 0.0, 0.467) * 14.0);
        }
        if (seconds <= 0.6) {
            return 15;
        }
        return seconds <= 2.033 ? 16 + (int)Math.round(Easing.range(seconds, 0.6, 2.033) * 11.0) : 28 + (int)Math.round(Easing.range(seconds, 2.033, 4.666667) * 3.0);
    }

    private static int runeCount(double seconds) {
        if (seconds >= 3.133) {
            return 0;
        }
        if (seconds < 0.35) {
            return Math.max(1, (int)Math.round(Easing.lerp(1.0, 12.0, Easing.range(seconds, 0.0, 0.35))));
        }
        return seconds > 2.6 ? Math.max(0, (int)Math.round(Easing.lerp(12.0, 0.0, Easing.range(seconds, 2.6, 3.133)))) : 12;
    }

    private static int particleCount(double seconds) {
        double[][] points = new double[][]{{0.0, 12.0}, {0.133, 72.0}, {0.547, 180.0}, {1.067, 145.0}, {1.783, 210.0}, {2.033, 180.0}, {2.833, 90.0}, {3.133, 54.0}, {4.666667, 8.0}};
        return (int)Math.round(RiftTimeline.interpolatePoints(seconds, points));
    }

    private static double pulse(double value, double start, double peak, double end) {
        if (value < start || value >= end) {
            return 0.0;
        }
        return value <= peak ? Easing.smoothStep(Easing.range(value, start, peak)) : 1.0 - Easing.smoothStep(Easing.range(value, peak, end));
    }

    private static double interpolatePoints(double value, double[][] points) {
        if (value <= points[0][0]) {
            return points[0][1];
        }
        for (int index = 1; index < points.length; ++index) {
            if (!(value <= points[index][0])) continue;
            double progress = Easing.range(value, points[index - 1][0], points[index][0]);
            return Easing.lerp(points[index - 1][1], points[index][1], Easing.smoothStep(progress));
        }
        return points[points.length - 1][1];
    }

    private record PlayerPath(double height, double forward, double yawOffset, double velocityY, double velocityForward) {
    }
}

