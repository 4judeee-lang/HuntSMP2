/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.util;

import org.bukkit.entity.ItemDisplay;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

public final class TransformUtil {
    private static final AxisAngle4f IDENTITY = new AxisAngle4f();

    private TransformUtil() {
    }

    public static void applyBillboard(ItemDisplay display, double scaleX, double scaleY, double rollDegrees) {
        display.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f((float)Math.toRadians(rollDegrees), 0.0f, 0.0f, 1.0f), new Vector3f((float)scaleX, (float)scaleY, 1.0f), IDENTITY));
    }

    public static void applyHorizontal(ItemDisplay display, double scale, double yawDegrees) {
        display.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(1.5707964f, 1.0f, 0.0f, 0.0f), new Vector3f((float)scale, (float)scale, 1.0f), new AxisAngle4f((float)Math.toRadians(yawDegrees), 0.0f, 0.0f, 1.0f)));
    }

    public static void hide(ItemDisplay display) {
        TransformUtil.applyBillboard(display, 0.001, 0.001, 0.0);
    }
}

