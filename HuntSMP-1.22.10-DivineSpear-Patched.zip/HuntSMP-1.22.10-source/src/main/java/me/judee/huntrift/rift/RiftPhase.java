/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntrift.rift;

import java.util.Locale;
import java.util.Optional;

public enum RiftPhase {
    OPENING(0.0, 0.033, "opening"),
    ROTATION(0.033, 0.133, "rotation"),
    CHARGE(0.133, 0.547, "charge"),
    IMPACT(0.547, 1.1, "impact"),
    LAUNCH(1.1, 2.033, "launch"),
    AFTERGLOW(2.033, 2.833, "afterglow"),
    GLIDE(2.833, 4.666667, "glide");

    private final double startSeconds;
    private final double endSeconds;
    private final String id;

    private RiftPhase(double startSeconds, double endSeconds, String id) {
        this.startSeconds = startSeconds;
        this.endSeconds = endSeconds;
        this.id = id;
    }

    public double startSeconds() {
        return this.startSeconds;
    }

    public double endSeconds() {
        return this.endSeconds;
    }

    public int startTick() {
        return (int)Math.floor(this.startSeconds * 20.0 + 1.0E-9);
    }

    public String id() {
        return this.id;
    }

    public static RiftPhase at(double seconds) {
        for (RiftPhase phase : RiftPhase.values()) {
            if (!(seconds >= phase.startSeconds) || !(seconds < phase.endSeconds)) continue;
            return phase;
        }
        return GLIDE;
    }

    public static Optional<RiftPhase> parse(String value) {
        String normalized = value.toLowerCase(Locale.ROOT);
        for (RiftPhase phase : RiftPhase.values()) {
            if (!phase.id.equals(normalized)) continue;
            return Optional.of(phase);
        }
        return Optional.empty();
    }
}

