package me.judee.huntsmp;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.TabCompleteEvent;
import org.bukkit.plugin.Plugin;

/** Routes the Divine Spear through HuntSMP's /hunt altar command tree. */
public final class DivineSpearHuntCommand implements Listener {
    private static final String ADMIN_PERMISSION = "hunt.admin";

    private DivineSpearHuntCommand() {}

    public static void register(Plugin plugin) {
        plugin.getServer().getPluginManager().registerEvents(new DivineSpearHuntCommand(), plugin);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onHuntAltarCommand(PlayerCommandPreprocessEvent event) {
        String raw = event.getMessage();
        if (raw == null) return;

        String normalized = raw.trim();
        if (normalized.startsWith("/")) normalized = normalized.substring(1);
        if (normalized.isBlank()) return;

        String[] parts = normalized.split("\\s+");
        if (!isDivineSpearRoute(parts)) return;

        event.setCancelled(true);
        Player player = event.getPlayer();
        if (!player.hasPermission(ADMIN_PERMISSION)) {
            player.sendMessage("§cYou do not have permission to use Hunt altar commands.");
            return;
        }

        // Reuse the tested DivineSpearFeature item factory and delivery path.
        Bukkit.dispatchCommand(player, "divinespear");
    }

    private static boolean isDivineSpearRoute(String[] parts) {
        if (parts.length < 3
                || !parts[0].equalsIgnoreCase("hunt")
                || !parts[1].equalsIgnoreCase("altar")) {
            return false;
        }

        // Exact shorthand requested by the server owner: /hunt altar spear
        if (parts.length == 3 && isSpearAlias(parts[2])) return true;

        // Existing Hunt altar style: /hunt altar give spear
        return parts.length == 4
                && parts[2].equalsIgnoreCase("give")
                && isSpearAlias(parts[3]);
    }

    private static boolean isSpearAlias(String value) {
        return value.equalsIgnoreCase("spear")
                || value.equalsIgnoreCase("divine")
                || value.equalsIgnoreCase("divinespear")
                || value.equalsIgnoreCase("divine_spear");
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onTabComplete(TabCompleteEvent event) {
        String buffer = event.getBuffer();
        if (buffer == null) return;

        String lower = buffer.toLowerCase(Locale.ROOT);
        boolean direct = lower.equals("/hunt altar ") || lower.startsWith("/hunt altar s");
        boolean give = lower.equals("/hunt altar give ") || lower.startsWith("/hunt altar give s");
        if (!direct && !give) return;

        String typed = lower.substring(lower.lastIndexOf(' ') + 1);
        if (!"spear".startsWith(typed)) return;

        Set<String> merged = new LinkedHashSet<>(event.getCompletions());
        merged.add("spear");
        event.setCompletions(new ArrayList<>(merged));
    }
}
