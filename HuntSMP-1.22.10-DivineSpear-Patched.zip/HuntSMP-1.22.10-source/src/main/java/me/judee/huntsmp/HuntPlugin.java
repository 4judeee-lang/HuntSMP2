/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntsmp;

import com.destroystokyo.paper.event.block.AnvilDamagedEvent;
import com.destroystokyo.paper.event.server.PaperServerListPingEvent;
import io.papermc.paper.event.block.VaultChangeStateEvent;
import io.papermc.paper.event.player.AsyncChatEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import me.judee.huntrift.camera.ProtocolCameraBridge;
import me.judee.huntrift.listener.CleanupListener;
import me.judee.huntrift.resource.ResourcePackService;
import me.judee.huntrift.rift.FinishReason;
import me.judee.huntrift.rift.RiftManager;
import me.judee.huntrift.rift.RiftPhase;
import me.judee.huntrift.rift.RiftSession;
import me.judee.huntsmp.AbilityManager;
import me.judee.huntsmp.AbsorptionDamage;
import me.judee.huntsmp.AltarManager;
import me.judee.huntsmp.MemberFeatures;
import me.judee.huntsmp.PremiumText;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.Color;
import org.bukkit.EntityEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.block.BlockState;
import org.bukkit.block.TrialSpawner;
import org.bukkit.block.Vault;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.TrialSpawner;
import org.bukkit.block.data.type.Vault;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockDispenseLootEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BrewingStartEvent;
import org.bukkit.event.block.CrafterCraftEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.TrialSpawnerSpawnEvent;
import org.bukkit.event.inventory.BrewEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.inventory.view.AnvilView;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;

public class HuntPlugin
extends JavaPlugin
implements Listener {
    private static final int[] RECIPE_INPUT_SLOTS = new int[]{10, 11, 12, 19, 20, 21, 28, 29, 30};
    private static final int RECIPE_OUTPUT_SLOT = 24;
    private static final int RECIPE_SAVE_SLOT = 49;
    private static final int SETTINGS_HEAVY_CORE_SLOT = 11;
    private static final int SETTINGS_EGAP_SLOT = 15;
    private static final int SETTINGS_MACE_CAP_SLOT = 22;
    private static final int SETTINGS_STRENGTH_SLOT = 27;
    private static final int SETTINGS_WEAVING_SLOT = 28;
    private static final Particle.DustOptions SHARD_DUST = new Particle.DustOptions(Color.fromRGB((int)255, (int)32, (int)64), 0.75f);
    private static final Particle.DustOptions TRACKER_DUST = new Particle.DustOptions(Color.fromRGB((int)210, (int)0, (int)28), 0.9f);
    private static final int[] RECIPE_LIST_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
    private final List<BukkitTask> cinematicTasks = new ArrayList<BukkitTask>();
    private final Set<UUID> vanishedPlayers = new HashSet<UUID>();
    private final Set<NamespacedKey> customRecipeKeys = new HashSet<NamespacedKey>();
    private final Map<Integer, StoredRecipe> customRecipes = new HashMap<Integer, StoredRecipe>();
    private final Map<UUID, TrackingSession> activeTrackers = new HashMap<UUID, TrackingSession>();
    private final Map<UUID, ItemStack> riftStoredHelmets = new HashMap<UUID, ItemStack>();
    private final Set<UUID> riftActivePlayers = new HashSet<UUID>();
    private final Map<UUID, Long> forcedGlidingPlayers = new HashMap<UUID, Long>();
    private final Map<UUID, List<BukkitTask>> riftTestTasks = new HashMap<UUID, List<BukkitTask>>();
    private final Set<UUID> pendingAbilityRolls = new HashSet<UUID>();
    private BukkitTask graceTask;
    private BukkitTask vanishSyncTask;
    private BukkitTask trackingTask;
    private BukkitTask heldEffectsTask;
    private BukkitTask forcedGlideTask;
    private BossBar graceBar;
    private File recipesFile;
    private YamlConfiguration recipesConfig;
    private int nextRecipeId = 1;
    private NamespacedKey huntItemKey;
    private NamespacedKey trackerCooldownKey;
    private Team redItemTeam;
    private boolean cinematicRunning;
    private boolean graceActive;
    private long graceTicksRemaining;
    private ResourcePackService riftResourcePacks;
    private RiftManager riftManager;
    private MemberFeatures memberFeatures;
    private AbilityManager abilityManager;
    private AltarManager altarManager;

    public void onEnable() {
        this.saveDefaultConfig();
        this.migrateConfiguration();
        this.huntItemKey = new NamespacedKey((Plugin)this, "hunt_item");
        this.trackerCooldownKey = new NamespacedKey((Plugin)this, "tracker_cooldown_until");
        this.loadVanishedPlayers();
        this.loadCustomRecipes();
        this.registerTrackerRecipe();
        this.registerAbilityRerollerRecipe();
        this.prepareRedItemTeam();
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)this);
        this.memberFeatures = new MemberFeatures(this);
        Bukkit.getPluginManager().registerEvents((Listener)this.memberFeatures, (Plugin)this);
        this.altarManager = new AltarManager(this);
        Bukkit.getPluginManager().registerEvents((Listener)this.altarManager, (Plugin)this);
        this.altarManager.start();
        this.abilityManager = new AbilityManager(this);
        Bukkit.getPluginManager().registerEvents((Listener)this.abilityManager, (Plugin)this);
        this.abilityManager.start();
        this.startVanishSync();
        this.startTrackingTask();
        this.startHeldItemEffects();
        this.startForcedGlideTask();
        this.riftResourcePacks = new ResourcePackService(this);
        ProtocolCameraBridge cameraBridge = new ProtocolCameraBridge(this);
        this.riftManager = new RiftManager(this, this.riftResourcePacks, cameraBridge, this::onRiftCinematicComplete);
        Bukkit.getPluginManager().registerEvents((Listener)new CleanupListener(this.riftManager, this.riftResourcePacks), (Plugin)this);
        this.riftManager.startTicker();
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.riftResourcePacks.sendLater(player);
        }
        Bukkit.getScheduler().runTask((Plugin)this, this::refreshLoadedGameplayBlocks);
        this.getLogger().info("HuntSMP enabled. Use /hunt start.");
    }

    private void migrateConfiguration() {
        boolean changed = false;
        Map additions = Map.ofEntries(Map.entry("gameplay.one-tick-brewing", true), Map.entry("gameplay.extended-strength-ii", true), Map.entry("gameplay.strength-ii-duration-seconds", 480), Map.entry("gameplay.extended-weaving", true), Map.entry("gameplay.weaving-duration-seconds", 480), Map.entry("gameplay.reusable-vaults", true), Map.entry("gameplay.trial-spawner-cooldown-seconds", 300), Map.entry("gameplay.mace-cap", 2), Map.entry("gameplay.unbreakable-anvils", true), Map.entry("gameplay.unlimited-anvil-cost", true), Map.entry("qol.one-player-sleep", true), Map.entry("qol.sleep-countdown-seconds", 5), Map.entry("qol.fast-leaf-decay", true), Map.entry("qol.leaf-decay-radius", 6), Map.entry("villagers.prevent-hit-price-increase", true), Map.entry("villagers.desirable-book-chance-percent", 75.0), Map.entry("trust.betrayal-hit-threshold", 3), Map.entry("trust.betrayal-window-seconds", 10), Map.entry("tracker.cooldown-seconds", 1800), Map.entry("limited-items.maces-issued", 0), Map.entry("vault-rewards.heavy-core.chance-percent", 40.0), Map.entry("vault-rewards.heavy-core.ominous-only", true), Map.entry("vault-rewards.enchanted-golden-apple.chance-percent", 50.0), Map.entry("vault-rewards.enchanted-golden-apple.ominous-only", false));
        for (Map.Entry addition : additions.entrySet()) {
            if (this.getConfig().isSet((String)addition.getKey())) continue;
            this.getConfig().set((String)addition.getKey(), addition.getValue());
            changed = true;
        }
        String currentPackUrl = "https://raw.githubusercontent.com/4judeee-lang/HuntSMP2/main/HuntSMP-Pack-1.21.1.zip";
        String currentPackHash = "bef00d5e2a95848aa1d6681fe09032ae824178ea";
        if (!currentPackUrl.equals(this.getConfig().getString("resource-pack.url", ""))) {
            this.getConfig().set("resource-pack.url", (Object)currentPackUrl);
            changed = true;
        }
        if (!currentPackHash.equalsIgnoreCase(this.getConfig().getString("resource-pack.sha1", ""))) {
            this.getConfig().set("resource-pack.sha1", (Object)currentPackHash);
            changed = true;
        }
        if (changed) {
            this.saveConfig();
        }
    }

    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!(player.getOpenInventory().getTopInventory().getHolder() instanceof RecipeEditorHolder)) continue;
            player.closeInventory();
        }
        this.cancelCinematic();
        if (this.riftManager != null) {
            this.riftManager.shutdown();
        }
        if (this.memberFeatures != null) {
            this.memberFeatures.shutdown();
        }
        if (this.abilityManager != null) {
            this.abilityManager.shutdown();
        }
        if (this.altarManager != null) {
            this.altarManager.shutdown();
        }
        for (UUID uuid : new HashSet<UUID>(this.riftTestTasks.keySet())) {
            Player player = Bukkit.getPlayer((UUID)uuid);
            if (player == null) continue;
            this.cancelRiftTest(player, false);
        }
        this.stopGrace();
        if (this.vanishSyncTask != null) {
            this.vanishSyncTask.cancel();
        }
        if (this.trackingTask != null) {
            this.trackingTask.cancel();
        }
        if (this.heldEffectsTask != null) {
            this.heldEffectsTask.cancel();
        }
        if (this.forcedGlideTask != null) {
            this.forcedGlideTask.cancel();
        }
        this.restoreAllRiftHelmets();
        this.forcedGlidingPlayers.clear();
        this.activeTrackers.clear();
        this.saveVanishedPlayers();
        for (UUID uuid : this.vanishedPlayers) {
            Player hidden = Bukkit.getPlayer((UUID)uuid);
            if (hidden == null) continue;
            hidden.setCollidable(true);
            for (Player viewer : Bukkit.getOnlinePlayers()) {
                viewer.showPlayer((Plugin)this, hidden);
            }
        }
        for (NamespacedKey key : this.customRecipeKeys) {
            Bukkit.removeRecipe((NamespacedKey)key);
        }
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (this.memberFeatures != null && this.memberFeatures.handleMemberCommand(sender, args)) {
            return true;
        }
        if (this.abilityManager != null && this.abilityManager.handleMemberCommand(sender, args)) {
            return true;
        }
        if (!sender.isOp()) {
            sender.sendMessage(this.color("&cOnly server operators can use Hunt commands."));
            return true;
        }
        if (this.abilityManager != null && this.abilityManager.handleOperatorCommand(sender, args)) {
            return true;
        }
        if (this.altarManager != null && this.altarManager.handleCommand(sender, args)) {
            return true;
        }
        if (args.length == 0) {
            this.sendUsage(sender);
            return true;
        }
        if (args[0].equalsIgnoreCase("compass")) {
            Player executingPlayer;
            Player player;
            if (args.length < 2 || args.length > 3) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &fUsage: &e/hunt compass <shard|give> [player] &7or &e/hunt compass cooldown"));
                return true;
            }
            if (args[1].equalsIgnoreCase("cooldown")) {
                if (args.length != 2 || !(sender instanceof Player)) {
                    sender.sendMessage(this.color("&6&lHUNT &8\u00bb &cUse /hunt compass cooldown as a player."));
                    return true;
                }
                Player executingPlayer2 = (Player)sender;
                executingPlayer2.getPersistentDataContainer().remove(this.trackerCooldownKey);
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &aYour compass tracking cooldown was cleared."));
                return true;
            }
            Object object = args.length == 3 ? Bukkit.getPlayerExact((String)args[2]) : (player = sender instanceof Player ? (executingPlayer = (Player)sender) : null);
            if (player == null) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &cSpecify an online player."));
                return true;
            }
            if (args[1].equalsIgnoreCase("shard")) {
                int shardNumber = Math.max(1, this.getConfig().getInt("limited-items.next-shard", 1));
                shardNumber = (shardNumber - 1) % 4 + 1;
                this.giveOrDrop(player, this.createMysteriousShard(shardNumber));
                this.getConfig().set("limited-items.next-shard", (Object)(shardNumber % 4 + 1));
                this.saveConfig();
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &aGave Rift Shard &f" + shardNumber + "/4 &ato &f" + player.getName() + "&a."));
                player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 0.8f, 0.55f);
                return true;
            }
            if (args[1].equalsIgnoreCase("give")) {
                this.giveOrDrop(player, this.createTrackerCompass());
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &aGave a Riftbound Compass to &f" + player.getName() + "&a."));
                player.playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.8f, 0.75f);
                return true;
            }
            sender.sendMessage(this.color("&6&lHUNT &8\u00bb &fUsage: &e/hunt compass <shard|give> [player] &7or &e/hunt compass cooldown"));
            return true;
        }
        if (args[0].equalsIgnoreCase("grace")) {
            if (args.length != 2 || !args[1].equalsIgnoreCase("off")) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &fUsage: &e/hunt grace off"));
                return true;
            }
            if (!this.graceActive) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &eGrace is not currently active."));
                return true;
            }
            this.stopGrace();
            Bukkit.broadcastMessage((String)this.color("&a&lGRACE &8\u00bb &cThe grace period was ended by an operator."));
            for (Player player : Bukkit.getOnlinePlayers()) {
                player.playSound(player.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 0.8f, 0.8f);
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("vanish")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(this.color("&cOnly a player can toggle vanish."));
                return true;
            }
            Player player = (Player)sender;
            if (args.length > 1) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &fUsage: &e/hunt vanish"));
                return true;
            }
            this.setVanished(player, !this.vanishedPlayers.contains(player.getUniqueId()), true);
            return true;
        }
        if (args[0].equalsIgnoreCase("recipes")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(this.color("&cOnly a player can open the recipe creator."));
                return true;
            }
            Player player = (Player)sender;
            if (args.length > 1) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &fUsage: &e/hunt recipes"));
                return true;
            }
            this.openRecipeBrowser(player, 0);
            return true;
        }
        if (args[0].equalsIgnoreCase("settings")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(this.color("&cOnly a player can open Hunt settings."));
                return true;
            }
            Player player = (Player)sender;
            if (args.length > 1) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &fUsage: &e/hunt settings"));
                return true;
            }
            this.openSettings(player);
            return true;
        }
        if (args[0].equalsIgnoreCase("rift")) {
            return this.handleRiftCommand(sender, args);
        }
        if (args[0].equalsIgnoreCase("broadcast")) {
            if (args.length < 2) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &fUsage: &e/hunt broadcast <message>"));
                return true;
            }
            if (this.cinematicRunning) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &eWait for the current announcement to finish."));
                return true;
            }
            String message = String.join((CharSequence)" ", Arrays.copyOfRange(args, 1, args.length));
            if (ChatColor.stripColor((String)this.color(message)).length() > 120) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &cBroadcasts can contain at most 120 visible characters."));
                return true;
            }
            this.startCustomBroadcast(message);
            sender.sendMessage(this.color("&6&lHUNT &8\u00bb &aBroadcast sent."));
            return true;
        }
        if (!args[0].equalsIgnoreCase("start") || args.length != 1) {
            this.sendUsage(sender);
            return true;
        }
        if (this.cinematicRunning || this.riftManager != null && this.riftManager.hasActiveSessions()) {
            sender.sendMessage(this.color("&6&lHUNT &8\u00bb &eThe startup sequence is already running."));
            return true;
        }
        this.startHunt();
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &aStartup sequence launched."));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.isOp()) {
            ArrayList<String> options = new ArrayList<String>();
            if (this.memberFeatures != null) {
                options.addAll(this.memberFeatures.tabComplete(sender, args));
            }
            if (this.abilityManager != null) {
                options.addAll(this.abilityManager.memberTab(sender, args));
            }
            return options.stream().distinct().toList();
        }
        if (args.length == 1) {
            String typed = args[0].toLowerCase();
            return List.of("start", "rift", "broadcast", "grace", "vanish", "recipes", "settings", "compass", "stats", "trust", "abilities", "ability", "altar").stream().filter(option -> option.startsWith(typed)).collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("grace")) {
            return "off".startsWith(args[1].toLowerCase()) ? List.of("off") : List.of();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("compass")) {
            String typed = args[1].toLowerCase();
            return List.of("shard", "give", "cooldown").stream().filter(option -> option.startsWith(typed)).toList();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("compass") && List.of("shard", "give").contains(args[1].toLowerCase())) {
            String typed = args[2].toLowerCase();
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase().startsWith(typed)).toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("trust")) {
            return this.memberFeatures == null ? List.of() : this.memberFeatures.tabComplete(sender, args);
        }
        if (args[0].equalsIgnoreCase("ability") || args[0].equalsIgnoreCase("abiliy") || args[0].equalsIgnoreCase("abilities")) {
            return this.abilityManager == null ? List.of() : this.abilityManager.operatorTab(args);
        }
        if (args[0].equalsIgnoreCase("altar")) {
            return this.altarManager == null ? List.of() : this.altarManager.tabComplete(args);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("rift")) {
            String typed = args[1].toLowerCase();
            ArrayList<String> options = new ArrayList<String>();
            options.addAll(List.of("cancel", "debug", "compare", "preview", "sendpack", "validatepack"));
            options.addAll(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList());
            return options.stream().filter(option -> option.toLowerCase().startsWith(typed)).toList();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("rift") && List.of("cancel", "debug", "compare", "sendpack").contains(args[1].toLowerCase())) {
            String typed = args[2].toLowerCase();
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase().startsWith(typed)).toList();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("rift") && args[1].equalsIgnoreCase("preview")) {
            String typed = args[2].toLowerCase();
            return Arrays.stream(RiftPhase.values()).map(RiftPhase::id).filter(name -> name.startsWith(typed)).toList();
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("rift") && args[1].equalsIgnoreCase("preview")) {
            String typed = args[3].toLowerCase();
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase().startsWith(typed)).toList();
        }
        return List.of();
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt start"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt rift [player]"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt rift cancel [player]"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt rift debug|compare|sendpack [player]"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt rift preview <phase> [player]"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt rift validatepack"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt broadcast <message>"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt grace off"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt vanish"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt recipes"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt settings"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt stats &7(member command)"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt trust <player> &7(member command)"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt ability info &7(member command)"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt abilities [player]"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt ability reroll [player]"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt compass <shard|give> [player]"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt compass cooldown"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt altar <give|spawn> <weapon|drill|mace|lightning>"));
        sender.sendMessage(this.color("&6&lHUNT &8\u00bb &e/hunt altar remove"));
    }

    private void startHunt() {
        this.cinematicRunning = true;
        this.startGrace();
        this.startCinematic();
    }

    private boolean handleRiftCommand(CommandSender sender, String[] args) {
        String action;
        if (this.riftManager == null || this.riftResourcePacks == null) {
            sender.sendMessage(this.color("&6&lHUNT &8\u00bb &cThe rift system did not initialize. Check latest.log."));
            return true;
        }
        String string = action = args.length >= 2 ? args[1].toLowerCase() : "start";
        if (action.equals("validatepack")) {
            sender.sendMessage(this.color("&6&lHUNT &8\u00bb &f" + this.riftResourcePacks.validationSummary()));
            return true;
        }
        if (action.equals("sendpack")) {
            Player target = this.resolveRiftTarget(sender, args.length >= 3 ? args[2] : null);
            if (target != null) {
                this.riftResourcePacks.send(target);
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &aSent the HuntSMP pack to &f" + target.getName() + "&a."));
            }
            return true;
        }
        if (action.equals("cancel")) {
            Player target = this.resolveRiftTarget(sender, args.length >= 3 ? args[2] : null);
            if (target != null) {
                boolean cancelled = this.riftManager.cancel(target, FinishReason.CANCELLED, true);
                sender.sendMessage(this.color((String)(cancelled ? "&6&lHUNT &8\u00bb &aCancelled the rift for &f" + target.getName() + "&a." : "&6&lHUNT &8\u00bb &eThat player has no active rift.")));
            }
            return true;
        }
        if (action.equals("debug")) {
            Player target = this.resolveRiftTarget(sender, args.length >= 3 ? args[2] : null);
            if (target != null) {
                RiftSession session = this.riftManager.session(target);
                if (session == null) {
                    sender.sendMessage(this.color("&6&lHUNT &8\u00bb &eThat player has no active rift."));
                } else {
                    session.toggleDebug(target);
                }
            }
            return true;
        }
        if (action.equals("compare")) {
            Player target = this.resolveRiftTarget(sender, args.length >= 3 ? args[2] : null);
            if (target != null) {
                this.startRift(sender, target, null, true);
            }
            return true;
        }
        if (action.equals("preview")) {
            if (args.length < 3 || args.length > 4) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &fUsage: &e/hunt rift preview <phase> [player]"));
                return true;
            }
            Optional<RiftPhase> phase = RiftPhase.parse(args[2]);
            if (phase.isEmpty()) {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &cUnknown phase."));
                return true;
            }
            Player target = this.resolveRiftTarget(sender, args.length == 4 ? args[3] : null);
            if (target != null) {
                this.startRift(sender, target, phase.get(), false);
            }
            return true;
        }
        Player target = this.resolveRiftTarget(sender, args.length == 2 ? args[1] : null);
        if (args.length > 2) {
            sender.sendMessage(this.color("&6&lHUNT &8\u00bb &fUsage: &e/hunt rift [player]"));
            return true;
        }
        if (target != null) {
            this.startRift(sender, target, null, false);
        }
        return true;
    }

    private Player resolveRiftTarget(CommandSender sender, String name) {
        if (name == null) {
            if (sender instanceof Player) {
                Player player = (Player)sender;
                return player;
            }
            sender.sendMessage(this.color("&cConsole must specify an online player."));
            return null;
        }
        Player target = Bukkit.getPlayerExact((String)name);
        if (target == null) {
            sender.sendMessage(this.color("&cThat player is not online."));
        }
        return target;
    }

    private void startRift(CommandSender sender, Player target, RiftPhase phase, boolean comparison) {
        RiftManager.StartResult result = this.riftManager.start(target, phase, comparison);
        switch (result) {
            case STARTED: {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &aRift started for &f" + target.getName() + "&a."));
                break;
            }
            case ALREADY_ACTIVE: {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &eThat player already has an active rift."));
                break;
            }
            case COOLDOWN: {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &eWait " + this.riftManager.remainingCooldownSeconds(target) + " seconds."));
                break;
            }
            case LIMIT_REACHED: {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &eToo many rifts are active."));
                break;
            }
            case PACK_NOT_LOADED: {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &cThe HuntSMP pack has not finished loading for that player. Use /hunt rift sendpack."));
                break;
            }
            case CAMERA_UNAVAILABLE: {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &eCamera unavailable; the working first-person fallback is enabled."));
                break;
            }
            case DEAD: {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &cThat player is dead."));
                break;
            }
            case INTERNAL_ERROR: {
                sender.sendMessage(this.color("&6&lHUNT &8\u00bb &cRift startup failed. Check latest.log."));
            }
        }
    }

    private boolean startRiftTest(Player player) {
        UUID uuid = player.getUniqueId();
        if (this.riftTestTasks.containsKey(uuid) || this.riftActivePlayers.contains(uuid)) {
            return false;
        }
        ArrayList<BukkitTask> tasks = new ArrayList<BukkitTask>();
        this.riftTestTasks.put(uuid, tasks);
        tasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
            if (!this.isActiveRiftTest(uuid)) {
                return;
            }
            player.playSound(player.getLocation(), "hunt:rift_warning", 1.1f, 1.0f);
            player.spawnParticle(Particle.END_ROD, player.getLocation().add(0.0, 1.0, 0.0), 10, 0.45, 0.7, 0.45, 0.025);
        }, 1L));
        tasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
            if (!this.isActiveRiftTest(uuid)) {
                return;
            }
            ItemStack helmet = player.getInventory().getHelmet();
            this.riftStoredHelmets.put(uuid, helmet == null ? new ItemStack(Material.AIR) : helmet.clone());
            this.riftActivePlayers.add(uuid);
            player.getInventory().setHelmet(this.createRiftOverlayHelmet());
            player.playSound(player.getLocation(), "hunt:rift_flash", 1.25f, 1.0f);
            this.spawnGoldenRiftBurst(player, player.getLocation().add(0.0, 1.0, 0.0));
        }, 20L));
        tasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
            if (this.isActiveRiftTest(uuid) && player.isOnline() && !player.isDead()) {
                this.launchPlayer(player);
            }
        }, 28L));
        tasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
            if (this.isActiveRiftTest(uuid)) {
                this.restoreRiftHelmet(player);
            }
        }, 93L));
        long sessionEnd = 28L + Math.max(10L, this.getConfig().getLong("launch.max-glide-seconds", 60L)) * 20L + 20L;
        tasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> this.riftTestTasks.remove(uuid), sessionEnd));
        return true;
    }

    private boolean isActiveRiftTest(UUID uuid) {
        return this.riftTestTasks.containsKey(uuid);
    }

    private boolean cancelRiftTest(Player player, boolean notifyTarget) {
        UUID uuid = player.getUniqueId();
        List<BukkitTask> tasks = this.riftTestTasks.remove(uuid);
        if (tasks == null) {
            return false;
        }
        for (BukkitTask task : tasks) {
            task.cancel();
        }
        this.restoreRiftHelmet(player);
        player.stopSound("hunt:rift_warning");
        player.stopSound("hunt:rift_flash");
        if (this.forcedGlidingPlayers.remove(uuid) != null) {
            player.setGliding(false);
            player.setFallDistance(0.0f);
        }
        if (notifyTarget) {
            player.sendMessage(this.color("&6&lHUNT &8\u00bb &cYour rift test was cancelled."));
        }
        return true;
    }

    private void expandBordersWithCinematic(long cinematicTicks) {
        double targetSize = Math.max(1.0, this.getConfig().getDouble("border.goal", 5000.0));
        double slowPercent = Math.max(0.01, Math.min(0.9, this.getConfig().getDouble("border.slow-phase-percent", 0.12)));
        long burstBeforeEnd = Math.max(1L, this.getConfig().getLong("border.final-burst-before-end-ticks", 30L));
        long slowTicks = Math.max(1L, cinematicTicks - burstBeforeEnd);
        HashSet<World> onlineWorlds = new HashSet<World>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            onlineWorlds.add(player.getWorld());
        }
        if (onlineWorlds.isEmpty() && !Bukkit.getWorlds().isEmpty()) {
            onlineWorlds.add((World)Bukkit.getWorlds().getFirst());
        }
        for (World world : onlineWorlds) {
            WorldBorder border = world.getWorldBorder();
            double currentSize = border.getSize();
            if (currentSize < targetSize) {
                double slowTarget = currentSize + (targetSize - currentSize) * slowPercent;
                border.changeSize(slowTarget, slowTicks);
            }
            this.cinematicTasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> border.setSize(targetSize), slowTicks));
        }
    }

    private void launchPlayer(Player player) {
        if (player.isDead()) {
            return;
        }
        Location beforeRift = player.getLocation().clone();
        double requestedHeight = Math.max(1.0, this.getConfig().getDouble("launch.height", 100.0));
        Location launchLocation = beforeRift.clone();
        launchLocation.setY(beforeRift.getY() + requestedHeight);
        player.teleport(launchLocation);
        Vector direction = launchLocation.getDirection().clone();
        direction.setY(0.0);
        if (direction.lengthSquared() < 1.0E-4) {
            direction = new Vector(0, 0, 1);
        }
        direction.normalize();
        double horizontalSpeed = Math.max(0.1, this.getConfig().getDouble("launch.horizontal-speed", 0.38));
        double verticalBoost = this.getConfig().getDouble("launch.vertical-boost", 0.06);
        Vector glideVelocity = direction.multiply(horizontalSpeed).setY(verticalBoost);
        player.setFallDistance(0.0f);
        player.setVelocity(glideVelocity);
        player.setGliding(true);
        this.forcedGlidingPlayers.put(player.getUniqueId(), System.currentTimeMillis());
        int slowFallingSeconds = Math.max(1, this.getConfig().getInt("launch.feather-falling-seconds", 30));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, slowFallingSeconds * 20, 0, false, false, true));
        this.spawnGoldenRiftBurst(player, launchLocation);
    }

    private void startCinematic() {
        List<String> lines = this.getConfig().getStringList("cinematic.lines");
        if (lines.isEmpty()) {
            lines = List.of("&fSMP has started", "&d2 altars have been released", "&eHints will be announced", "&aGood luck! Survive out there &7-4judee");
        }
        String title = this.color(this.getConfig().getString("cinematic.title", "&6&lHUNT"));
        int characterDelay = Math.max(1, this.getConfig().getInt("cinematic.ticks-per-character", 2));
        int holdTicks = Math.max(10, this.getConfig().getInt("cinematic.hold-ticks", 35));
        long cursor = 10L;
        for (Player player2 : Bukkit.getOnlinePlayers()) {
            player2.playSound(player2.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.35f, 0.72f);
            player2.playSound(player2.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.55f, 0.65f);
        }
        for (String configuredLine : lines) {
            String line = this.color(configuredLine);
            this.scheduleTypewriterLine(title, line, cursor, characterDelay);
            cursor += (long)this.visibleLength(line) * (long)characterDelay + (long)holdTicks;
        }
        long finishAt = cursor + 10L;
        this.expandBordersWithCinematic(finishAt);
        List<UUID> riftPlayers = Bukkit.getOnlinePlayers().stream().filter(player -> !player.isDead()).map(OfflinePlayer::getUniqueId).toList();
        this.cinematicTasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                player.sendTitle("", "", 0, 1, 10);
                player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.85f, 1.0f);
            }
            this.cinematicRunning = false;
            for (UUID uuid : riftPlayers) {
                Player player = Bukkit.getPlayer((UUID)uuid);
                if (player == null || !player.isOnline()) continue;
                this.pendingAbilityRolls.add(player.getUniqueId());
                RiftManager.StartResult result = this.riftManager.start(player, null, false);
                if (result == RiftManager.StartResult.STARTED) continue;
                this.pendingAbilityRolls.remove(player.getUniqueId());
                player.sendMessage(this.color("&6&lHUNT &8\u00bb &cRift could not start: &f" + result.name()));
            }
            this.cinematicTasks.clear();
        }, finishAt));
    }

    private void startCustomBroadcast(String message) {
        this.cinematicRunning = true;
        String title = this.color(this.getConfig().getString("cinematic.title", "&6&lHUNT"));
        int characterDelay = Math.max(1, this.getConfig().getInt("cinematic.ticks-per-character", 2));
        int holdTicks = Math.max(10, this.getConfig().getInt("cinematic.hold-ticks", 35));
        String coloredMessage = this.color(message);
        this.scheduleTypewriterLine(title, coloredMessage, 1L, characterDelay);
        long finishAt = (long)this.visibleLength(coloredMessage) * (long)characterDelay + (long)holdTicks;
        this.cinematicTasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                player.sendTitle("", "", 0, 1, 10);
            }
            this.cinematicRunning = false;
            this.cinematicTasks.clear();
        }, finishAt));
    }

    private List<UUID> beginWhiteFlashSequence(long durationTicks) {
        return this.beginWhiteFlashSequence(durationTicks, Bukkit.getOnlinePlayers());
    }

    private List<UUID> beginWhiteFlashSequence(long durationTicks, Iterable<? extends Player> players) {
        ArrayList<UUID> participants = new ArrayList<UUID>();
        for (Player player : players) {
            if (player.isDead()) continue;
            participants.add(player.getUniqueId());
        }
        long safeDuration = Math.max(1L, durationTicks);
        long warningAt = Math.max(1L, safeDuration - 28L);
        long flashAt = Math.max(warningAt + 1L, safeDuration - 8L);
        this.cinematicTasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
            for (UUID uuid : participants) {
                Player player = Bukkit.getPlayer((UUID)uuid);
                if (player == null || !player.isOnline() || player.isDead()) continue;
                player.playSound(player.getLocation(), "hunt:rift_warning", 1.1f, 1.0f);
                player.spawnParticle(Particle.END_ROD, player.getLocation().add(0.0, 1.0, 0.0), 10, 0.45, 0.7, 0.45, 0.025);
            }
        }, warningAt));
        this.cinematicTasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
            for (UUID uuid : participants) {
                Player player = Bukkit.getPlayer((UUID)uuid);
                if (player == null || !player.isOnline() || player.isDead()) continue;
                ItemStack helmet = player.getInventory().getHelmet();
                this.riftStoredHelmets.put(uuid, helmet == null ? new ItemStack(Material.AIR) : helmet.clone());
                this.riftActivePlayers.add(uuid);
                player.getInventory().setHelmet(this.createRiftOverlayHelmet());
                player.playSound(player.getLocation(), "hunt:rift_flash", 1.25f, 1.0f);
                this.spawnGoldenRiftBurst(player, player.getLocation().add(0.0, 1.0, 0.0));
            }
        }, flashAt));
        this.cinematicTasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
            for (UUID uuid : participants) {
                this.restoreRiftHelmet(uuid);
            }
        }, safeDuration + 65L));
        return participants;
    }

    private void spawnGoldenRiftBurst(Player player, Location center) {
        player.spawnParticle(Particle.FLASH, center, 1);
        player.spawnParticle(Particle.END_ROD, center, 42, 1.25, 1.8, 1.25, 0.09);
        player.spawnParticle(Particle.FIREWORK, center, 34, 1.0, 1.35, 1.0, 0.12);
        player.spawnParticle(Particle.WAX_ON, center, 38, 1.15, 1.55, 1.15, 0.11);
        player.spawnParticle(Particle.TOTEM_OF_UNDYING, center, 24, 0.85, 1.2, 0.85, 0.08);
    }

    private void restoreRiftHelmet(UUID uuid) {
        Player player = Bukkit.getPlayer((UUID)uuid);
        if (player == null) {
            return;
        }
        this.restoreRiftHelmet(player);
    }

    private void restoreRiftHelmet(Player player) {
        UUID uuid = player.getUniqueId();
        ItemStack original = this.riftStoredHelmets.remove(uuid);
        this.riftActivePlayers.remove(uuid);
        if (original == null) {
            return;
        }
        player.getInventory().setHelmet(original.getType() == Material.AIR ? null : original);
    }

    private void restoreAllRiftHelmets() {
        for (UUID uuid : new HashSet<UUID>(this.riftStoredHelmets.keySet())) {
            this.restoreRiftHelmet(uuid);
        }
    }

    private void startForcedGlideTask() {
        this.forcedGlideTask = Bukkit.getScheduler().runTaskTimer((Plugin)this, () -> {
            long now = System.currentTimeMillis();
            long maxMillis = Math.max(10L, this.getConfig().getLong("launch.max-glide-seconds", 60L)) * 1000L;
            for (Map.Entry<UUID, Long> entry : new HashMap<UUID, Long>(this.forcedGlidingPlayers).entrySet()) {
                Player player = Bukkit.getPlayer((UUID)entry.getKey());
                if (player == null || !player.isOnline() || player.isDead()) {
                    this.forcedGlidingPlayers.remove(entry.getKey());
                    continue;
                }
                long elapsed = now - entry.getValue();
                if (elapsed >= maxMillis || elapsed >= 1000L && player.isOnGround()) {
                    this.forcedGlidingPlayers.remove(entry.getKey());
                    List<BukkitTask> completedTest = this.riftTestTasks.remove(entry.getKey());
                    if (completedTest != null) {
                        for (BukkitTask task : completedTest) {
                            task.cancel();
                        }
                        this.restoreRiftHelmet(player);
                    }
                    player.setGliding(false);
                    player.setFallDistance(0.0f);
                    player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 22, 0.55, 0.15, 0.55, 0.04);
                    continue;
                }
                player.setGliding(true);
                player.setFallDistance(0.0f);
                Vector look = player.getLocation().getDirection().setY(0.0);
                if (!(look.lengthSquared() > 1.0E-4)) continue;
                double cruiseSpeed = Math.max(0.1, this.getConfig().getDouble("launch.glide-cruise-speed", 0.48));
                Vector target = look.normalize().multiply(cruiseSpeed);
                Vector current = player.getVelocity();
                double blend = 0.035;
                player.setVelocity(new Vector(current.getX() * (1.0 - blend) + target.getX() * blend, current.getY(), current.getZ() * (1.0 - blend) + target.getZ() * blend));
            }
        }, 1L, 1L);
    }

    private void scheduleTypewriterLine(String title, String coloredLine, long startTick, int characterDelay) {
        Object activeColors = "";
        StringBuilder visible = new StringBuilder();
        int visibleCharacters = 0;
        for (int index = 0; index < coloredLine.length(); ++index) {
            char current = coloredLine.charAt(index);
            if (current == '\u00a7' && index + 1 < coloredLine.length()) {
                activeColors = (String)activeColors + coloredLine.substring(index, index + 2);
                visible.append(current).append(coloredLine.charAt(++index));
                continue;
            }
            visible.append(current);
            String frame = (String)activeColors + String.valueOf(visible);
            long frameTick = startTick + (long)(++visibleCharacters - 1) * (long)characterDelay;
            this.cinematicTasks.add(Bukkit.getScheduler().runTaskLater((Plugin)this, () -> this.showFrame(title, frame), frameTick));
        }
    }

    private void showFrame(String title, String subtitle) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendTitle(title, subtitle, 0, 30, 5);
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.38f, 1.65f);
        }
    }

    private void startGrace() {
        this.stopGrace();
        int minutes = Math.max(1, this.getConfig().getInt("grace.duration-minutes", 30));
        this.graceTicksRemaining = (long)minutes * 60L * 20L;
        this.graceActive = true;
        this.graceBar = Bukkit.createBossBar((String)"", (BarColor)BarColor.GREEN, (BarStyle)BarStyle.SOLID, (BarFlag[])new BarFlag[0]);
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.graceBar.addPlayer(player);
            this.applyGraceSaturation(player);
        }
        this.updateGraceBar();
        this.graceTask = Bukkit.getScheduler().runTaskTimer((Plugin)this, () -> {
            this.graceTicksRemaining -= 20L;
            if (this.graceTicksRemaining <= 0L) {
                this.stopGrace();
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.sendMessage(this.color("&a&lGRACE &8\u00bb &cThe grace period has ended. PvP and damage are now enabled."));
                    player.playSound(player.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 0.8f, 0.8f);
                }
                return;
            }
            for (Player player : Bukkit.getOnlinePlayers()) {
                this.applyGraceSaturation(player);
            }
            this.updateGraceBar();
        }, 20L, 20L);
    }

    private void updateGraceBar() {
        if (this.graceBar == null) {
            return;
        }
        long totalTicks = Math.max(20L, (long)this.getConfig().getInt("grace.duration-minutes", 30) * 60L * 20L);
        double progress = Math.max(0.0, Math.min(1.0, (double)this.graceTicksRemaining / (double)totalTicks));
        long totalSeconds = Math.max(0L, (this.graceTicksRemaining + 19L) / 20L);
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        this.graceBar.setProgress(progress);
        this.graceBar.setTitle(PremiumText.legacyMini("GRACE PROTOCOL", 12976066, 4170851) + PremiumText.legacyMini("   |   ", 0x555A65, 7567751) + PremiumText.legacyMini(String.format("%02d:%02d", minutes, seconds), 0xFFFFFF, 12173516));
    }

    private void applyGraceSaturation(Player player) {
        player.setFoodLevel(20);
        player.setSaturation(20.0f);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SATURATION, 40, 0, false, false, true));
    }

    private void stopGrace() {
        boolean removeGrantedSaturation = this.graceActive;
        this.graceActive = false;
        this.graceTicksRemaining = 0L;
        if (this.graceTask != null) {
            this.graceTask.cancel();
            this.graceTask = null;
        }
        if (this.graceBar != null) {
            this.graceBar.removeAll();
            this.graceBar = null;
        }
        if (removeGrantedSaturation) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                player.removePotionEffect(PotionEffectType.SATURATION);
            }
        }
    }

    private void loadVanishedPlayers() {
        this.vanishedPlayers.clear();
        for (String value : this.getConfig().getStringList("vanished-players")) {
            try {
                this.vanishedPlayers.add(UUID.fromString(value));
            }
            catch (IllegalArgumentException ignored) {
                this.getLogger().warning("Ignored invalid vanished player UUID: " + value);
            }
        }
    }

    private void saveVanishedPlayers() {
        List<String> values = this.vanishedPlayers.stream().map(UUID::toString).sorted().toList();
        this.getConfig().set("vanished-players", values);
        this.saveConfig();
    }

    private void startVanishSync() {
        this.vanishSyncTask = Bukkit.getScheduler().runTaskTimer((Plugin)this, () -> {
            for (UUID uuid : this.vanishedPlayers) {
                Player hidden = Bukkit.getPlayer((UUID)uuid);
                if (hidden == null || !hidden.isOnline()) continue;
                hidden.setCollidable(false);
                for (Player viewer : Bukkit.getOnlinePlayers()) {
                    if (viewer.equals((Object)hidden)) continue;
                    if (viewer.isOp()) {
                        viewer.showPlayer((Plugin)this, hidden);
                        continue;
                    }
                    viewer.hidePlayer((Plugin)this, hidden);
                }
            }
        }, 1L, 20L);
    }

    private void setVanished(Player player, boolean vanish, boolean announce) {
        if (vanish) {
            this.vanishedPlayers.add(player.getUniqueId());
            player.setCollidable(false);
            for (Player viewer : Bukkit.getOnlinePlayers()) {
                if (viewer.equals((Object)player)) continue;
                if (viewer.isOp()) {
                    viewer.showPlayer((Plugin)this, player);
                    continue;
                }
                viewer.hidePlayer((Plugin)this, player);
                if (!announce) continue;
                viewer.sendMessage((Component)Component.text((String)(player.getName() + " left the game"), (TextColor)NamedTextColor.YELLOW));
            }
            if (announce) {
                player.sendMessage(this.color("&6&lHUNT &8\u00bb &aVanish enabled. Non-operators can no longer see you."));
                player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.7f, 0.7f);
            }
        } else {
            this.vanishedPlayers.remove(player.getUniqueId());
            player.setCollidable(true);
            for (Player viewer : Bukkit.getOnlinePlayers()) {
                if (viewer.equals((Object)player)) continue;
                viewer.showPlayer((Plugin)this, player);
                if (viewer.isOp() || !announce) continue;
                viewer.sendMessage(this.color("&e" + player.getName() + " joined the game"));
            }
            if (announce) {
                player.sendMessage(this.color("&6&lHUNT &8\u00bb &cVanish disabled. You are visible again."));
                player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.7f, 1.3f);
            }
        }
        this.saveVanishedPlayers();
    }

    private ItemStack createMysteriousShard(int shardNumber) {
        ItemStack item = new ItemStack(Material.AMETHYST_SHARD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(PremiumText.mini("FRACTURED SHARD   |   0" + shardNumber + "/04", 0xFF9B9B, 8197694));
        meta.lore(List.of(PremiumText.mini("CLASSIFIED RELIC", 10189444, 4996166), Component.empty(), PremiumText.mini("ORIGIN        |  UNRESOLVED", 15198703, 9344418), PremiumText.mini("FREQUENCY     |  UNREADABLE", 15198703, 9344418), Component.empty(), PremiumText.mini("One quarter of a forbidden instrument.", 13357017, 8291474), PremiumText.mini("It remembers the trail of every quarry.", 13357017, 8291474), Component.empty(), PremiumText.mini("SINGULAR FRAGMENT   |   " + shardNumber + " OF 4", 16747158, 12004169)));
        meta.getPersistentDataContainer().set(this.huntItemKey, PersistentDataType.STRING, (Object)"mysterious_shard");
        meta.getPersistentDataContainer().set(new NamespacedKey((Plugin)this, "shard_number"), PersistentDataType.INTEGER, (Object)shardNumber);
        meta.setItemModel(new NamespacedKey("hunt", "mysterious_shard"));
        meta.setEnchantmentGlintOverride(Boolean.valueOf(true));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createTrackerCompass() {
        ItemStack item = new ItemStack(Material.RECOVERY_COMPASS);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(PremiumText.mini("RIFTBOUND COMPASS   |   01/01", 0xFF9A9A, 10097982));
        meta.lore(List.of(PremiumText.mini("SINGULAR TRACKING RELIC", 10713732, 5258053), Component.empty(), PremiumText.mini("Forged from four impossible fragments.", 15001581, 9476005), PremiumText.mini("No marked quarry remains hidden.", 15001581, 9476005), Component.empty(), PremiumText.mini("RIGHT CLICK    |  SELECT QUARRY", 16749212, 12856651), PremiumText.mini("CRIMSON TRAIL  |  05:00", 16764855, 13781589), PremiumText.mini("RECOVERY       |  30:00", 13554911, 8225938), Component.empty(), PremiumText.mini("SIGNATURE RELIC   |   ONE OF ONE", 16770203, 12154919)));
        meta.getPersistentDataContainer().set(this.huntItemKey, PersistentDataType.STRING, (Object)"bloodbound_tracker");
        meta.setItemModel(new NamespacedKey("hunt", "red_tracker"));
        meta.setEnchantmentGlintOverride(Boolean.valueOf(true));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createRiftOverlayHelmet() {
        ItemStack item = new ItemStack(Material.CARVED_PUMPKIN);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(PremiumText.mini("RIFT VISION   |   CINEMATIC LENS", 15250687, 7418788));
        meta.getPersistentDataContainer().set(this.huntItemKey, PersistentDataType.STRING, (Object)"rift_overlay");
        meta.setItemModel(new NamespacedKey("hunt", "rift_overlay"));
        meta.setUnbreakable(true);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE});
        item.setItemMeta(meta);
        return item;
    }

    private boolean isTracker(ItemStack item) {
        if (!this.isUsableItem(item) || !item.hasItemMeta()) {
            return false;
        }
        String type = (String)item.getItemMeta().getPersistentDataContainer().get(this.huntItemKey, PersistentDataType.STRING);
        return "bloodbound_tracker".equals(type);
    }

    private String getHuntItemType(ItemStack item) {
        if (!this.isUsableItem(item) || !item.hasItemMeta()) {
            return null;
        }
        return (String)item.getItemMeta().getPersistentDataContainer().get(this.huntItemKey, PersistentDataType.STRING);
    }

    private void giveOrDrop(Player player, ItemStack item) {
        HashMap overflow = player.getInventory().addItem(new ItemStack[]{item});
        for (ItemStack leftover : overflow.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), leftover);
        }
    }

    private void registerTrackerRecipe() {
        NamespacedKey key = new NamespacedKey((Plugin)this, "bloodbound_tracker");
        Bukkit.removeRecipe((NamespacedKey)key);
        ShapedRecipe recipe = new ShapedRecipe(key, this.createTrackerCompass());
        recipe.shape(new String[]{" S ", "SCS", " S "});
        recipe.setIngredient('S', (RecipeChoice)new RecipeChoice.ExactChoice(List.of(this.createMysteriousShard(1), this.createMysteriousShard(2), this.createMysteriousShard(3), this.createMysteriousShard(4))));
        recipe.setIngredient('C', Material.RECOVERY_COMPASS);
        if (Bukkit.addRecipe((Recipe)recipe)) {
            this.customRecipeKeys.add(key);
        }
    }

    private ItemStack createAbilityReroller() {
        ItemStack item = new ItemStack(Material.ECHO_SHARD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(PremiumText.mini("FATE REROLLER   |   CONSUMABLE", 15972607, 7549098));
        meta.lore(List.of(PremiumText.mini("FRACTURED INSTRUMENT OF FATE", 11111090, 5325656), Component.empty(), PremiumText.mini("Break the Hunt bound to your soul.", 0xE5E7EE, 9541797), PremiumText.mini("Awaken another power in its place.", 0xE5E7EE, 9541797), Component.empty(), PremiumText.mini("RIGHT CLICK    |  INITIATE REROLL", 15246079, 9257926), PremiumText.mini("CONSUMED ON USE", 16757402, 13715806)));
        meta.getPersistentDataContainer().set(this.huntItemKey, PersistentDataType.STRING, (Object)"ability_reroller");
        meta.setItemModel(new NamespacedKey("hunt", "ability_reroller"));
        meta.setEnchantmentGlintOverride(Boolean.valueOf(true));
        item.setItemMeta(meta);
        return item;
    }

    private void registerAbilityRerollerRecipe() {
        NamespacedKey key = new NamespacedKey((Plugin)this, "ability_reroller");
        Bukkit.removeRecipe((NamespacedKey)key);
        ShapedRecipe recipe = new ShapedRecipe(key, this.createAbilityReroller());
        recipe.shape(new String[]{"AEA", "ENE", "AEA"});
        recipe.setIngredient('A', Material.AMETHYST_SHARD);
        recipe.setIngredient('E', Material.ECHO_SHARD);
        recipe.setIngredient('N', Material.NETHER_STAR);
        if (Bukkit.addRecipe((Recipe)recipe)) {
            this.customRecipeKeys.add(key);
        }
        ItemStack[] ingredients = new ItemStack[]{new ItemStack(Material.AMETHYST_SHARD), new ItemStack(Material.ECHO_SHARD), new ItemStack(Material.AMETHYST_SHARD), new ItemStack(Material.ECHO_SHARD), new ItemStack(Material.NETHER_STAR), new ItemStack(Material.ECHO_SHARD), new ItemStack(Material.AMETHYST_SHARD), new ItemStack(Material.ECHO_SHARD), new ItemStack(Material.AMETHYST_SHARD)};
        this.customRecipes.put(0, new StoredRecipe(0, ingredients, this.createAbilityReroller()));
    }

    private void prepareRedItemTeam() {
        Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
        this.redItemTeam = scoreboard.getTeam("hunt_red_items");
        if (this.redItemTeam == null) {
            this.redItemTeam = scoreboard.registerNewTeam("hunt_red_items");
        }
        this.redItemTeam.setColor(ChatColor.RED);
        for (World world : Bukkit.getWorlds()) {
            for (Item item : world.getEntitiesByClass(Item.class)) {
                if (this.getHuntItemType(item.getItemStack()) == null) continue;
                this.applyDroppedItemGlow(item, false);
            }
        }
    }

    private void applyDroppedItemGlow(Item item, boolean playEffects) {
        String type = this.getHuntItemType(item.getItemStack());
        if (!"mysterious_shard".equals(type) && !"bloodbound_tracker".equals(type)) {
            return;
        }
        item.setGlowing(true);
        if (this.redItemTeam != null) {
            this.redItemTeam.addEntry(item.getUniqueId().toString());
        }
        if (playEffects) {
            Location location = item.getLocation();
            item.getWorld().playSound(location, "hunt:item_drop", 0.9f, "bloodbound_tracker".equals(type) ? 0.72f : 1.05f);
            item.getWorld().spawnParticle(Particle.DUST, location.clone().add(0.0, 0.2, 0.0), 12, 0.22, 0.16, 0.22, 0.0, (Object)("bloodbound_tracker".equals(type) ? TRACKER_DUST : SHARD_DUST));
        }
    }

    private void startHeldItemEffects() {
        this.heldEffectsTask = Bukkit.getScheduler().runTaskTimer((Plugin)this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                String mainType = this.getHuntItemType(player.getInventory().getItemInMainHand());
                String offType = this.getHuntItemType(player.getInventory().getItemInOffHand());
                if (mainType != null) {
                    this.spawnHeldParticles(player, mainType, true);
                }
                if (offType == null) continue;
                this.spawnHeldParticles(player, offType, false);
            }
        }, 4L, 4L);
    }

    private void spawnHeldParticles(Player player, String type, boolean mainHand) {
        if (!"mysterious_shard".equals(type) && !"bloodbound_tracker".equals(type)) {
            return;
        }
        Location eye = player.getEyeLocation();
        Vector forward = eye.getDirection().normalize().multiply(0.48);
        Vector side = new Vector(-forward.getZ(), 0.0, forward.getX());
        if (side.lengthSquared() > 0.001) {
            side.normalize().multiply(mainHand ? 0.28 : -0.28);
        }
        Location hand = eye.clone().add(forward).add(side).subtract(0.0, 0.38, 0.0);
        player.getWorld().spawnParticle(Particle.DUST, hand, "bloodbound_tracker".equals(type) ? 2 : 1, 0.06, 0.06, 0.06, 0.0, (Object)("bloodbound_tracker".equals(type) ? TRACKER_DUST : SHARD_DUST));
    }

    private void openTrackerTargets(Player player, int requestedPage) {
        List<Player> allTargets = new ArrayList(Bukkit.getOnlinePlayers()).stream().filter(target -> !target.equals((Object)player)).filter(target -> player.isOp() || !this.vanishedPlayers.contains(target.getUniqueId()) && player.canSee(target)).sorted((first, second) -> first.getName().compareToIgnoreCase(second.getName())).toList();
        int maxPage = allTargets.isEmpty() ? 0 : (allTargets.size() - 1) / RECIPE_LIST_SLOTS.length;
        int page = Math.max(0, Math.min(requestedPage, maxPage));
        int fromIndex = page * RECIPE_LIST_SLOTS.length;
        int toIndex = Math.min(allTargets.size(), fromIndex + RECIPE_LIST_SLOTS.length);
        List<Player> targets = allTargets.subList(fromIndex, toIndex);
        TrackerHolder holder = new TrackerHolder(page);
        Inventory inventory = Bukkit.createInventory((InventoryHolder)holder, (int)54, (Component)PremiumText.mini("RIFTBOUND ARCHIVE   |   SELECT QUARRY", 0xFF9B9B, 9839168));
        holder.setInventory(inventory);
        ItemStack filler = this.menuItem(Material.BLACK_STAINED_GLASS_PANE, "&0", List.of());
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
        for (int index = 0; index < targets.size(); ++index) {
            Player target2 = targets.get(index);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta)head.getItemMeta();
            meta.setOwningPlayer((OfflinePlayer)target2);
            meta.displayName(PremiumText.mini(target2.getName().toUpperCase() + "   |   QUARRY", 16750238, 12134473));
            meta.lore(List.of(PremiumText.mini("RIGHT CLICK    |  REVEAL TRAIL", 15790839, 9607591), PremiumText.mini("TRACK WINDOW   |  05:00", 16764572, 12220717)));
            head.setItemMeta((ItemMeta)meta);
            int slot = RECIPE_LIST_SLOTS[index];
            inventory.setItem(slot, head);
            holder.targets().put(slot, target2.getUniqueId());
        }
        inventory.setItem(4, this.menuItem(Material.RECOVERY_COMPASS, "&c&lRIFTBOUND COMPASS", List.of("&7Select one online player.", "&7The trail is visible only to you.", "&8Page " + (page + 1) + "/" + (maxPage + 1))));
        if (allTargets.isEmpty()) {
            inventory.setItem(22, this.menuItem(Material.BARRIER, "&cNo trackable players", List.of("&7Nobody visible is currently online.")));
        }
        if (page > 0) {
            inventory.setItem(45, this.menuItem(Material.ARROW, "&ePrevious page", List.of()));
        }
        if (page < maxPage) {
            inventory.setItem(53, this.menuItem(Material.ARROW, "&eNext page", List.of()));
        }
        player.openInventory(inventory);
    }

    private void beginTracking(Player hunter, Player target) {
        if (!this.hasTrackerCompass(hunter)) {
            hunter.closeInventory();
            hunter.sendMessage(this.color("&6&lHUNT &8\u00bb &cYou must carry the Riftbound Compass to begin tracking."));
            return;
        }
        long remaining = this.trackerCooldownRemaining(hunter);
        if (remaining > 0L) {
            hunter.closeInventory();
            hunter.sendMessage(this.color("&6&lHUNT &8\u00bb &cYour compass is recovering for &f" + this.formatTrackerTime(remaining) + "&c."));
            return;
        }
        int durationSeconds = Math.max(10, this.getConfig().getInt("tracker.duration-seconds", 300));
        int cooldownSeconds = Math.max(0, this.getConfig().getInt("tracker.cooldown-seconds", 1800));
        if (cooldownSeconds > 0) {
            hunter.getPersistentDataContainer().set(this.trackerCooldownKey, PersistentDataType.LONG, (Object)(System.currentTimeMillis() + (long)cooldownSeconds * 1000L));
        }
        this.activeTrackers.put(hunter.getUniqueId(), new TrackingSession(target.getUniqueId(), System.currentTimeMillis() + (long)durationSeconds * 1000L));
        hunter.closeInventory();
        hunter.sendMessage(this.color("&6&lHUNT &8\u00bb &cTracking &f" + target.getName() + " &cfor " + durationSeconds / 60 + " minutes."));
        hunter.playSound(hunter.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_DEPLETE, 0.8f, 1.2f);
        target.sendMessage(PremiumText.mini("- - - - -  RIFTBOUND LOCK  - - - - -", 7216683, 0xFF6676));
        target.sendMessage(PremiumText.mini(hunter.getName().toUpperCase(), 0xFFFFFF, 13488862).append(PremiumText.mini("  IS TRACKING YOU   |   ", 16746384, 13119305)).append(PremiumText.mini(durationSeconds / 60 + " MINUTES", 16771484, 13142312)));
        target.playSound(target.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_DEPLETE, 1.0f, 0.55f);
    }

    private void startTrackingTask() {
        this.trackingTask = Bukkit.getScheduler().runTaskTimer((Plugin)this, () -> {
            long now = System.currentTimeMillis();
            for (Map.Entry<UUID, TrackingSession> entry : new HashMap<UUID, TrackingSession>(this.activeTrackers).entrySet()) {
                Player hunter = Bukkit.getPlayer((UUID)entry.getKey());
                TrackingSession session = entry.getValue();
                Player target = Bukkit.getPlayer((UUID)session.target());
                if (hunter == null || !hunter.isOnline() || now >= session.endsAt()) {
                    this.activeTrackers.remove(entry.getKey());
                    if (hunter == null) continue;
                    hunter.sendMessage(this.color("&6&lHUNT &8\u00bb &7The crimson trail has faded."));
                    continue;
                }
                if (!this.hasTrackerCompass(hunter)) {
                    this.activeTrackers.remove(entry.getKey());
                    hunter.sendActionBar((Component)Component.empty());
                    hunter.sendMessage(this.color("&6&lHUNT &8\u00bb &cThe trail collapsed because you no longer carry the compass. The cooldown remains active."));
                    hunter.playSound(hunter.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_DEPLETE, 0.65f, 0.55f);
                    continue;
                }
                if (target == null || !target.isOnline() || !hunter.isOp() && this.vanishedPlayers.contains(target.getUniqueId())) {
                    this.activeTrackers.remove(entry.getKey());
                    hunter.sendMessage(this.color("&6&lHUNT &8\u00bb &cThe target can no longer be found."));
                    continue;
                }
                long remainingSeconds = Math.max(0L, (session.endsAt() - now + 999L) / 1000L);
                if (hunter.getWorld() != target.getWorld()) {
                    hunter.sendActionBar(this.combinedTrackerHud(hunter, PremiumText.mini(target.getName().toUpperCase(), 16746384, 13184585).append(PremiumText.mini("   |   ANOTHER DIMENSION   |   ", 6646390, 9607333)).append(PremiumText.mini(this.formatTrackerTime(remainingSeconds), 0xFFFFFF, 12107724))));
                    continue;
                }
                Location origin = hunter.getEyeLocation().subtract(0.0, 0.3, 0.0);
                Location destination = target.getLocation().add(0.0, 0.9, 0.0);
                Vector difference = destination.toVector().subtract(origin.toVector());
                double distance = difference.length();
                if (distance > 0.25) {
                    Vector direction = difference.normalize();
                    double trailLength = Math.min(distance, Math.max(3.0, this.getConfig().getDouble("tracker.visible-trail-blocks", 14.0)));
                    for (double step = 0.75; step <= trailLength; step += 0.55) {
                        Location point = origin.clone().add(direction.clone().multiply(step));
                        hunter.spawnParticle(Particle.DUST, point, 1, 0.0, 0.0, 0.0, 0.0, (Object)TRACKER_DUST);
                    }
                }
                hunter.sendActionBar(this.combinedTrackerHud(hunter, PremiumText.mini(target.getName().toUpperCase(), 16746384, 13184585).append(PremiumText.mini("   |   " + Math.round(distance) + "m   |   ", 7633543, 11778759)).append(PremiumText.mini(this.formatTrackerTime(remainingSeconds), 0xFFFFFF, 12107724))));
                if (session.lastPulseSecond() == remainingSeconds || remainingSeconds % 2L != 0L) continue;
                session.lastPulseSecond(remainingSeconds);
                hunter.playSound(hunter.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.22f, 0.55f);
            }
        }, 10L, 10L);
    }

    private String formatTrackerTime(long seconds) {
        return String.format("%d:%02d", seconds / 60L, seconds % 60L);
    }

    private long trackerCooldownRemaining(Player player) {
        Long until = (Long)player.getPersistentDataContainer().get(this.trackerCooldownKey, PersistentDataType.LONG);
        if (until == null) {
            return 0L;
        }
        long remaining = (until - System.currentTimeMillis() + 999L) / 1000L;
        if (remaining <= 0L) {
            player.getPersistentDataContainer().remove(this.trackerCooldownKey);
            return 0L;
        }
        return remaining;
    }

    private boolean hasTrackerCompass(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (!this.isTracker(item)) continue;
            return true;
        }
        return false;
    }

    private Component combinedTrackerHud(Player player, Component tracker) {
        if (this.abilityManager == null) {
            return tracker;
        }
        Component ability = this.abilityManager.statusComponent(player);
        if (ability.equals((Object)Component.empty())) {
            return tracker;
        }
        return tracker.append(PremiumText.mini("     |     ", 3882824, 6843768)).append(ability);
    }

    private void loadCustomRecipes() {
        this.customRecipes.clear();
        this.recipesFile = new File(this.getDataFolder(), "custom-recipes.yml");
        this.recipesConfig = YamlConfiguration.loadConfiguration((File)this.recipesFile);
        ConfigurationSection recipes = this.recipesConfig.getConfigurationSection("recipes");
        if (recipes == null) {
            return;
        }
        int highestId = 0;
        for (String idText : recipes.getKeys(false)) {
            int id;
            try {
                id = Integer.parseInt(idText);
            }
            catch (NumberFormatException ignored) {
                this.getLogger().warning("Ignored invalid custom recipe id: " + idText);
                continue;
            }
            ItemStack output = this.recipesConfig.getItemStack("recipes." + id + ".output");
            ItemStack[] ingredients = new ItemStack[9];
            for (int index = 0; index < ingredients.length; ++index) {
                ingredients[index] = this.recipesConfig.getItemStack("recipes." + id + ".ingredients." + index);
            }
            if (!this.isUsableItem(output) || !Arrays.stream(ingredients).anyMatch(this::isUsableItem) || !this.registerCustomRecipe(id, ingredients, output)) continue;
            this.customRecipes.put(id, new StoredRecipe(id, ingredients, output));
            highestId = Math.max(highestId, id);
        }
        this.nextRecipeId = highestId + 1;
    }

    private void openRecipeBrowser(Player player, int requestedPage) {
        List ids = this.customRecipes.keySet().stream().sorted().toList();
        int maxPage = ids.isEmpty() ? 0 : (ids.size() - 1) / RECIPE_LIST_SLOTS.length;
        int page = Math.max(0, Math.min(requestedPage, maxPage));
        RecipeListHolder holder = new RecipeListHolder(page);
        Inventory inventory = Bukkit.createInventory((InventoryHolder)holder, (int)54, (Component)PremiumText.mini("FORGING ARCHIVE   |   SAVED RECIPES", 16771493, 10250277));
        holder.setInventory(inventory);
        ItemStack filler = this.menuItem(Material.BLACK_STAINED_GLASS_PANE, "&0", List.of());
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
        int startIndex = page * RECIPE_LIST_SLOTS.length;
        int shown = Math.min(RECIPE_LIST_SLOTS.length, ids.size() - startIndex);
        for (int index = 0; index < shown; ++index) {
            ArrayList<String> lore;
            int recipeId = (Integer)ids.get(startIndex + index);
            StoredRecipe recipe = this.customRecipes.get(recipeId);
            ItemStack icon = recipe.output();
            ItemMeta meta = icon.getItemMeta();
            ArrayList<String> arrayList = lore = meta.hasLore() && meta.getLore() != null ? new ArrayList<String>(meta.getLore()) : new ArrayList<String>();
            if (!lore.isEmpty()) {
                lore.add("");
            }
            lore.add(this.color("&8Recipe #" + recipeId));
            lore.add(this.color("&eClick to view the crafting layout."));
            meta.setLore(lore);
            icon.setItemMeta(meta);
            inventory.setItem(RECIPE_LIST_SLOTS[index], icon);
            holder.recipeSlots().put(RECIPE_LIST_SLOTS[index], recipeId);
        }
        if (ids.isEmpty()) {
            inventory.setItem(22, this.menuItem(Material.BARRIER, "&cNo saved recipes", List.of("&7Create your first recipe", "&7using the button below.")));
        }
        if (page > 0) {
            inventory.setItem(45, this.menuItem(Material.ARROW, "&ePrevious page", List.of()));
        }
        inventory.setItem(49, this.menuItem(Material.CRAFTING_TABLE, "&a&lCREATE RECIPE", List.of("&7Open the 3\u00d73 recipe creator.")));
        if (page < maxPage) {
            inventory.setItem(53, this.menuItem(Material.ARROW, "&eNext page", List.of()));
        }
        inventory.setItem(4, this.menuItem(Material.BOOK, "&f&lSAVED RECIPES", List.of("&7Page &f" + (page + 1) + "&7/&f" + (maxPage + 1), "&7Recipes: &f" + ids.size())));
        player.openInventory(inventory);
    }

    private void openRecipeViewer(Player player, int recipeId, int returnPage) {
        StoredRecipe recipe = this.customRecipes.get(recipeId);
        if (recipe == null) {
            player.sendMessage(this.color("&6&lHUNT &8\u00bb &cThat recipe no longer exists."));
            this.openRecipeBrowser(player, returnPage);
            return;
        }
        RecipeViewerHolder holder = new RecipeViewerHolder(recipeId, returnPage);
        Inventory inventory = Bukkit.createInventory((InventoryHolder)holder, (int)54, (Component)PremiumText.mini("FORGING SCHEMATIC   |   RECORD " + recipeId, 16771493, 10250277));
        holder.setInventory(inventory);
        ItemStack filler = this.menuItem(Material.BLACK_STAINED_GLASS_PANE, "&0", List.of());
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
        ItemStack[] ingredients = recipe.ingredients();
        for (int index = 0; index < RECIPE_INPUT_SLOTS.length; ++index) {
            inventory.setItem(RECIPE_INPUT_SLOTS[index], ingredients[index]);
        }
        inventory.setItem(24, recipe.output());
        inventory.setItem(14, this.menuItem(Material.CRAFTING_TABLE, "&c&lCRAFTING LAYOUT", List.of("&7Use this exact shape", "&7in a crafting table.")));
        inventory.setItem(23, this.menuItem(Material.ARROW, "&7Crafts &f\u2192", List.of()));
        inventory.setItem(49, this.menuItem(Material.ARROW, "&eBack to recipes", List.of()));
        player.openInventory(inventory);
    }

    private void openRecipeCreator(Player player, int returnPage) {
        RecipeEditorHolder holder = new RecipeEditorHolder(returnPage);
        Inventory inventory = Bukkit.createInventory((InventoryHolder)holder, (int)54, (Component)PremiumText.mini("FORGING LABORATORY   |   NEW SCHEMATIC", 16771493, 10250277));
        holder.setInventory(inventory);
        ItemStack filler = this.menuItem(Material.BLACK_STAINED_GLASS_PANE, "&0", List.of());
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
        for (int slot : RECIPE_INPUT_SLOTS) {
            inventory.setItem(slot, null);
        }
        inventory.setItem(24, null);
        inventory.setItem(14, this.menuItem(Material.CRAFTING_TABLE, "&c&l3\u00d73 RECIPE", List.of("&7Place one ingredient in each", "&7required crafting square.")));
        inventory.setItem(23, this.menuItem(Material.ARROW, "&7Result &f\u2192", List.of("&7Place the crafted item", "&7in the slot to the right.")));
        inventory.setItem(49, this.menuItem(Material.LIME_DYE, "&a&lSAVE RECIPE", List.of("&7Registers the recipe immediately", "&7and saves it across restarts.")));
        player.openInventory(inventory);
    }

    private void saveRecipeFromEditor(Player player, Inventory inventory, int returnPage) {
        ItemStack output = inventory.getItem(24);
        if (!this.isUsableItem(output)) {
            player.sendMessage(this.color("&6&lHUNT &8\u00bb &cPlace the crafted result in the output slot."));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.8f);
            return;
        }
        ItemStack[] ingredients = new ItemStack[9];
        boolean hasIngredient = false;
        for (int index = 0; index < RECIPE_INPUT_SLOTS.length; ++index) {
            ItemStack item = inventory.getItem(RECIPE_INPUT_SLOTS[index]);
            if (!this.isUsableItem(item)) continue;
            ingredients[index] = item.clone();
            ingredients[index].setAmount(1);
            hasIngredient = true;
        }
        if (!hasIngredient) {
            player.sendMessage(this.color("&6&lHUNT &8\u00bb &cAdd at least one crafting ingredient."));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.8f);
            return;
        }
        int id = this.nextRecipeId++;
        String path = "recipes." + id;
        this.recipesConfig.set(path + ".output", (Object)output.clone());
        for (int index = 0; index < ingredients.length; ++index) {
            this.recipesConfig.set(path + ".ingredients." + index, (Object)ingredients[index]);
        }
        try {
            this.recipesConfig.save(this.recipesFile);
        }
        catch (IOException exception) {
            --this.nextRecipeId;
            this.recipesConfig.set(path, null);
            this.getLogger().severe("Could not save custom recipe " + id + ": " + exception.getMessage());
            player.sendMessage(this.color("&6&lHUNT &8\u00bb &cThe recipe file could not be saved. Check the console."));
            return;
        }
        if (!this.registerCustomRecipe(id, ingredients, output.clone())) {
            this.recipesConfig.set(path, null);
            try {
                this.recipesConfig.save(this.recipesFile);
            }
            catch (IOException exception) {
                this.getLogger().severe("Could not remove rejected custom recipe " + id + " from storage: " + exception.getMessage());
            }
            player.sendMessage(this.color("&6&lHUNT &8\u00bb &cPaper rejected that recipe. Check the console."));
            return;
        }
        this.customRecipes.put(id, new StoredRecipe(id, ingredients, output));
        player.sendMessage(this.color("&6&lHUNT &8\u00bb &aCustom recipe #" + id + " created successfully."));
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1.15f);
        player.closeInventory();
        Bukkit.getScheduler().runTask((Plugin)this, () -> this.openRecipeBrowser(player, returnPage));
    }

    private boolean registerCustomRecipe(int id, ItemStack[] ingredients, ItemStack output) {
        int row;
        NamespacedKey key = new NamespacedKey((Plugin)this, "custom_recipe_" + id);
        Bukkit.removeRecipe((NamespacedKey)key);
        ShapedRecipe recipe = new ShapedRecipe(key, output);
        char[] symbols = "ABCDEFGHI".toCharArray();
        int minRow = 3;
        int maxRow = -1;
        int minColumn = 3;
        int maxColumn = -1;
        for (int index = 0; index < ingredients.length; ++index) {
            if (!this.isUsableItem(ingredients[index])) continue;
            row = index / 3;
            int column = index % 3;
            minRow = Math.min(minRow, row);
            maxRow = Math.max(maxRow, row);
            minColumn = Math.min(minColumn, column);
            maxColumn = Math.max(maxColumn, column);
        }
        try {
            ArrayList<String> shape = new ArrayList<String>();
            for (row = minRow; row <= maxRow; ++row) {
                StringBuilder line = new StringBuilder();
                for (int column = minColumn; column <= maxColumn; ++column) {
                    int index = row * 3 + column;
                    line.append(this.isUsableItem(ingredients[index]) ? symbols[index] : (char)' ');
                }
                shape.add(line.toString());
            }
            recipe.shape((String[])shape.toArray(String[]::new));
            for (int index = 0; index < 9; ++index) {
                if (!this.isUsableItem(ingredients[index])) continue;
                ItemStack exact = ingredients[index].clone();
                exact.setAmount(1);
                recipe.setIngredient(symbols[index], (RecipeChoice)new RecipeChoice.ExactChoice(exact));
            }
            boolean added = Bukkit.addRecipe((Recipe)recipe);
            if (added) {
                this.customRecipeKeys.add(key);
            }
            return added;
        }
        catch (IllegalArgumentException exception) {
            this.getLogger().warning("Could not register custom recipe " + id + ": " + exception.getMessage());
            return false;
        }
    }

    private boolean isUsableItem(ItemStack item) {
        return item != null && item.getType() != Material.AIR && item.getAmount() > 0;
    }

    private boolean isRecipeEditableSlot(int rawSlot) {
        if (rawSlot == 24) {
            return true;
        }
        for (int slot : RECIPE_INPUT_SLOTS) {
            if (slot != rawSlot) continue;
            return true;
        }
        return false;
    }

    private void openSettings(Player player) {
        SettingsHolder holder = new SettingsHolder();
        Inventory inventory = Bukkit.createInventory((InventoryHolder)holder, (int)45, (Component)PremiumText.mini("HUNT CONTROL MATRIX   |   SETTINGS", 0xFF9B9B, 9839168));
        holder.setInventory(inventory);
        ItemStack filler = this.menuItem(Material.BLACK_STAINED_GLASS_PANE, "&0", List.of());
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
        inventory.setItem(4, this.menuItem(Material.COMPARATOR, "&c&lHUNT SETTINGS", List.of("&7Changes save instantly.", "&7Only operators can open this menu.")));
        inventory.setItem(11, this.chanceItem(Material.HEAVY_CORE, "&dHeavy Core", "vault-rewards.heavy-core.chance-percent", true));
        inventory.setItem(15, this.chanceItem(Material.ENCHANTED_GOLDEN_APPLE, "&6Enchanted Golden Apple", "vault-rewards.enchanted-golden-apple.chance-percent", false));
        int maceCap = Math.max(0, this.getConfig().getInt("gameplay.mace-cap", 2));
        int macesIssued = Math.max(0, this.getConfig().getInt("limited-items.maces-issued", 0));
        inventory.setItem(22, this.menuItem(Material.MACE, "&bMace cap &8\u2022 &f" + maceCap, List.of("&7Issued: &f" + macesIssued + "&7/&f" + maceCap, "&7The limit is enforced automatically.", "&7Existing maces are never deleted.", "", "&aLeft-click &8\u2022 &f+1", "&cRight-click &8\u2022 &f-1", "&aShift-left &8\u2022 &f+5", "&cShift-right &8\u2022 &f-5", "&eMiddle-click &8\u2022 &fReset issued count")));
        inventory.setItem(29, this.featureItem(Material.BREWING_STAND, "&dOne-tick brewing", this.getConfig().getBoolean("gameplay.one-tick-brewing", true), "Potions finish in one server tick."));
        int strengthDuration = Math.max(1, this.getConfig().getInt("gameplay.strength-ii-duration-seconds", 480));
        inventory.setItem(27, this.featureItem(Material.BLAZE_POWDER, "&cStrength II override", this.getConfig().getBoolean("gameplay.extended-strength-ii", true), "Every brewed Strength II potion lasts " + strengthDuration / 60 + ":" + String.format("%02d", strengthDuration % 60) + ". Click to toggle."));
        int weavingDuration = Math.max(1, this.getConfig().getInt("gameplay.weaving-duration-seconds", 480));
        inventory.setItem(28, this.featureItem(Material.COBWEB, "&fWeaving override", this.getConfig().getBoolean("gameplay.extended-weaving", true), "Every brewed Weaving potion lasts " + weavingDuration / 60 + ":" + String.format("%02d", weavingDuration % 60) + ". Click to toggle."));
        inventory.setItem(31, this.featureItem(Material.VAULT, "&eReusable vaults", this.getConfig().getBoolean("gameplay.reusable-vaults", true), "Players can reuse every vault forever."));
        int cooldownSeconds = Math.max(1, this.getConfig().getInt("gameplay.trial-spawner-cooldown-seconds", 300));
        inventory.setItem(33, this.menuItem(Material.TRIAL_SPAWNER, "&bTrial spawner cooldown", List.of("&7Current: &f" + cooldownSeconds / 60 + " minutes", "&7Applied to normal and ominous spawners.")));
        inventory.setItem(35, this.menuItem(Material.ANVIL, "&fSMP anvils &8\u2022 &aENABLED", List.of("&7Anvils never take durability damage.", "&7The Too Expensive limit is disabled.")));
        inventory.setItem(40, this.menuItem(Material.BARRIER, "&cClose", List.of()));
        player.openInventory(inventory);
    }

    private ItemStack chanceItem(Material material, String name, String path, boolean ominousOnly) {
        double chance = this.clampChance(this.getConfig().getDouble(path, 0.0));
        return this.menuItem(material, name + " &8\u2022 &f" + this.formatChance(chance) + "%", List.of(ominousOnly ? "&7Source: &5Ominous vaults" : "&7Source: &fAll vaults", "", "&aLeft-click &8\u2022 &f+5%", "&cRight-click &8\u2022 &f-5%", "&aShift-left &8\u2022 &f+25%", "&cShift-right &8\u2022 &f-25%"));
    }

    private ItemStack featureItem(Material material, String name, boolean enabled, String description) {
        return this.menuItem(material, name + (enabled ? " &8\u2022 &aON" : " &8\u2022 &cOFF"), List.of("&7" + description));
    }

    private void changeChance(Player player, String path, ClickType click) {
        double change;
        switch (click) {
            case LEFT: {
                double d = 5.0;
                break;
            }
            case RIGHT: {
                double d = -5.0;
                break;
            }
            case SHIFT_LEFT: {
                double d = 25.0;
                break;
            }
            case SHIFT_RIGHT: {
                double d = -25.0;
                break;
            }
            default: {
                double d = change = 0.0;
            }
        }
        if (change == 0.0) {
            return;
        }
        double updated = this.clampChance(this.getConfig().getDouble(path, 0.0) + change);
        this.getConfig().set(path, (Object)updated);
        this.saveConfig();
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.55f, change > 0.0 ? 1.45f : 0.8f);
        this.openSettings(player);
    }

    private void changeMaceCap(Player player, ClickType click) {
        int change;
        if (click == ClickType.MIDDLE) {
            this.getConfig().set("limited-items.maces-issued", (Object)0);
            this.saveConfig();
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.7f, 1.3f);
            this.openSettings(player);
            return;
        }
        switch (click) {
            case LEFT: {
                int n = 1;
                break;
            }
            case RIGHT: {
                int n = -1;
                break;
            }
            case SHIFT_LEFT: {
                int n = 5;
                break;
            }
            case SHIFT_RIGHT: {
                int n = -5;
                break;
            }
            default: {
                int n = change = 0;
            }
        }
        if (change == 0) {
            return;
        }
        int updated = Math.max(0, Math.min(100, this.getConfig().getInt("gameplay.mace-cap", 2) + change));
        this.getConfig().set("gameplay.mace-cap", (Object)updated);
        this.saveConfig();
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.55f, change > 0 ? 1.45f : 0.8f);
        this.openSettings(player);
    }

    private double clampChance(double value) {
        return Math.max(0.0, Math.min(100.0, value));
    }

    private String formatChance(double value) {
        return value == Math.rint(value) ? Integer.toString((int)value) : String.format("%.1f", value);
    }

    private ItemStack menuItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(PremiumText.menuTitle(name));
        meta.lore(lore.stream().map(PremiumText::menuLore).toList());
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onAnvilOpen(InventoryOpenEvent event) {
        this.configureAnvilView(event.getView());
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        this.configureAnvilView((InventoryView)event.getView());
    }

    private void configureAnvilView(InventoryView view) {
        if (view instanceof AnvilView) {
            AnvilView anvil = (AnvilView)view;
            if (this.getConfig().getBoolean("gameplay.unlimited-anvil-cost", true)) {
                anvil.setMaximumRepairCost(Short.MAX_VALUE);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onAnvilDamaged(AnvilDamagedEvent event) {
        if (this.getConfig().getBoolean("gameplay.unbreakable-anvils", true)) {
            event.setBreaking(false);
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onBrewingStart(BrewingStartEvent event) {
        if (this.getConfig().getBoolean("gameplay.one-tick-brewing", true)) {
            event.setRecipeBrewTime(1);
            event.setBrewingTime(1);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onBrewComplete(BrewEvent event) {
        boolean strengthEnabled = this.getConfig().getBoolean("gameplay.extended-strength-ii", true);
        boolean weavingEnabled = this.getConfig().getBoolean("gameplay.extended-weaving", true);
        if (!strengthEnabled && !weavingEnabled) {
            return;
        }
        List results = event.getResults();
        for (int index = 0; index < results.size(); ++index) {
            boolean weaving;
            ItemMeta itemMeta;
            ItemStack result = (ItemStack)results.get(index);
            if (!this.isUsableItem(result) || !((itemMeta = result.getItemMeta()) instanceof PotionMeta)) continue;
            PotionMeta meta = (PotionMeta)itemMeta;
            PotionType baseType = meta.getBasePotionType();
            boolean strength = strengthEnabled && baseType == PotionType.STRONG_STRENGTH;
            boolean bl = weaving = weavingEnabled && baseType == PotionType.WEAVING;
            if (!strength && !weaving) continue;
            int durationSeconds = Math.max(1, this.getConfig().getInt(strength ? "gameplay.strength-ii-duration-seconds" : "gameplay.weaving-duration-seconds", 480));
            PotionEffectType effectType = strength ? PotionEffectType.STRENGTH : PotionEffectType.WEAVING;
            meta.setBasePotionType(PotionType.WATER);
            meta.removeCustomEffect(effectType);
            meta.addCustomEffect(new PotionEffect(effectType, durationSeconds * 20, strength ? 1 : 0, false, true, true), true);
            meta.setColor(strength ? Color.fromRGB((int)170, (int)38, (int)54) : Color.fromRGB((int)214, (int)220, (int)224));
            meta.displayName(PremiumText.mini((strength ? "SOVEREIGN STRENGTH II" : "WOVEN ESSENCE") + "   |   " + String.format("%02d:%02d", durationSeconds / 60, durationSeconds % 60), strength ? 16756893 : 16054266, strength ? 10821439 : 9016481));
            meta.lore(List.of(PremiumText.mini(strength ? "ALCHEMICAL OVERRIDE" : "THREADBOUND CONCOCTION", strength ? 11110283 : 12107461, strength ? 5522246 : 5594471), Component.empty(), PremiumText.mini((strength ? "STRENGTH II" : "WEAVING") + "    |  " + String.format("%02d:%02d", durationSeconds / 60, durationSeconds % 60), strength ? 0xFFAF9A : 15922680, strength ? 11741512 : 9016481), PremiumText.mini("BREWING CYCLE  |  HUNT ENHANCED", 15001581, 9476005)));
            result.setItemMeta((ItemMeta)meta);
            results.set(index, result);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onVaultUnlock(VaultChangeStateEvent event) {
        if (event.getNewState() != Vault.State.UNLOCKING || event.getPlayer() == null) {
            return;
        }
        if (this.memberFeatures != null) {
            this.memberFeatures.recordVault(event.getPlayer());
        }
        Location vaultLocation = event.getBlock().getLocation();
        if (this.getConfig().getBoolean("gameplay.reusable-vaults", true)) {
            Bukkit.getScheduler().runTaskLater((Plugin)this, () -> this.clearVaultRewardHistory(vaultLocation), 120L);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onVaultDispenseLoot(BlockDispenseLootEvent event) {
        org.bukkit.block.data.type.Vault data;
        if (event.getBlock().getType() != Material.VAULT) {
            return;
        }
        BlockData blockData = event.getBlock().getBlockData();
        boolean ominous = blockData instanceof org.bukkit.block.data.type.Vault && (data = (org.bukkit.block.data.type.Vault)blockData).isOminous();
        ArrayList<ItemStack> loot = new ArrayList<ItemStack>(event.getDispensedLoot());
        loot.removeIf(item -> item.getType() == Material.HEAVY_CORE || item.getType() == Material.ENCHANTED_GOLDEN_APPLE);
        if (ominous && this.rollChance(this.getConfig().getDouble("vault-rewards.heavy-core.chance-percent", 40.0))) {
            loot.add(new ItemStack(Material.HEAVY_CORE));
        }
        if (this.rollChance(this.getConfig().getDouble("vault-rewards.enchanted-golden-apple.chance-percent", 50.0))) {
            loot.add(new ItemStack(Material.ENCHANTED_GOLDEN_APPLE));
        }
        event.setDispensedLoot(loot);
    }

    private boolean rollChance(double percentage) {
        return ThreadLocalRandom.current().nextDouble(100.0) < this.clampChance(percentage);
    }

    private void clearVaultRewardHistory(Location location) {
        BlockState blockState = location.getBlock().getState();
        if (!(blockState instanceof Vault)) {
            return;
        }
        Vault vault = (Vault)blockState;
        for (UUID rewarded : new ArrayList(vault.getRewardedPlayers())) {
            vault.removeRewardedPlayer(rewarded);
        }
        vault.update(true, false);
    }

    @EventHandler
    public void onGameplayChunkLoad(ChunkLoadEvent event) {
        for (BlockState state : event.getChunk().getTileEntities()) {
            this.applyGameplayBlockSettings(state);
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onGameplayBlockPlace(BlockPlaceEvent event) {
        Bukkit.getScheduler().runTask((Plugin)this, () -> this.applyGameplayBlockSettings(event.getBlock().getState()));
    }

    @EventHandler
    public void onTrialSpawnerSpawn(TrialSpawnerSpawnEvent event) {
        this.applyGameplayBlockSettings((BlockState)event.getTrialSpawner());
    }

    private void refreshLoadedGameplayBlocks() {
        for (World world : Bukkit.getWorlds()) {
            for (Chunk chunk : world.getLoadedChunks()) {
                for (BlockState state : chunk.getTileEntities()) {
                    this.applyGameplayBlockSettings(state);
                }
            }
        }
    }

    private void applyGameplayBlockSettings(BlockState state) {
        org.bukkit.block.data.type.TrialSpawner data;
        if (state instanceof Vault) {
            Vault vault = (Vault)state;
            if (this.getConfig().getBoolean("gameplay.reusable-vaults", true)) {
                boolean changed = false;
                for (UUID rewarded : new ArrayList(vault.getRewardedPlayers())) {
                    changed |= vault.removeRewardedPlayer(rewarded);
                }
                if (changed) {
                    vault.update(true, false);
                }
                return;
            }
        }
        if (!(state instanceof TrialSpawner)) {
            return;
        }
        TrialSpawner spawner = (TrialSpawner)state;
        int seconds = Math.max(1, this.getConfig().getInt("gameplay.trial-spawner-cooldown-seconds", 300));
        int cooldownTicks = seconds * 20;
        boolean changed = spawner.getCooldownLength() != cooldownTicks;
        spawner.setCooldownLength(cooldownTicks);
        BlockData blockData = spawner.getBlockData();
        if (blockData instanceof org.bukkit.block.data.type.TrialSpawner && (data = (org.bukkit.block.data.type.TrialSpawner)blockData).getTrialSpawnerState() == TrialSpawner.State.COOLDOWN) {
            long desiredEnd = spawner.getWorld().getGameTime() + (long)cooldownTicks;
            if (spawner.getCooldownEnd() > desiredEnd) {
                spawner.setCooldownEnd(desiredEnd);
                changed = true;
            }
        }
        if (changed) {
            spawner.update(true, false);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onGraceDamage(EntityDamageEvent event) {
        Entity entity;
        if (this.graceActive && (entity = event.getEntity()) instanceof Player) {
            Player player = (Player)entity;
            event.setCancelled(true);
            player.setFallDistance(0.0f);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player joined = event.getPlayer();
        this.refreshHuntItemText(joined);
        if (this.altarManager != null) {
            this.altarManager.refreshInventoryText(joined);
        }
        if (this.riftStoredHelmets.containsKey(joined.getUniqueId())) {
            this.restoreRiftHelmet(joined);
        }
        if (this.vanishedPlayers.contains(joined.getUniqueId())) {
            event.setJoinMessage(null);
            Bukkit.getScheduler().runTask((Plugin)this, () -> this.setVanished(joined, true, false));
        } else if (!joined.isOp()) {
            for (UUID uuid : this.vanishedPlayers) {
                Player hidden = Bukkit.getPlayer((UUID)uuid);
                if (hidden == null || !hidden.isOnline()) continue;
                joined.hidePlayer((Plugin)this, hidden);
            }
        }
        if (this.graceActive && this.graceBar != null) {
            this.graceBar.addPlayer(joined);
            this.applyGraceSaturation(joined);
        }
    }

    private void refreshHuntItemText(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (!this.isUsableItem(item) || !item.hasItemMeta()) continue;
            String type = (String)item.getItemMeta().getPersistentDataContainer().get(this.huntItemKey, PersistentDataType.STRING);
            ItemStack template = null;
            if ("mysterious_shard".equals(type)) {
                int number = (Integer)item.getItemMeta().getPersistentDataContainer().getOrDefault(new NamespacedKey((Plugin)this, "shard_number"), PersistentDataType.INTEGER, (Object)1);
                template = this.createMysteriousShard(Math.max(1, Math.min(4, number)));
            } else if ("bloodbound_tracker".equals(type)) {
                template = this.createTrackerCompass();
            } else if ("ability_reroller".equals(type)) {
                template = this.createAbilityReroller();
            } else if ("rift_overlay".equals(type)) {
                template = this.createRiftOverlayHelmet();
            }
            if (template == null) continue;
            ItemMeta current = item.getItemMeta();
            ItemMeta styled = template.getItemMeta();
            current.displayName(styled.displayName());
            current.lore(styled.lore());
            item.setItemMeta(current);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.pendingAbilityRolls.remove(event.getPlayer().getUniqueId());
        this.cancelRiftTest(event.getPlayer(), false);
        this.restoreRiftHelmet(event.getPlayer());
        this.forcedGlidingPlayers.remove(event.getPlayer().getUniqueId());
        this.activeTrackers.remove(event.getPlayer().getUniqueId());
        if (this.vanishedPlayers.contains(event.getPlayer().getUniqueId())) {
            event.setQuitMessage(null);
            for (Player viewer : Bukkit.getOnlinePlayers()) {
                if (!viewer.isOp() || viewer.equals((Object)event.getPlayer())) continue;
                viewer.sendMessage(this.color("&8[&cVanish&8] &7" + event.getPlayer().getName() + " disconnected."));
            }
        }
        if (this.graceBar != null) {
            this.graceBar.removePlayer(event.getPlayer());
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();
        Player killer = dead.getKiller();
        if (this.vanishedPlayers.contains(dead.getUniqueId()) || killer != null && this.vanishedPlayers.contains(killer.getUniqueId())) {
            String detailedMessage = event.getDeathMessage();
            event.setDeathMessage(null);
            for (Player viewer : Bukkit.getOnlinePlayers()) {
                if (viewer.isOp() && detailedMessage != null) {
                    viewer.sendMessage(detailedMessage);
                    continue;
                }
                if (viewer.isOp() || this.vanishedPlayers.contains(dead.getUniqueId())) continue;
                viewer.sendMessage(this.color("&e" + dead.getName() + " died"));
            }
        }
    }

    @EventHandler
    public void onVanishedChat(AsyncChatEvent event) {
        if (!this.vanishedPlayers.contains(event.getPlayer().getUniqueId())) {
            return;
        }
        event.viewers().removeIf(audience -> {
            Player viewer;
            return audience instanceof Player && !(viewer = (Player)audience).isOp() && !viewer.equals((Object)event.getPlayer());
        });
    }

    @EventHandler
    public void onVanishedAdvancement(PlayerAdvancementDoneEvent event) {
        if (this.vanishedPlayers.contains(event.getPlayer().getUniqueId())) {
            event.message(null);
        }
    }

    @EventHandler
    public void onServerListPing(ServerListPingEvent event) {
        if (!(event instanceof PaperServerListPingEvent)) {
            return;
        }
        PaperServerListPingEvent paperEvent = (PaperServerListPingEvent)event;
        int visiblePlayers = (int)Bukkit.getOnlinePlayers().stream().filter(player -> !this.vanishedPlayers.contains(player.getUniqueId())).count();
        paperEvent.setNumPlayers(visiblePlayers);
        paperEvent.getListedPlayers().removeIf(info -> this.vanishedPlayers.contains(info.id()));
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onHiddenPlayerCommand(PlayerCommandPreprocessEvent event) {
        Player sender = event.getPlayer();
        if (sender.isOp()) {
            return;
        }
        String[] parts = event.getMessage().substring(1).split("\\s+");
        if (parts.length == 0) {
            return;
        }
        String base = parts[0].toLowerCase();
        if (base.contains(":")) {
            base = base.substring(base.indexOf(58) + 1);
        }
        if (base.equals("list") || base.equals("online")) {
            event.setCancelled(true);
            List<String> visibleNames = Bukkit.getOnlinePlayers().stream().filter(player -> !this.vanishedPlayers.contains(player.getUniqueId())).map(Player::getName).sorted(String.CASE_INSENSITIVE_ORDER).toList();
            sender.sendMessage(this.color("&eThere are &f" + visibleNames.size() + "&e of a max of &f" + Bukkit.getMaxPlayers() + "&e players online: &f" + String.join((CharSequence)", ", visibleNames)));
            return;
        }
        if (parts.length < 2 || !List.of("msg", "tell", "w", "whisper", "tpa", "tpahere", "tp").contains(base)) {
            return;
        }
        String requestedName = parts[1];
        for (UUID uuid : this.vanishedPlayers) {
            Player hidden = Bukkit.getPlayer((UUID)uuid);
            if (hidden == null || !hidden.getName().equalsIgnoreCase(requestedName)) continue;
            event.setCancelled(true);
            sender.sendMessage(this.color("&cNo player was found with that name."));
            return;
        }
    }

    @EventHandler
    public void onAbilityRerollerUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND || event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK || !"ability_reroller".equals(this.getHuntItemType(event.getItem()))) {
            return;
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (this.abilityManager == null || this.shouldSuppressAbilityBar(player)) {
            player.sendMessage(this.color("&6&lHUNT &8\u00bb &eWait until the current Hunt sequence finishes."));
            return;
        }
        if (!this.abilityManager.queueReroll(player)) {
            player.sendMessage(this.color("&6&lHUNT &8\u00bb &eYour private ability roll is already in progress."));
            return;
        }
        ItemStack held = player.getInventory().getItemInMainHand();
        if (held.getAmount() <= 1) {
            player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
        } else {
            held.setAmount(held.getAmount() - 1);
        }
        player.playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.85f, 1.25f);
    }

    @EventHandler
    public void onTrackerUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND || event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK || !this.isTracker(event.getItem())) {
            return;
        }
        event.setCancelled(true);
        long remaining = this.trackerCooldownRemaining(event.getPlayer());
        if (remaining > 0L) {
            event.getPlayer().sendMessage(this.color("&6&lHUNT &8\u00bb &cYour compass is recovering for &f" + this.formatTrackerTime(remaining) + "&c."));
            event.getPlayer().playSound(event.getPlayer().getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.7f, 0.65f);
            return;
        }
        this.openTrackerTargets(event.getPlayer(), 0);
        event.getPlayer().playSound(event.getPlayer().getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_AMBIENT, 0.55f, 1.25f);
    }

    @EventHandler
    public void onTrackerCraft(CraftItemEvent event) {
        if (!this.isTracker(event.getRecipe().getResult())) {
            return;
        }
        if (this.getConfig().getBoolean("limited-items.tracker-issued", false)) {
            event.setCancelled(true);
            HumanEntity humanEntity = event.getWhoClicked();
            if (humanEntity instanceof Player) {
                Player player = (Player)humanEntity;
                player.sendMessage(this.color("&6&lHUNT &8\u00bb &cThe unique Riftbound Compass already exists."));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.7f);
            }
            return;
        }
        this.getConfig().set("limited-items.tracker-issued", (Object)true);
        this.saveConfig();
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onMaceCraft(CraftItemEvent event) {
        if (event.getRecipe().getResult().getType() != Material.MACE) {
            return;
        }
        if (this.altarManager != null && this.altarManager.isSovereignMace(event.getRecipe().getResult())) {
            return;
        }
        if (event.isShiftClick()) {
            event.setCancelled(true);
            HumanEntity humanEntity = event.getWhoClicked();
            if (humanEntity instanceof Player) {
                Player player = (Player)humanEntity;
                player.sendMessage(this.color("&6&lHUNT &8\u00bb &eCraft capped maces one at a time."));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.75f, 0.75f);
            }
            return;
        }
        if (!this.reserveMaceIssue()) {
            event.setCancelled(true);
            HumanEntity humanEntity = event.getWhoClicked();
            if (humanEntity instanceof Player) {
                Player player = (Player)humanEntity;
                int cap = Math.max(0, this.getConfig().getInt("gameplay.mace-cap", 2));
                player.sendMessage(this.color("&6&lHUNT &8\u00bb &cThe server-wide mace cap of &f" + cap + " &chas been reached."));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.85f, 0.55f);
            }
        } else {
            HumanEntity humanEntity = event.getWhoClicked();
            if (humanEntity instanceof Player) {
                Player player = (Player)humanEntity;
                if (this.memberFeatures != null) {
                    this.memberFeatures.recordMace(player);
                }
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onCrafterMaceCraft(CrafterCraftEvent event) {
        if (event.getResult().getType() == Material.MACE && !this.reserveMaceIssue()) {
            event.setCancelled(true);
        }
    }

    private boolean reserveMaceIssue() {
        int cap = Math.max(0, this.getConfig().getInt("gameplay.mace-cap", 2));
        int issued = Math.max(0, this.getConfig().getInt("limited-items.maces-issued", 0));
        if (issued >= cap) {
            return false;
        }
        this.getConfig().set("limited-items.maces-issued", (Object)(issued + 1));
        this.saveConfig();
        return true;
    }

    @EventHandler
    public void onHuntItemSpawn(ItemSpawnEvent event) {
        this.applyDroppedItemGlow(event.getEntity(), true);
    }

    @EventHandler
    public void onHuntItemDespawn(ItemDespawnEvent event) {
        if (this.redItemTeam != null) {
            this.redItemTeam.removeEntry(event.getEntity().getUniqueId().toString());
        }
    }

    @EventHandler
    public void onRiftHelmetDrop(PlayerDropItemEvent event) {
        if ("rift_overlay".equals(this.getHuntItemType(event.getItemDrop().getItemStack()))) {
            event.setCancelled(true);
            return;
        }
        if (this.isTracker(event.getItemDrop().getItemStack())) {
            Player player = event.getPlayer();
            Bukkit.getScheduler().runTask((Plugin)this, () -> {
                if (!this.activeTrackers.containsKey(player.getUniqueId()) || this.hasTrackerCompass(player)) {
                    return;
                }
                this.activeTrackers.remove(player.getUniqueId());
                player.sendActionBar((Component)Component.empty());
                player.sendMessage(this.color("&6&lHUNT &8\u00bb &cThe trail collapsed because you dropped the compass. The cooldown remains active."));
                player.playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_DEPLETE, 0.65f, 0.55f);
            });
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onRiftHelmetMove(InventoryClickEvent event) {
        Player player;
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player) || !this.riftActivePlayers.contains((player = (Player)humanEntity).getUniqueId())) {
            return;
        }
        if ("rift_overlay".equals(this.getHuntItemType(event.getCurrentItem())) || "rift_overlay".equals(this.getHuntItemType(event.getCursor()))) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onTrackerInventoryClick(InventoryClickEvent event) {
        InventoryHolder inventoryHolder = event.getView().getTopInventory().getHolder();
        if (!(inventoryHolder instanceof TrackerHolder)) {
            return;
        }
        TrackerHolder holder = (TrackerHolder)inventoryHolder;
        event.setCancelled(true);
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        int slot = event.getRawSlot();
        if (slot == 45 && holder.page() > 0) {
            this.openTrackerTargets(player, holder.page() - 1);
            return;
        }
        if (slot == 53) {
            this.openTrackerTargets(player, holder.page() + 1);
            return;
        }
        UUID targetId = holder.targets().get(slot);
        if (targetId == null) {
            return;
        }
        Player target = Bukkit.getPlayer((UUID)targetId);
        if (target == null || !target.isOnline() || !player.isOp() && this.vanishedPlayers.contains(targetId)) {
            player.sendMessage(this.color("&6&lHUNT &8\u00bb &cThat player can no longer be tracked."));
            this.openTrackerTargets(player, holder.page());
            return;
        }
        this.beginTracking(player, target);
    }

    @EventHandler
    public void onSettingsInventoryClick(InventoryClickEvent event) {
        Player player;
        if (!(event.getView().getTopInventory().getHolder() instanceof SettingsHolder)) {
            return;
        }
        event.setCancelled(true);
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player) || !(player = (Player)humanEntity).isOp()) {
            return;
        }
        if (event.getRawSlot() == 11) {
            this.changeChance(player, "vault-rewards.heavy-core.chance-percent", event.getClick());
        } else if (event.getRawSlot() == 15) {
            this.changeChance(player, "vault-rewards.enchanted-golden-apple.chance-percent", event.getClick());
        } else if (event.getRawSlot() == 22) {
            this.changeMaceCap(player, event.getClick());
        } else if (event.getRawSlot() == 27) {
            this.toggleSetting(player, "gameplay.extended-strength-ii");
        } else if (event.getRawSlot() == 28) {
            this.toggleSetting(player, "gameplay.extended-weaving");
        } else if (event.getRawSlot() == 29) {
            this.toggleSetting(player, "gameplay.one-tick-brewing");
        } else if (event.getRawSlot() == 31) {
            this.toggleSetting(player, "gameplay.reusable-vaults");
        } else if (event.getRawSlot() == 40) {
            player.closeInventory();
        }
    }

    private void toggleSetting(Player player, String path) {
        boolean enabled = !this.getConfig().getBoolean(path, true);
        this.getConfig().set(path, (Object)enabled);
        this.saveConfig();
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, enabled ? 1.45f : 0.72f);
        this.openSettings(player);
    }

    @EventHandler
    public void onRecipeInventoryClick(InventoryClickEvent event) {
        InventoryHolder topHolder = event.getView().getTopInventory().getHolder();
        if (topHolder instanceof RecipeListHolder) {
            RecipeListHolder holder = (RecipeListHolder)topHolder;
            event.setCancelled(true);
            HumanEntity humanEntity = event.getWhoClicked();
            if (!(humanEntity instanceof Player)) {
                return;
            }
            Player player = (Player)humanEntity;
            int rawSlot = event.getRawSlot();
            if (rawSlot == 49) {
                this.openRecipeCreator(player, holder.page());
            } else if (rawSlot == 45 && holder.page() > 0) {
                this.openRecipeBrowser(player, holder.page() - 1);
            } else if (rawSlot == 53) {
                this.openRecipeBrowser(player, holder.page() + 1);
            } else if (holder.recipeSlots().containsKey(rawSlot)) {
                this.openRecipeViewer(player, holder.recipeSlots().get(rawSlot), holder.page());
            }
            return;
        }
        if (topHolder instanceof RecipeViewerHolder) {
            HumanEntity rawSlot;
            RecipeViewerHolder holder = (RecipeViewerHolder)topHolder;
            event.setCancelled(true);
            if (event.getRawSlot() == 49 && (rawSlot = event.getWhoClicked()) instanceof Player) {
                Player player = (Player)rawSlot;
                this.openRecipeBrowser(player, holder.returnPage());
            }
            return;
        }
        if (!(topHolder instanceof RecipeEditorHolder)) {
            return;
        }
        RecipeEditorHolder editorHolder = (RecipeEditorHolder)topHolder;
        int rawSlot = event.getRawSlot();
        if (rawSlot < 0) {
            return;
        }
        if (rawSlot < event.getView().getTopInventory().getSize()) {
            if (rawSlot == 49) {
                event.setCancelled(true);
                HumanEntity humanEntity = event.getWhoClicked();
                if (humanEntity instanceof Player) {
                    Player player = (Player)humanEntity;
                    this.saveRecipeFromEditor(player, event.getView().getTopInventory(), editorHolder.returnPage());
                }
                return;
            }
            if (!this.isRecipeEditableSlot(rawSlot)) {
                event.setCancelled(true);
            }
            return;
        }
        if (event.isShiftClick() || event.getClick() == ClickType.DOUBLE_CLICK) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onRecipeInventoryDrag(InventoryDragEvent event) {
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof RecipeListHolder || holder instanceof RecipeViewerHolder || holder instanceof TrackerHolder || holder instanceof SettingsHolder) {
            event.setCancelled(true);
            return;
        }
        if (!(holder instanceof RecipeEditorHolder)) {
            return;
        }
        int topSize = event.getView().getTopInventory().getSize();
        Iterator iterator = event.getRawSlots().iterator();
        while (iterator.hasNext()) {
            int rawSlot = (Integer)iterator.next();
            if (rawSlot >= topSize || this.isRecipeEditableSlot(rawSlot)) continue;
            event.setCancelled(true);
            return;
        }
    }

    @EventHandler
    public void onRecipeInventoryClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof RecipeEditorHolder)) {
            return;
        }
        Player player = (Player)event.getPlayer();
        ArrayList<ItemStack> returning = new ArrayList<ItemStack>();
        for (int slot : RECIPE_INPUT_SLOTS) {
            ItemStack item = event.getInventory().getItem(slot);
            if (!this.isUsableItem(item)) continue;
            returning.add(item.clone());
            event.getInventory().setItem(slot, null);
        }
        ItemStack output = event.getInventory().getItem(24);
        if (this.isUsableItem(output)) {
            returning.add(output.clone());
            event.getInventory().setItem(24, null);
        }
        for (ItemStack item : returning) {
            HashMap overflow = player.getInventory().addItem(new ItemStack[]{item});
            for (ItemStack leftover : overflow.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
        }
    }

    private void cancelCinematic() {
        for (BukkitTask task : new ArrayList<BukkitTask>(this.cinematicTasks)) {
            task.cancel();
        }
        this.cinematicTasks.clear();
        this.pendingAbilityRolls.clear();
        this.restoreAllRiftHelmets();
        this.cinematicRunning = false;
    }

    private int visibleLength(String text) {
        return ChatColor.stripColor((String)text).length();
    }

    private String color(String text) {
        return PremiumText.legacyStyled(text);
    }

    private void onRiftCinematicComplete(Player player) {
        if (this.pendingAbilityRolls.remove(player.getUniqueId()) && this.abilityManager != null) {
            this.abilityManager.queueReroll(player);
        }
    }

    boolean isDamageBlockedByTrust(Player victim, Player attacker) {
        return this.memberFeatures != null && this.memberFeatures.blocksDamage(victim, attacker);
    }

    boolean dealHuntDamage(Player attacker, Player victim, double heartsDamage, DamageType damageType) {
        if (attacker == null || victim == null || attacker.equals((Object)victim) || victim.isDead() || this.graceActive || victim.isInvulnerable() || victim.getGameMode() == GameMode.CREATIVE || victim.getGameMode() == GameMode.SPECTATOR) {
            return false;
        }
        DamageSource source = DamageSource.builder((DamageType)damageType).withCausingEntity((Entity)attacker).withDirectEntity((Entity)attacker).withDamageLocation(victim.getLocation()).build();
        EntityDamageEvent.DamageCause cause = damageType == DamageType.LIGHTNING_BOLT ? EntityDamageEvent.DamageCause.LIGHTNING : EntityDamageEvent.DamageCause.MAGIC;
        EntityDamageByEntityEvent event = new EntityDamageByEntityEvent((Entity)attacker, (Entity)victim, cause, source, Math.max(0.0, heartsDamage));
        Bukkit.getPluginManager().callEvent((Event)event);
        if (event.isCancelled() || event.getFinalDamage() <= 0.0) {
            return false;
        }
        double applied = AbsorptionDamage.clamp(victim, event.getFinalDamage());
        victim.setLastDamageCause((EntityDamageEvent)event);
        victim.setLastDamage(applied);
        victim.setNoDamageTicks(0);
        AbsorptionDamage.apply(victim, applied);
        if (!victim.isDead()) {
            victim.setNoDamageTicks(10);
            victim.playEffect(EntityEffect.HURT);
        }
        return true;
    }

    boolean shouldSuppressAbilityBar(Player player) {
        return this.cinematicRunning || this.activeTrackers.containsKey(player.getUniqueId()) || this.riftManager != null && this.riftManager.session(player) != null;
    }

    boolean isGraceActive() {
        return this.graceActive;
    }

    boolean handleAltarWeaponSwap(PlayerSwapHandItemsEvent event) {
        return this.altarManager != null && this.altarManager.handleWeaponSwap(event);
    }

    private static final class RecipeEditorHolder
    implements InventoryHolder {
        private final int returnPage;
        private Inventory inventory;

        private RecipeEditorHolder(int returnPage) {
            this.returnPage = returnPage;
        }

        private int returnPage() {
            return this.returnPage;
        }

        private void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private static final class StoredRecipe {
        private final int id;
        private final ItemStack[] ingredients;
        private final ItemStack output;

        private StoredRecipe(int id, ItemStack[] ingredients, ItemStack output) {
            this.id = id;
            this.ingredients = new ItemStack[9];
            for (int index = 0; index < this.ingredients.length; ++index) {
                this.ingredients[index] = ingredients[index] == null ? null : ingredients[index].clone();
            }
            this.output = output.clone();
        }

        private ItemStack[] ingredients() {
            ItemStack[] copy = new ItemStack[this.ingredients.length];
            for (int index = 0; index < this.ingredients.length; ++index) {
                copy[index] = this.ingredients[index] == null ? null : this.ingredients[index].clone();
            }
            return copy;
        }

        private ItemStack output() {
            return this.output.clone();
        }
    }

    private static final class TrackerHolder
    implements InventoryHolder {
        private final int page;
        private final Map<Integer, UUID> targets = new HashMap<Integer, UUID>();
        private Inventory inventory;

        private TrackerHolder(int page) {
            this.page = page;
        }

        private int page() {
            return this.page;
        }

        private Map<Integer, UUID> targets() {
            return this.targets;
        }

        private void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private static final class TrackingSession {
        private final UUID target;
        private final long endsAt;
        private long lastPulseSecond = -1L;

        private TrackingSession(UUID target, long endsAt) {
            this.target = target;
            this.endsAt = endsAt;
        }

        private UUID target() {
            return this.target;
        }

        private long endsAt() {
            return this.endsAt;
        }

        private long lastPulseSecond() {
            return this.lastPulseSecond;
        }

        private void lastPulseSecond(long value) {
            this.lastPulseSecond = value;
        }
    }

    private static final class RecipeListHolder
    implements InventoryHolder {
        private final int page;
        private final Map<Integer, Integer> recipeSlots = new HashMap<Integer, Integer>();
        private Inventory inventory;

        private RecipeListHolder(int page) {
            this.page = page;
        }

        private int page() {
            return this.page;
        }

        private Map<Integer, Integer> recipeSlots() {
            return this.recipeSlots;
        }

        private void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private static final class RecipeViewerHolder
    implements InventoryHolder {
        private final int recipeId;
        private final int returnPage;
        private Inventory inventory;

        private RecipeViewerHolder(int recipeId, int returnPage) {
            this.recipeId = recipeId;
            this.returnPage = returnPage;
        }

        private int returnPage() {
            return this.returnPage;
        }

        private void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private static final class SettingsHolder
    implements InventoryHolder {
        private Inventory inventory;

        private SettingsHolder() {
        }

        private void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        public Inventory getInventory() {
            return this.inventory;
        }
    }
}

