/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntsmp.crimson;

import java.lang.invoke.CallSite;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import me.judee.huntsmp.crimson.HuntBridge;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.TabCompleteEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class CrimsonService
implements Listener {
    private static final Component PREFIX = ((TextComponent)Component.text((String)"CRIMSON ", (TextColor)NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD)).append(Component.text((String)"\u00bb ", (TextColor)NamedTextColor.DARK_GRAY).decoration(TextDecoration.BOLD, false));
    private static final String WEAPON_ID = "crimson";
    private static final UUID CRIMSON_PACK_ID = UUID.fromString("7b3f9470-0714-4c74-91e5-1c4f21d3f008");
    private static final String CRIMSON_PACK_URL = "https://raw.githubusercontent.com/4judeee-lang/HuntSMP2/main/4judeeWeaponsOverlay-v8.zip";
    private static final byte[] CRIMSON_PACK_SHA1 = HexFormat.of().parseHex("1cfb80dc18491a25e8a7b59f0eb185b7bd6dfd53");
    private static final Particle.DustOptions BEAM_DUST = new Particle.DustOptions(Color.fromRGB((int)215, (int)12, (int)66), 1.35f);
    private static final Particle.DustOptions BEAM_CORE_DUST = new Particle.DustOptions(Color.fromRGB((int)255, (int)74, (int)124), 1.8f);
    private static final Particle.DustOptions BEAM_EDGE_DUST = new Particle.DustOptions(Color.fromRGB((int)105, (int)0, (int)38), 1.15f);
    private final JavaPlugin plugin;
    private final HuntBridge huntBridge;
    private final NamespacedKey bladeKey;
    private final NamespacedKey bladeIdKey;
    private final NamespacedKey sharpnessKey;
    private final NamespacedKey huntWeaponKey;
    private final NamespacedKey altarRoleKey;
    private final NamespacedKey altarGroupKey;
    private final Set<UUID> altarRelics = new HashSet<UUID>();
    private final Set<UUID> glowingDrops = new HashSet<UUID>();
    private final Set<BukkitTask> activeBeams = new HashSet<BukkitTask>();
    private final Map<UUID, Long> lastBeamUse = new HashMap<UUID, Long>();
    private final Map<UUID, BukkitTask> activeBurns = new HashMap<UUID, BukkitTask>();
    private final Map<UUID, HitCredit> hitCredits = new HashMap<UUID, HitCredit>();
    private BukkitTask animationTask;
    private Team droppedBladeTeam;

    public CrimsonService(JavaPlugin javaPlugin, HuntBridge huntBridge) {
        this.plugin = javaPlugin;
        this.huntBridge = huntBridge;
        this.bladeKey = new NamespacedKey((Plugin)javaPlugin, "crimson_blade");
        this.bladeIdKey = new NamespacedKey((Plugin)javaPlugin, "crimson_blade_id");
        this.sharpnessKey = new NamespacedKey((Plugin)javaPlugin, "crimson_sharpness");
        this.huntWeaponKey = new NamespacedKey("huntsmp", "altar_weapon");
        this.altarRoleKey = new NamespacedKey((Plugin)javaPlugin, "altar_role");
        this.altarGroupKey = new NamespacedKey((Plugin)javaPlugin, "altar_group");
    }

    public void start() {
        Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
        this.droppedBladeTeam = scoreboard.getTeam("crimson_drops");
        if (this.droppedBladeTeam == null) {
            this.droppedBladeTeam = scoreboard.registerNewTeam("crimson_drops");
        }
        this.droppedBladeTeam.setColor(ChatColor.RED);
        for (World world : Bukkit.getWorlds()) {
            for (ItemDisplay itemDisplay : world.getEntitiesByClass(ItemDisplay.class)) {
                if (!"relic".equals(itemDisplay.getPersistentDataContainer().get(this.altarRoleKey, PersistentDataType.STRING))) continue;
                this.altarRelics.add(itemDisplay.getUniqueId());
            }
            for (ItemDisplay itemDisplay : world.getEntitiesByClass(Item.class)) {
                this.applyDroppedGlow((Item)itemDisplay);
            }
        }
        Bukkit.getOnlinePlayers().forEach(this::refreshBlades);
        long l = Math.max(2L, this.plugin.getConfig().getLong("visuals.held-fragment-period-ticks", 4L));
        this.animationTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::animate, 1L, l);
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> Bukkit.getOnlinePlayers().forEach(this::sendCrimsonPack), 60L);
    }

    public void shutdown() {
        if (this.animationTask != null) {
            this.animationTask.cancel();
        }
        for (BukkitTask object : this.activeBurns.values()) {
            object.cancel();
        }
        for (BukkitTask bukkitTask : this.activeBeams) {
            bukkitTask.cancel();
        }
        this.activeBeams.clear();
        this.activeBurns.clear();
        for (UUID uUID : new HashSet<UUID>(this.glowingDrops)) {
            Entity entity = Bukkit.getEntity((UUID)uUID);
            if (entity instanceof Item) {
                Item item = (Item)entity;
                this.clearDroppedGlow(item);
                continue;
            }
            if (this.droppedBladeTeam == null) continue;
            this.droppedBladeTeam.removeEntry(uUID.toString());
        }
        this.glowingDrops.clear();
        this.lastBeamUse.clear();
        this.hitCredits.clear();
        this.altarRelics.clear();
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onHuntCommand(PlayerCommandPreprocessEvent playerCommandPreprocessEvent) {
        String string = playerCommandPreprocessEvent.getMessage().substring(1).trim();
        if (string.isEmpty()) {
            return;
        }
        String[] stringArray = string.split("\\s+");
        String string2 = stringArray[0].toLowerCase(Locale.ROOT);
        if (string2.contains(":")) {
            string2 = string2.substring(string2.indexOf(58) + 1);
        }
        if (!string2.equals("hunt") || stringArray.length < 3 || !stringArray[1].equalsIgnoreCase("altar")) {
            return;
        }
        Player player = playerCommandPreprocessEvent.getPlayer();
        if (stringArray.length == 3 && stringArray[2].equalsIgnoreCase("remove")) {
            ItemDisplay itemDisplay = this.findLookedAtAltar(player, 12.0);
            if (itemDisplay != null) {
                playerCommandPreprocessEvent.setCancelled(true);
                if (!this.canAdmin(player)) {
                    this.deny(player);
                    return;
                }
                this.collapseAltar(itemDisplay, itemDisplay.getLocation(), null, false);
                player.sendMessage(PREFIX.append((Component)Component.text((String)"The Crimson altar has been removed.", (TextColor)NamedTextColor.GRAY)));
            }
            return;
        }
        if (stringArray.length == 4 && (stringArray[2].equalsIgnoreCase("give") || stringArray[2].equalsIgnoreCase("spawn")) && (stringArray[3].equalsIgnoreCase(WEAPON_ID) || stringArray[3].equalsIgnoreCase("crimson_blade"))) {
            playerCommandPreprocessEvent.setCancelled(true);
            if (!this.canAdmin(player)) {
                this.deny(player);
                return;
            }
            if (stringArray[2].equalsIgnoreCase("give")) {
                this.giveOrDrop(player, this.createBlade());
                player.sendMessage(PREFIX.append((Component)Component.text((String)"You received the Crimson Blade.", (TextColor)NamedTextColor.RED)));
                player.playSound(player.getLocation(), Sound.BLOCK_VAULT_EJECT_ITEM, 0.9f, 0.9f);
            } else {
                this.spawnAltar(player);
            }
        }
    }

    @EventHandler
    public void onTabComplete(TabCompleteEvent tabCompleteEvent) {
        ArrayList<String> arrayList;
        Player player;
        Object object = tabCompleteEvent.getSender();
        if (!(object instanceof Player) || !this.canAdmin(player = (Player)object)) {
            return;
        }
        object = tabCompleteEvent.getBuffer().toLowerCase(Locale.ROOT);
        if (!((String)object).matches("/?(?:[a-z0-9_.-]+:)?hunt\\s+altar\\s+(?:give|spawn)\\s+[^\\s]*")) {
            return;
        }
        String string = ((String)object).substring(((String)object).lastIndexOf(32) + 1);
        if (WEAPON_ID.startsWith(string) && !(arrayList = new ArrayList<String>(tabCompleteEvent.getCompletions())).contains(WEAPON_ID)) {
            arrayList.add(WEAPON_ID);
            arrayList.sort(String.CASE_INSENSITIVE_ORDER);
            tabCompleteEvent.setCompletions(arrayList);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onCrimsonActivation(PlayerInteractEvent playerInteractEvent) {
        if (playerInteractEvent.getHand() != EquipmentSlot.HAND || !playerInteractEvent.getPlayer().isSneaking() || !playerInteractEvent.getAction().isRightClick()) {
            return;
        }
        Player player = playerInteractEvent.getPlayer();
        ItemStack itemStack = player.getInventory().getItemInMainHand();
        if (!this.isBlade(itemStack)) {
            return;
        }
        this.refreshBladePresentation(itemStack);
        playerInteractEvent.setCancelled(true);
        long l = System.currentTimeMillis();
        long l2 = Math.max(250L, this.plugin.getConfig().getLong("beam.anti-double-fire-millis", 750L));
        long l3 = this.lastBeamUse.getOrDefault(player.getUniqueId(), 0L);
        if (l - l3 < l2) {
            return;
        }
        this.lastBeamUse.put(player.getUniqueId(), l);
        this.fireBeam(player, itemStack);
    }

    private void fireBeam(Player player, ItemStack itemStack) {
        double d = Math.max(4.0, this.plugin.getConfig().getDouble("beam.range-blocks", 36.0));
        double d2 = Math.max(0.75, this.plugin.getConfig().getDouble("beam.radius-blocks", 2.25));
        double d3 = Math.max(0.0, this.plugin.getConfig().getDouble("beam.direct-true-damage", 6.0));
        Location location = player.getEyeLocation();
        Vector vector = location.getDirection().normalize();
        RayTraceResult rayTraceResult = player.getWorld().rayTraceBlocks(location, vector, d);
        double d4 = rayTraceResult == null ? d : location.toVector().distance(rayTraceResult.getHitPosition());
        ArrayList<BeamVictim> arrayList = new ArrayList<BeamVictim>();
        for (Object object : player.getWorld().getPlayers()) {
            Vector object2;
            double d5;
            if (object.equals((Object)player) || object.isDead() || !player.canSee((Player)object) || this.huntBridge.isTrusted((Player)object, player) || (d5 = (object2 = object.getLocation().add(0.0, 1.0, 0.0).toVector().subtract(location.toVector())).dot(vector)) < 0.0 || d5 > d4) continue;
            Vector vector2 = location.toVector().add(vector.clone().multiply(d5));
            double d6 = object.getLocation().add(0.0, 1.0, 0.0).toVector().distanceSquared(vector2);
            if (!(d6 <= d2 * d2) || !player.hasLineOfSight((Entity)object)) continue;
            arrayList.add(new BeamVictim((Player)object, d5));
        }
        arrayList.sort(Comparator.comparingDouble(BeamVictim::distance));
        this.renderBeam(player, location, vector, d4);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 0.75f, 1.55f);
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.8f, 1.8f);
        player.sendActionBar(((TextComponent)((TextComponent)Component.text((String)"\u2726 CRIMSON BEAM", (TextColor)NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD)).append(Component.text((String)"  \u2022  ", (TextColor)NamedTextColor.DARK_GRAY).decoration(TextDecoration.BOLD, false))).append(Component.text((String)(arrayList.size() + " marked"), (TextColor)NamedTextColor.RED).decoration(TextDecoration.BOLD, false)));
        String string = this.getOrAssignBladeId(itemStack);
        for (BeamVictim beamVictim : arrayList) {
            Player player2 = beamVictim.player();
            this.credit(player2, player, string);
            if (!this.huntBridge.damage(player, player2, d3)) continue;
            this.startCrimsonFire(player, player2, string);
            player2.sendActionBar(((TextComponent)Component.text((String)"\u2726 CRIMSON INFERNO", (TextColor)NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD)).append(Component.text((String)"  \u2022  6 seconds", (TextColor)NamedTextColor.RED).decoration(TextDecoration.BOLD, false)));
            player2.getWorld().playSound(player2.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 0.9f, 0.55f);
        }
    }

    private void renderBeam(final Player player, final Location location, final Vector vector, final double d) {
        Vector vector2 = vector.clone().crossProduct(new Vector(0.0, 1.0, 0.0));
        if (vector2.lengthSquared() < 0.001) {
            vector2 = new Vector(1.0, 0.0, 0.0);
        } else {
            vector2.normalize();
        }
        Vector vector3 = vector2.clone().crossProduct(vector).normalize();
        final Vector vector4 = vector2;
        final Vector vector5 = vector3;
        final double d2 = Math.max(0.65, this.plugin.getConfig().getDouble("beam.visual-width-blocks", 1.8));
        final double d3 = Math.max(2.0, this.plugin.getConfig().getDouble("beam.travel-blocks-per-tick", 5.0));
        final int n = Math.max(1, Math.min(100, this.plugin.getConfig().getInt("beam.maximum-particle-lifetime-ticks", 100)));
        BukkitRunnable bukkitRunnable = new BukkitRunnable(){
            private double renderedTo;
            private double phase;
            private int ticksAlive;

            private void finish() {
                int n2 = this.getTaskId();
                CrimsonService.this.activeBeams.removeIf(bukkitTask -> bukkitTask.getTaskId() == n2);
                this.cancel();
            }

            public void run() {
                if (!player.isOnline() || this.ticksAlive++ >= n) {
                    this.finish();
                    return;
                }
                double d6 = Math.min(d, this.renderedTo + d3);
                for (double d22 = this.renderedTo; d22 <= d6; d22 += 0.42) {
                    Location location3 = location.clone().add(vector.clone().multiply(d22));
                    location3.getWorld().spawnParticle(Particle.DUST, location3, 2, 0.12, 0.12, 0.12, 0.0, (Object)BEAM_CORE_DUST);
                    double d32 = this.phase + d22 * 0.72;
                    for (int i = 0; i < 4; ++i) {
                        double d4 = d32 + Math.PI * 2 * (double)i / 4.0;
                        double d5 = d2 * (0.72 + 0.18 * Math.sin(d22 * 1.8 + (double)i));
                        Vector vector2 = vector4.clone().multiply(Math.cos(d4) * d5).add(vector5.clone().multiply(Math.sin(d4) * d5));
                        Location location2 = location3.clone().add(vector2);
                        location2.getWorld().spawnParticle(Particle.DUST, location2, 1, 0.06, 0.06, 0.06, 0.0, (Object)(i % 2 == 0 ? BEAM_DUST : BEAM_EDGE_DUST));
                    }
                }
                this.renderedTo = d6;
                this.phase += 0.8;
                if (this.renderedTo >= d) {
                    Location location4 = location.clone().add(vector.clone().multiply(d));
                    location4.getWorld().spawnParticle(Particle.DUST, location4, 36, d2 * 0.7, d2 * 0.7, d2 * 0.7, 0.04, (Object)BEAM_CORE_DUST);
                    location4.getWorld().spawnParticle(Particle.FLASH, location4, 1);
                    location4.getWorld().playSound(location4, Sound.BLOCK_TRIAL_SPAWNER_BREAK, 0.75f, 0.55f);
                    this.finish();
                }
            }
        };
        this.activeBeams.add(bukkitRunnable.runTaskTimer((Plugin)this.plugin, 0L, 1L));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent playerQuitEvent) {
        UUID uUID = playerQuitEvent.getPlayer().getUniqueId();
        this.lastBeamUse.remove(uUID);
        BukkitTask bukkitTask = this.activeBurns.remove(uUID);
        if (bukkitTask != null) {
            bukkitTask.cancel();
        }
        this.hitCredits.entrySet().removeIf(entry -> ((UUID)entry.getKey()).equals(uUID) || ((HitCredit)entry.getValue()).attacker().equals(uUID));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent playerJoinEvent) {
        Player player = playerJoinEvent.getPlayer();
        this.refreshBlades(player);
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            if (player.isOnline()) {
                this.sendCrimsonPack(player);
            }
        }, 60L);
    }

    private void sendCrimsonPack(Player player) {
        player.addResourcePack(CRIMSON_PACK_ID, CRIMSON_PACK_URL, CRIMSON_PACK_SHA1, "The 4judee weapon texture overlay is required.", true);
    }

    private void startCrimsonFire(Player player, Player player2, final String string) {
        BukkitTask bukkitTask = this.activeBurns.remove(player2.getUniqueId());
        if (bukkitTask != null) {
            bukkitTask.cancel();
        }
        final int n = Math.max(1, this.plugin.getConfig().getInt("beam.burn-seconds", 6));
        final double d = Math.max(0.0, this.plugin.getConfig().getDouble("beam.burn-true-damage-per-second", 2.0));
        final UUID uUID = player2.getUniqueId();
        final UUID uUID2 = player.getUniqueId();
        player2.setFireTicks(Math.max(player2.getFireTicks(), n * 20));
        BukkitRunnable bukkitRunnable = new BukkitRunnable(){
            private int elapsed;

            public void run() {
                Player player = Bukkit.getPlayer((UUID)uUID);
                Player player2 = Bukkit.getPlayer((UUID)uUID2);
                if (player == null || player2 == null || player.isDead() || player.getWorld() != player2.getWorld() || this.elapsed >= n) {
                    CrimsonService.this.activeBurns.remove(uUID);
                    this.cancel();
                    return;
                }
                ++this.elapsed;
                player.setFireTicks(Math.max(player.getFireTicks(), (n - this.elapsed + 1) * 20));
                CrimsonService.this.credit(player, player2, string);
                CrimsonService.this.huntBridge.damage(player2, player, d);
                Location location = player.getLocation().add(0.0, 1.0, 0.0);
                location.getWorld().spawnParticle(Particle.DUST, location, 42, 0.55, 0.9, 0.55, 0.04, (Object)BEAM_DUST);
                location.getWorld().spawnParticle(Particle.DUST, location, 24, 0.4, 0.75, 0.4, 0.02, (Object)BEAM_CORE_DUST);
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_HURT, 0.65f, 0.55f);
                if (this.elapsed >= n) {
                    CrimsonService.this.activeBurns.remove(uUID);
                    player.setFireTicks(0);
                    this.cancel();
                }
            }
        };
        this.activeBurns.put(uUID, bukkitRunnable.runTaskTimer((Plugin)this.plugin, 20L, 20L));
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onCrimsonFireDamage(EntityDamageEvent entityDamageEvent) {
        Player player;
        Entity entity = entityDamageEvent.getEntity();
        if (!(entity instanceof Player) || !this.activeBurns.containsKey((player = (Player)entity).getUniqueId())) {
            return;
        }
        entity = entityDamageEvent.getCause();
        if (entity == EntityDamageEvent.DamageCause.FIRE || entity == EntityDamageEvent.DamageCause.FIRE_TICK || entity == EntityDamageEvent.DamageCause.LAVA || entity == EntityDamageEvent.DamageCause.HOT_FLOOR) {
            entityDamageEvent.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBladeDamage(EntityDamageByEntityEvent entityDamageByEntityEvent) {
        Entity entity = entityDamageByEntityEvent.getDamager();
        if (entity instanceof Player) {
            Player player = (Player)entity;
            entity = entityDamageByEntityEvent.getEntity();
            if (entity instanceof Player) {
                Player player2 = (Player)entity;
                if (this.isBlade(player.getInventory().getItemInMainHand())) {
                    this.credit(player2, player, this.getOrAssignBladeId(player.getInventory().getItemInMainHand()));
                }
            }
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onBladeDrop(PlayerDropItemEvent playerDropItemEvent) {
        this.applyDroppedGlow(playerDropItemEvent.getItemDrop());
    }

    @EventHandler(ignoreCancelled=true)
    public void onBladePickup(EntityPickupItemEvent entityPickupItemEvent) {
        if (this.isBlade(entityPickupItemEvent.getItem().getItemStack())) {
            this.clearDroppedGlow(entityPickupItemEvent.getItem());
        }
    }

    @EventHandler
    public void onBladeDespawn(ItemDespawnEvent itemDespawnEvent) {
        this.clearDroppedGlow(itemDespawnEvent.getEntity());
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent playerDeathEvent) {
        Player player = playerDeathEvent.getEntity();
        HitCredit hitCredit = this.hitCredits.remove(player.getUniqueId());
        if (hitCredit == null || hitCredit.expiresAt() < System.currentTimeMillis()) {
            return;
        }
        Player player2 = player.getKiller();
        if (player2 == null || !player2.getUniqueId().equals(hitCredit.attacker())) {
            return;
        }
        ItemStack itemStack = this.findBlade(player2, hitCredit.bladeId());
        if (itemStack != null) {
            this.upgradeSharpness(player2, itemStack);
        }
    }

    private void credit(Player player, Player player2, String string) {
        this.hitCredits.put(player.getUniqueId(), new HitCredit(player2.getUniqueId(), string, System.currentTimeMillis() + 15000L));
    }

    private ItemStack findBlade(Player player, String string) {
        ItemStack itemStack = player.getInventory().getItemInMainHand();
        if (this.isBlade(itemStack) && string.equals(this.getOrAssignBladeId(itemStack))) {
            return itemStack;
        }
        for (ItemStack itemStack2 : player.getInventory().getStorageContents()) {
            if (!this.isBlade(itemStack2) || !string.equals(this.getOrAssignBladeId(itemStack2))) continue;
            return itemStack2;
        }
        return null;
    }

    private String getOrAssignBladeId(ItemStack itemStack) {
        ItemMeta itemMeta = itemStack.getItemMeta();
        String string = (String)itemMeta.getPersistentDataContainer().get(this.bladeIdKey, PersistentDataType.STRING);
        if (string == null) {
            string = UUID.randomUUID().toString();
            itemMeta.getPersistentDataContainer().set(this.bladeIdKey, PersistentDataType.STRING, (Object)string);
            itemStack.setItemMeta(itemMeta);
        }
        return string;
    }

    private void upgradeSharpness(Player player, ItemStack itemStack) {
        int n = Math.max(1, this.plugin.getConfig().getInt("progression.maximum-sharpness", 7));
        ItemMeta itemMeta = itemStack.getItemMeta();
        int n2 = (Integer)itemMeta.getPersistentDataContainer().getOrDefault(this.sharpnessKey, PersistentDataType.INTEGER, (Object)0);
        if (n2 >= n) {
            player.sendActionBar(((TextComponent)((TextComponent)Component.text((String)"\u2726 CRIMSON BLADE", (TextColor)NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD)).append(Component.text((String)"  \u2022  SHARPNESS VII", (TextColor)NamedTextColor.RED).decoration(TextDecoration.BOLD, false))).append(Component.text((String)"  MAXIMUM", (TextColor)NamedTextColor.GRAY).decoration(TextDecoration.BOLD, false)));
            return;
        }
        int n3 = n2 + 1;
        itemMeta.getPersistentDataContainer().set(this.sharpnessKey, PersistentDataType.INTEGER, (Object)n3);
        itemMeta.addEnchant(Enchantment.SHARPNESS, n3, true);
        itemMeta.lore(this.bladeLore(n3, n));
        itemStack.setItemMeta(itemMeta);
        player.showTitle(Title.title((Component)Component.text((String)"\u2726 CRIMSON AWAKENED \u2726", (TextColor)NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD), (Component)Component.text((String)("Sharpness " + this.roman(n3)), (TextColor)NamedTextColor.RED).append((Component)Component.text((String)("  \u2022  " + this.roman(n)), (TextColor)NamedTextColor.DARK_GRAY)), (Title.Times)Title.Times.times((Duration)Duration.ofMillis(250L), (Duration)Duration.ofMillis(1750L), (Duration)Duration.ofMillis(500L))));
        player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 0.65f + (float)n3 * 0.06f);
        player.getWorld().spawnParticle(Particle.ITEM, player.getLocation().add(0.0, 1.0, 0.0), 32, 0.65, 0.8, 0.65, 0.08, (Object)this.modelItem("crimson_fragment"));
    }

    private void animate() {
        long l = Bukkit.getCurrentTick();
        this.altarRelics.removeIf(uUID -> {
            ItemDisplay itemDisplay;
            Entity entity = Bukkit.getEntity((UUID)uUID);
            if (!(entity instanceof ItemDisplay) || !(itemDisplay = (ItemDisplay)entity).isValid()) {
                return true;
            }
            Location location = itemDisplay.getLocation();
            location.setYaw((float)l * 4.4f % 360.0f);
            location.setY(Math.floor(location.getY()) + 0.82 + Math.sin((double)l * 0.1) * 0.13);
            itemDisplay.teleport(location);
            if (l % 8L == 0L) {
                itemDisplay.getWorld().spawnParticle(Particle.ITEM, location, 2, 0.35, 0.32, 0.35, 0.02, (Object)this.modelItem("crimson_fragment"));
            }
            return false;
        });
        ItemStack itemStack = this.modelItem("crimson_fragment");
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!this.isBlade(player.getInventory().getItemInMainHand())) continue;
            Vector vector = player.getEyeLocation().getDirection().normalize();
            Vector vector2 = vector.clone().crossProduct(new Vector(0.0, 1.0, 0.0));
            if (vector2.lengthSquared() < 0.001) {
                vector2 = new Vector(1.0, 0.0, 0.0);
            } else {
                vector2.normalize();
            }
            Location location = player.getEyeLocation().add(vector.multiply(0.65)).add(vector2.multiply(0.34)).add(0.0, -0.42, 0.0);
            location.getWorld().spawnParticle(Particle.ITEM, location, 1, 0.18, 0.3, 0.18, 0.02, (Object)itemStack);
            location.getWorld().spawnParticle(Particle.DUST, location, 2, 0.16, 0.25, 0.16, 0.01, (Object)BEAM_DUST);
        }
        this.glowingDrops.removeIf(uUID -> {
            Item item;
            Entity entity = Bukkit.getEntity((UUID)uUID);
            if (!(entity instanceof Item && (item = (Item)entity).isValid() && this.isBlade(item.getItemStack()))) {
                if (this.droppedBladeTeam != null) {
                    this.droppedBladeTeam.removeEntry(uUID.toString());
                }
                return true;
            }
            Location location = item.getLocation().add(0.0, 0.22, 0.0);
            location.getWorld().spawnParticle(Particle.DUST, location, 2, 0.34, 0.18, 0.34, 0.01, (Object)BEAM_CORE_DUST);
            return false;
        });
        long l2 = System.currentTimeMillis();
        this.hitCredits.entrySet().removeIf(entry -> ((HitCredit)entry.getValue()).expiresAt() < l2);
    }

    private ItemStack createBlade() {
        ItemStack itemStack = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.displayName(this.bladeName());
        itemMeta.setItemModel(new NamespacedKey("hunt", "crimson_blade"));
        itemMeta.getPersistentDataContainer().set(this.bladeKey, PersistentDataType.BYTE, (Object)1);
        itemMeta.getPersistentDataContainer().set(this.bladeIdKey, PersistentDataType.STRING, (Object)UUID.randomUUID().toString());
        itemMeta.getPersistentDataContainer().set(this.sharpnessKey, PersistentDataType.INTEGER, (Object)0);
        itemMeta.getPersistentDataContainer().set(this.huntWeaponKey, PersistentDataType.STRING, (Object)WEAPON_ID);
        itemMeta.setEnchantmentGlintOverride(Boolean.valueOf(true));
        itemMeta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_UNBREAKABLE});
        itemMeta.lore(this.bladeLore(0, Math.max(1, this.plugin.getConfig().getInt("progression.maximum-sharpness", 7))));
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private List<Component> bladeLore(int n, int n2) {
        return List.of(this.loreLine("\u2726  AWAKENED HUNT RELIC  \u2726", NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD), Component.empty(), this.lorePair("ABILITY", "CRIMSON BEAM"), this.loreLine("Sneak + Right-Click to unleash", NamedTextColor.GRAY), this.loreLine("a wide, piercing wave of bloodfire.", NamedTextColor.GRAY), Component.empty(), this.lorePair("IMPACT", "3 HEARTS"), this.lorePair("INFERNO", "1 HEART / SEC  \u00b7  6 SEC"), this.loreLine("Absorption is consumed before health.", NamedTextColor.DARK_GRAY), this.loreLine("Fire Resistance cannot extinguish it.", NamedTextColor.DARK_GRAY), Component.empty(), this.lorePair("BLOODBOUND", "SHARPNESS " + this.roman(n) + " / " + this.roman(n2)), this.loreLine("Each player kill awakens its next level.", NamedTextColor.GRAY));
    }

    private Component bladeName() {
        return ((TextComponent)((TextComponent)Component.text((String)"\u2726 ", (TextColor)NamedTextColor.RED).append(Component.text((String)"CRIMSON BLADE", (TextColor)NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD))).append((Component)Component.text((String)" \u2726", (TextColor)NamedTextColor.RED))).decoration(TextDecoration.ITALIC, false);
    }

    private Component lorePair(String string, String string2) {
        return this.loreLine(string, NamedTextColor.RED).append(Component.text((String)"  |  ", (TextColor)NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false)).append(Component.text((String)string2, (TextColor)NamedTextColor.WHITE).decoration(TextDecoration.ITALIC, false));
    }

    private Component loreLine(String string, NamedTextColor namedTextColor) {
        return Component.text((String)string, (TextColor)namedTextColor).decoration(TextDecoration.ITALIC, false);
    }

    private void refreshBlades(Player player) {
        this.refreshBladePresentation(player.getInventory().getItemInMainHand());
        this.refreshBladePresentation(player.getInventory().getItemInOffHand());
        for (ItemStack itemStack : player.getInventory().getStorageContents()) {
            this.refreshBladePresentation(itemStack);
        }
    }

    private void refreshBladePresentation(ItemStack itemStack) {
        if (!this.isBlade(itemStack)) {
            return;
        }
        ItemMeta itemMeta = itemStack.getItemMeta();
        int n = (Integer)itemMeta.getPersistentDataContainer().getOrDefault(this.sharpnessKey, PersistentDataType.INTEGER, (Object)0);
        int n2 = Math.max(1, this.plugin.getConfig().getInt("progression.maximum-sharpness", 7));
        itemMeta.displayName(this.bladeName());
        itemMeta.lore(this.bladeLore(n, n2));
        itemStack.setItemMeta(itemMeta);
    }

    private void applyDroppedGlow(Item item) {
        ItemStack itemStack = item.getItemStack();
        if (!this.isBlade(itemStack)) {
            return;
        }
        this.refreshBladePresentation(itemStack);
        item.setItemStack(itemStack);
        item.setGlowing(true);
        this.glowingDrops.add(item.getUniqueId());
        if (this.droppedBladeTeam != null) {
            this.droppedBladeTeam.addEntry(item.getUniqueId().toString());
        }
    }

    private void clearDroppedGlow(Item item) {
        item.setGlowing(false);
        this.glowingDrops.remove(item.getUniqueId());
        if (this.droppedBladeTeam != null) {
            this.droppedBladeTeam.removeEntry(item.getUniqueId().toString());
        }
    }

    private boolean isBlade(ItemStack itemStack) {
        return itemStack != null && itemStack.hasItemMeta() && itemStack.getItemMeta().getPersistentDataContainer().has(this.bladeKey, PersistentDataType.BYTE);
    }

    private ItemStack modelItem(String string) {
        ItemStack itemStack = new ItemStack(Material.PAPER);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setItemModel(new NamespacedKey("hunt", string));
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private void giveOrDrop(Player player, ItemStack itemStack) {
        HashMap hashMap = player.getInventory().addItem(new ItemStack[]{itemStack});
        for (ItemStack itemStack2 : hashMap.values()) {
            Item item = player.getWorld().dropItemNaturally(player.getLocation(), itemStack2);
            this.applyDroppedGlow(item);
        }
    }

    private boolean canAdmin(Player player) {
        return player.isOp() || player.hasPermission("hunt.admin");
    }

    private void deny(Player player) {
        player.sendMessage(PREFIX.append((Component)Component.text((String)"You do not have permission to use altar commands.", (TextColor)NamedTextColor.RED)));
    }

    private String roman(int n) {
        return switch (n) {
            case 0 -> "0";
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            default -> Integer.toString(n);
        };
    }

    private void spawnAltar(Player player) {
        Block block = player.getTargetBlockExact(8);
        Location location = block == null ? player.getLocation().getBlock().getLocation() : block.getLocation().add(0.0, 1.0, 0.0);
        Block block2 = location.getBlock();
        if (!block2.isEmpty() && block2.getType() != Material.BARRIER) {
            player.sendMessage(PREFIX.append((Component)Component.text((String)"That space is blocked.", (TextColor)NamedTextColor.RED)));
            return;
        }
        block2.setType(Material.BARRIER, false);
        String string = UUID.randomUUID().toString();
        Location location2 = location.clone().add(0.5, 0.5, 0.5);
        ItemDisplay itemDisplay2 = (ItemDisplay)location.getWorld().spawn(location2, ItemDisplay.class, itemDisplay -> {
            itemDisplay.setItemStack(this.modelItem("weapon_altar"));
            itemDisplay.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            itemDisplay.setBrightness(new Display.Brightness(15, 15));
            itemDisplay.setPersistent(true);
            this.tag((Display)itemDisplay, "base", string);
        });
        itemDisplay2.setPersistent(true);
        ItemDisplay itemDisplay3 = (ItemDisplay)location.getWorld().spawn(location.clone().add(0.5, 1.85, 0.5), ItemDisplay.class, itemDisplay -> {
            itemDisplay.setItemStack(this.createBlade());
            itemDisplay.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            itemDisplay.setBrightness(new Display.Brightness(15, 15));
            itemDisplay.setBillboard(Display.Billboard.FIXED);
            itemDisplay.setPersistent(true);
            this.tag((Display)itemDisplay, "relic", string);
        });
        this.altarRelics.add(itemDisplay3.getUniqueId());
        this.spawnRecipeText(location, string);
        location.getWorld().playSound(location2, Sound.BLOCK_END_PORTAL_SPAWN, 0.9f, 0.75f);
        location.getWorld().spawnParticle(Particle.ITEM, location2.clone().add(0.0, 1.2, 0.0), 48, 0.75, 1.0, 0.75, 0.08, (Object)this.modelItem("crimson_fragment"));
        player.sendMessage(PREFIX.append((Component)Component.text((String)"Crimson Blade altar released.", (TextColor)NamedTextColor.RED)));
    }

    private void spawnRecipeText(Location location, String string) {
        List<TextComponent> list = List.of(Component.text((String)"\u2726  CRIMSON BLADE  \u2726", (TextColor)NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD), Component.text((String)"F O R G I N G   R E Q U I R E M E N T S", (TextColor)NamedTextColor.DARK_GRAY), this.ingredientRow("x3", "WITHER SKELETON SKULL"), this.ingredientRow("x1", "NETHER STAR"), this.ingredientRow("x64", "CRIMSON NYLIUM"), this.ingredientRow("x3", "NETHERITE INGOT"), this.ingredientRow("x32", "QUARTZ BLOCK"), Component.text((String)"RIGHT CLICK THE ALTAR TO FORGE", (TextColor)NamedTextColor.DARK_GRAY));
        for (int i = 0; i < list.size(); ++i) {
            int n = i;
            TextDisplay textDisplay2 = (TextDisplay)location.getWorld().spawn(location.clone().add(0.5, 4.0 - (double)i * 0.22, 0.5), TextDisplay.class, textDisplay -> {
                textDisplay.text((Component)list.get(n));
                textDisplay.setBillboard(Display.Billboard.CENTER);
                textDisplay.setSeeThrough(false);
                textDisplay.setShadowed(true);
                textDisplay.setLineWidth(320);
                textDisplay.setBackgroundColor(Color.fromARGB((int)(n <= 1 ? 160 : 96), (int)8, (int)0, (int)4));
                textDisplay.setBrightness(new Display.Brightness(15, 15));
                textDisplay.setPersistent(true);
                this.tag((Display)textDisplay, "text", string);
            });
            textDisplay2.setPersistent(true);
        }
    }

    private Component ingredientRow(String string, String string2) {
        return Component.text((String)("\u25aa  " + string + "  "), (TextColor)NamedTextColor.RED).append((Component)Component.text((String)string2, (TextColor)NamedTextColor.WHITE));
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onAltarForge(PlayerInteractEvent playerInteractEvent) {
        if (playerInteractEvent.getHand() != EquipmentSlot.HAND || playerInteractEvent.getAction() != Action.RIGHT_CLICK_BLOCK || playerInteractEvent.getClickedBlock() == null || playerInteractEvent.getClickedBlock().getType() != Material.BARRIER) {
            return;
        }
        Location location = playerInteractEvent.getClickedBlock().getLocation().add(0.5, 0.5, 0.5);
        ItemDisplay itemDisplay = this.findBaseNear(location);
        if (itemDisplay == null) {
            return;
        }
        playerInteractEvent.setCancelled(true);
        Player player = playerInteractEvent.getPlayer();
        Map<Material, Integer> map = this.recipeCosts();
        ArrayList<CallSite> arrayList = new ArrayList<CallSite>();
        for (Map.Entry<Material, Integer> entry : map.entrySet()) {
            int n = this.countMaterial(player, entry.getKey());
            if (n >= entry.getValue()) continue;
            arrayList.add((CallSite)((Object)(entry.getValue() - n + "x " + this.friendlyName(entry.getKey()))));
        }
        if (!arrayList.isEmpty()) {
            player.sendMessage(PREFIX.append((Component)Component.text((String)"Forging failed. Missing: ", (TextColor)NamedTextColor.RED)).append((Component)Component.text((String)String.join((CharSequence)" / ", arrayList), (TextColor)NamedTextColor.WHITE)));
            player.playSound(location, Sound.BLOCK_VAULT_REJECT_REWARDED_PLAYER, 0.8f, 0.7f);
            location.getWorld().spawnParticle(Particle.SMOKE, location.clone().add(0.0, 0.9, 0.0), 16, 0.35, 0.45, 0.35, 0.02);
            return;
        }
        for (Map.Entry<Material, Integer> entry : map.entrySet()) {
            this.removeMaterial(player, entry.getKey(), entry.getValue());
        }
        this.giveOrDrop(player, this.createBlade());
        location.getWorld().playSound(location, Sound.BLOCK_VAULT_EJECT_ITEM, 1.0f, 0.7f);
        location.getWorld().playSound(location, Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.9f, 1.35f);
        location.getWorld().spawnParticle(Particle.ITEM, location.clone().add(0.0, 1.2, 0.0), 64, 0.7, 0.9, 0.7, 0.1, (Object)this.modelItem("crimson_fragment"));
        this.collapseAltar(itemDisplay, location, player, true);
    }

    private Map<Material, Integer> recipeCosts() {
        LinkedHashMap<Material, Integer> linkedHashMap = new LinkedHashMap<Material, Integer>();
        linkedHashMap.put(Material.WITHER_SKELETON_SKULL, 3);
        linkedHashMap.put(Material.NETHER_STAR, 1);
        linkedHashMap.put(Material.CRIMSON_NYLIUM, 64);
        linkedHashMap.put(Material.NETHERITE_INGOT, 3);
        linkedHashMap.put(Material.QUARTZ_BLOCK, 32);
        return linkedHashMap;
    }

    private int countMaterial(Player player, Material material) {
        int n = 0;
        for (ItemStack itemStack : player.getInventory().getStorageContents()) {
            if (itemStack == null || itemStack.getType() != material) continue;
            n += itemStack.getAmount();
        }
        return n;
    }

    private void removeMaterial(Player player, Material material, int n) {
        ItemStack[] itemStackArray = player.getInventory().getStorageContents();
        int n2 = n;
        for (int i = 0; i < itemStackArray.length && n2 > 0; ++i) {
            ItemStack itemStack = itemStackArray[i];
            if (itemStack == null || itemStack.getType() != material) continue;
            int n3 = Math.min(itemStack.getAmount(), n2);
            n2 -= n3;
            if (n3 == itemStack.getAmount()) {
                itemStackArray[i] = null;
                continue;
            }
            itemStack.setAmount(itemStack.getAmount() - n3);
        }
        player.getInventory().setStorageContents(itemStackArray);
    }

    private void collapseAltar(ItemDisplay itemDisplay, Location location, Player player, boolean bl) {
        String string = (String)itemDisplay.getPersistentDataContainer().get(this.altarGroupKey, PersistentDataType.STRING);
        for (Entity entity : new ArrayList(location.getWorld().getNearbyEntities(location, 8.0, 8.0, 8.0))) {
            if (!(entity instanceof Display)) continue;
            Display display = (Display)entity;
            if (string == null || !string.equals(display.getPersistentDataContainer().get(this.altarGroupKey, PersistentDataType.STRING))) continue;
            this.altarRelics.remove(display.getUniqueId());
            display.remove();
        }
        Block block = location.getBlock();
        if (block.getType() == Material.BARRIER) {
            block.setType(Material.AIR, false);
        }
        location.getWorld().spawnParticle(Particle.ITEM, location.clone().add(0.0, 1.1, 0.0), 42, 0.75, 1.0, 0.75, 0.08, (Object)this.modelItem("crimson_fragment"));
        location.getWorld().playSound(location, Sound.BLOCK_END_PORTAL_FRAME_FILL, 1.0f, 0.55f);
        if (bl && player != null) {
            Entity entity;
            entity = ((TextComponent)((TextComponent)((TextComponent)((TextComponent)Component.text((String)"HUNT RELIC ", (TextColor)NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD)).append(Component.text((String)"| ", (TextColor)NamedTextColor.DARK_GRAY).decoration(TextDecoration.BOLD, false))).append(Component.text((String)player.getName(), (TextColor)NamedTextColor.WHITE).decoration(TextDecoration.BOLD, false))).append(Component.text((String)" has forged the Crimson Blade. ", (TextColor)NamedTextColor.RED).decoration(TextDecoration.BOLD, false))).append(Component.text((String)"The altar has disappeared.", (TextColor)NamedTextColor.GRAY).decoration(TextDecoration.BOLD, false));
            for (Player player2 : Bukkit.getOnlinePlayers()) {
                player2.sendMessage((Component)entity);
            }
        }
    }

    private ItemDisplay findBaseNear(Location location) {
        for (Entity entity : location.getWorld().getNearbyEntities(location, 0.8, 0.8, 0.8)) {
            ItemDisplay itemDisplay;
            if (!(entity instanceof ItemDisplay) || !"base".equals((itemDisplay = (ItemDisplay)entity).getPersistentDataContainer().get(this.altarRoleKey, PersistentDataType.STRING))) continue;
            return itemDisplay;
        }
        return null;
    }

    private ItemDisplay findLookedAtAltar(Player player, double d) {
        Vector vector = player.getEyeLocation().getDirection().normalize();
        ItemDisplay itemDisplay = null;
        double d2 = Double.NEGATIVE_INFINITY;
        for (ItemDisplay itemDisplay2 : player.getWorld().getEntitiesByClass(ItemDisplay.class)) {
            Vector vector2;
            double d3;
            if (!"base".equals(itemDisplay2.getPersistentDataContainer().get(this.altarRoleKey, PersistentDataType.STRING)) || (d3 = (vector2 = itemDisplay2.getLocation().toVector().subtract(player.getEyeLocation().toVector())).length()) < 0.1 || d3 > d) continue;
            double d4 = vector.dot(vector2.normalize());
            double d5 = d4 * 4.0 - d3 * 0.08;
            if (!(d4 >= 0.72) || !(d5 > d2)) continue;
            d2 = d5;
            itemDisplay = itemDisplay2;
        }
        return itemDisplay;
    }

    private void tag(Display display, String string, String string2) {
        display.getPersistentDataContainer().set(this.altarRoleKey, PersistentDataType.STRING, (Object)string);
        display.getPersistentDataContainer().set(this.altarGroupKey, PersistentDataType.STRING, (Object)string2);
    }

    private String friendlyName(Material material) {
        String[] stringArray = material.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder stringBuilder = new StringBuilder();
        for (String string : stringArray) {
            if (!stringBuilder.isEmpty()) {
                stringBuilder.append(' ');
            }
            stringBuilder.append(Character.toUpperCase(string.charAt(0))).append(string.substring(1));
        }
        return stringBuilder.toString();
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent chunkLoadEvent) {
        for (Entity entity : chunkLoadEvent.getChunk().getEntities()) {
            ItemDisplay itemDisplay;
            if (entity instanceof ItemDisplay && "relic".equals((itemDisplay = (ItemDisplay)entity).getPersistentDataContainer().get(this.altarRoleKey, PersistentDataType.STRING))) {
                this.altarRelics.add(itemDisplay.getUniqueId());
            }
            if (!(entity instanceof Item)) continue;
            itemDisplay = (Item)entity;
            this.applyDroppedGlow((Item)itemDisplay);
        }
    }

    private record BeamVictim(Player player, double distance) {
    }

    private record HitCredit(UUID attacker, String bladeId, long expiresAt) {
    }
}

