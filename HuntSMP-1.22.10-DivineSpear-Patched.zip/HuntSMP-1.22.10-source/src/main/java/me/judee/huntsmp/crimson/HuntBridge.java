/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntsmp.crimson;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.bukkit.Bukkit;
import org.bukkit.EntityEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class HuntBridge {
    private final JavaPlugin plugin;
    private final Plugin huntPlugin;
    private final Method trustMethod;
    private final Method graceMethod;

    public HuntBridge(JavaPlugin javaPlugin) {
        this.plugin = javaPlugin;
        this.huntPlugin = javaPlugin.getServer().getPluginManager().getPlugin("HuntSMP");
        this.trustMethod = this.findMethod("isDamageBlockedByTrust", Player.class, Player.class);
        this.graceMethod = this.findMethod("isGraceActive", new Class[0]);
    }

    boolean damage(Player player, Player player2, double d) {
        if (player == null || player2 == null || player.equals((Object)player2) || player2.isDead() || player2.isInvulnerable() || player2.getGameMode() == GameMode.CREATIVE || player2.getGameMode() == GameMode.SPECTATOR || this.isTrusted(player2, player) || this.isGraceActive()) {
            return false;
        }
        double d2 = Math.max(0.0, d);
        if (d2 <= 0.0) {
            return false;
        }
        Location location = player2.getLocation();
        DamageSource damageSource = DamageSource.builder((DamageType)DamageType.MAGIC).withCausingEntity((Entity)player).withDirectEntity((Entity)player).withDamageLocation(location).build();
        EntityDamageByEntityEvent entityDamageByEntityEvent = new EntityDamageByEntityEvent((Entity)player, (Entity)player2, EntityDamageEvent.DamageCause.MAGIC, damageSource, d2);
        Bukkit.getPluginManager().callEvent((Event)entityDamageByEntityEvent);
        double d3 = Math.max(0.0, entityDamageByEntityEvent.getFinalDamage());
        if (entityDamageByEntityEvent.isCancelled() || d3 <= 0.0) {
            return false;
        }
        double d4 = Math.min(d3, Math.max(0.0, player2.getAbsorptionAmount()));
        if (d4 > 0.0) {
            player2.setAbsorptionAmount(player2.getAbsorptionAmount() - d4);
        }
        double d5 = Math.min(d3 - d4, player2.getHealth());
        player2.setLastDamageCause((EntityDamageEvent)entityDamageByEntityEvent);
        player2.setLastDamage(d3);
        player2.setNoDamageTicks(0);
        if (d5 > 0.0) {
            player2.setHealth(Math.max(0.0, player2.getHealth() - d5));
        }
        if (!player2.isDead()) {
            player2.setNoDamageTicks(10);
            player2.playEffect(EntityEffect.HURT);
        }
        return true;
    }

    boolean isTrusted(Player player, Player player2) {
        if (this.huntPlugin == null || this.trustMethod == null) {
            return false;
        }
        try {
            return Boolean.TRUE.equals(this.trustMethod.invoke((Object)this.huntPlugin, player, player2));
        }
        catch (IllegalAccessException | InvocationTargetException reflectiveOperationException) {
            this.plugin.getLogger().warning("HuntSMP trust bridge failed: " + reflectiveOperationException.getMessage());
            return false;
        }
    }

    private boolean isGraceActive() {
        if (this.huntPlugin == null || this.graceMethod == null) {
            return false;
        }
        try {
            return Boolean.TRUE.equals(this.graceMethod.invoke((Object)this.huntPlugin, new Object[0]));
        }
        catch (IllegalAccessException | InvocationTargetException reflectiveOperationException) {
            this.plugin.getLogger().warning("HuntSMP grace bridge failed: " + reflectiveOperationException.getMessage());
            return true;
        }
    }

    private Method findMethod(String string, Class<?> ... classArray) {
        if (this.huntPlugin == null) {
            return null;
        }
        for (Class clazz = this.huntPlugin.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
            try {
                Method method = clazz.getDeclaredMethod(string, classArray);
                method.setAccessible(true);
                return method;
            }
            catch (NoSuchMethodException noSuchMethodException) {
                continue;
            }
        }
        this.plugin.getLogger().severe("Unsupported HuntSMP build: missing method " + string + ".");
        return null;
    }
}

