/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntsmp;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import me.judee.huntsmp.DivineSpearFeature;
import me.judee.huntsmp.DivineSpearHuntCommand;
import me.judee.huntsmp.FeaturePatch;
import me.judee.huntsmp.HuntPlugin;
import me.judee.huntsmp.crimson.CrimsonService;
import me.judee.huntsmp.crimson.HuntBridge;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.BrewEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;
import org.bukkit.scheduler.BukkitTask;

public final class IntegratedHuntPlugin
extends HuntPlugin {
    private static final String BUNDLED_PACK = "packs/HuntSMP-Crimson-Pack-1.22.3.zip";
    private static final long CRIMSON_COOLDOWN_MILLIS = 45000L;
    private static final int TARGET_POTION_DURATION_TICKS = 9600;
    private final Map<UUID, Long> crimsonCooldownEnds = new HashMap<UUID, Long>();
    private final Map<UUID, BossBar> crimsonCooldownBars = new HashMap<UUID, BossBar>();
    private CrimsonService crimsonService;
    private BukkitTask featureTicker;

    @Override
    public void onEnable() {
        super.onEnable();
        this.getConfig().set("beam.anti-double-fire-millis", (Object)45000L);
        this.getConfig().set("gameplay.extended-strength-ii", (Object)true);
        this.getConfig().set("gameplay.strength-ii-duration-seconds", (Object)480);
        this.getConfig().set("gameplay.extended-weaving", (Object)true);
        this.getConfig().set("gameplay.weaving-duration-seconds", (Object)480);
        this.saveConfig();
        this.crimsonService = new CrimsonService(this, new HuntBridge(this));
        this.getServer().getPluginManager().registerEvents((Listener)this.crimsonService, (Plugin)this);
        this.crimsonService.start();
        this.featureTicker = Bukkit.getScheduler().runTaskTimer((Plugin)this, this::tickExtraFeatures, 2L, 2L);
        this.extractBundledPack();
        this.getLogger().info("Crimson Blade loaded with a 45-second boss-bar cooldown. Strength and Weaving potions normalize to 8:00.");
        FeaturePatch.register((Plugin)this);
        DivineSpearFeature.register((Plugin)this);
        DivineSpearHuntCommand.register((Plugin)this);
    }

    @Override
    public void onDisable() {
        if (this.featureTicker != null) {
            this.featureTicker.cancel();
            this.featureTicker = null;
        }
        for (BossBar bossBar : this.crimsonCooldownBars.values()) {
            bossBar.removeAll();
        }
        this.crimsonCooldownBars.clear();
        this.crimsonCooldownEnds.clear();
        if (this.crimsonService != null) {
            this.crimsonService.shutdown();
            this.crimsonService = null;
        }
        super.onDisable();
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=false)
    public void onCrimsonCooldownDisplay(PlayerInteractEvent playerInteractEvent) {
        if (playerInteractEvent.getHand() != EquipmentSlot.HAND || !playerInteractEvent.getPlayer().isSneaking() || !playerInteractEvent.getAction().isRightClick()) {
            return;
        }
        Player player = playerInteractEvent.getPlayer();
        ItemStack itemStack = player.getInventory().getItemInMainHand();
        if (!this.isCrimsonBlade(itemStack)) {
            return;
        }
        long l = System.currentTimeMillis();
        long l2 = this.crimsonCooldownEnds.getOrDefault(player.getUniqueId(), 0L);
        if (l2 > l) {
            return;
        }
        long l3 = l + 45000L;
        this.crimsonCooldownEnds.put(player.getUniqueId(), l3);
        BossBar bossBar = this.crimsonCooldownBars.remove(player.getUniqueId());
        if (bossBar != null) {
            bossBar.removeAll();
        }
        BossBar bossBar2 = Bukkit.createBossBar((String)"\u00a7c\u00a7lCRIMSON BLADE \u00a78| \u00a7f45.0s", (BarColor)BarColor.RED, (BarStyle)BarStyle.SOLID, (BarFlag[])new BarFlag[0]);
        bossBar2.setProgress(1.0);
        bossBar2.addPlayer(player);
        bossBar2.setVisible(true);
        this.crimsonCooldownBars.put(player.getUniqueId(), bossBar2);
    }

    @Override
    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBrewComplete(BrewEvent brewEvent) {
        super.onBrewComplete(brewEvent);
        List list = brewEvent.getResults();
        for (int i = 0; i < list.size(); ++i) {
            ItemStack itemStack = (ItemStack)list.get(i);
            if (!this.normalizePotion(itemStack)) continue;
            list.set(i, itemStack);
        }
    }

    private void tickExtraFeatures() {
        long l = System.currentTimeMillis();
        ArrayList<UUID> arrayList = new ArrayList<UUID>();
        for (Map.Entry<UUID, Long> object : this.crimsonCooldownEnds.entrySet()) {
            UUID uUID = object.getKey();
            long l2 = object.getValue() - l;
            BossBar bossBar = this.crimsonCooldownBars.get(uUID);
            Player player = Bukkit.getPlayer((UUID)uUID);
            if (l2 <= 0L) {
                if (bossBar != null) {
                    bossBar.setProgress(0.0);
                    bossBar.removeAll();
                }
                arrayList.add(uUID);
                continue;
            }
            if (bossBar == null) continue;
            double d = (double)l2 / 1000.0;
            bossBar.setTitle(String.format("\u00a7c\u00a7lCRIMSON BLADE \u00a78| \u00a7f%.1fs", d));
            bossBar.setProgress(Math.max(0.0, Math.min(1.0, (double)l2 / 45000.0)));
            if (player == null || bossBar.getPlayers().contains(player)) continue;
            bossBar.addPlayer(player);
        }
        for (UUID uUID : arrayList) {
            this.crimsonCooldownEnds.remove(uUID);
            this.crimsonCooldownBars.remove(uUID);
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.normalizeInventory((Inventory)player.getInventory());
            if (player.getOpenInventory() == null) continue;
            this.normalizeInventory(player.getOpenInventory().getTopInventory());
            this.normalizePotion(player.getOpenInventory().getCursor());
        }
    }

    private void normalizeInventory(Inventory inventory) {
        if (inventory == null) {
            return;
        }
        ItemStack[] itemStackArray = inventory.getContents();
        for (int i = 0; i < itemStackArray.length; ++i) {
            ItemStack itemStack = itemStackArray[i];
            if (!this.normalizePotion(itemStack)) continue;
            inventory.setItem(i, itemStack);
        }
    }

    private boolean normalizePotion(ItemStack itemStack) {
        String string;
        Object object2;
        if (itemStack == null || itemStack.getType() == Material.AIR) {
            return false;
        }
        String string2 = itemStack.getType().name();
        if (!(string2.equals("POTION") || string2.equals("SPLASH_POTION") || string2.equals("LINGERING_POTION"))) {
            return false;
        }
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (!(itemMeta instanceof PotionMeta)) {
            return false;
        }
        PotionMeta potionMeta = (PotionMeta)itemMeta;
        PotionType potionType = potionMeta.getBasePotionType();
        String string3 = potionType == null ? "" : potionType.name();
        boolean bl = string3.contains("STRENGTH");
        boolean bl2 = string3.contains("WEAVING");
        int n = string3.contains("STRONG") ? 1 : 0;
        PotionEffectType potionEffectType = null;
        for (Object object2 : potionMeta.getCustomEffects()) {
            string = object2.getType().getName();
            if (string == null) continue;
            if (string.equalsIgnoreCase("STRENGTH") || string.equalsIgnoreCase("INCREASE_DAMAGE")) {
                bl = true;
                potionEffectType = object2.getType();
                n = Math.max(n, object2.getAmplifier());
                continue;
            }
            if (!string.equalsIgnoreCase("WEAVING")) continue;
            bl2 = true;
            if (bl) continue;
            potionEffectType = object2.getType();
            n = Math.max(n, object2.getAmplifier());
        }
        if (!bl && !bl2) {
            return false;
        }
        if (potionEffectType == null) {
            PotionEffectType potionEffectType2 = potionEffectType = bl ? this.firstEffectType("STRENGTH", "INCREASE_DAMAGE") : this.firstEffectType("WEAVING");
        }
        if (potionEffectType == null) {
            return false;
        }
        boolean bl3 = string3.equals("WATER");
        object2 = potionMeta.getCustomEffects().iterator();
        while (object2.hasNext()) {
            string = (PotionEffect)object2.next();
            if (!string.getType().equals(potionEffectType) || string.getDuration() != 9600 || string.getAmplifier() != n || !bl3) continue;
            return false;
        }
        potionMeta.setBasePotionType(PotionType.valueOf((String)"WATER"));
        potionMeta.removeCustomEffect(potionEffectType);
        potionMeta.addCustomEffect(new PotionEffect(potionEffectType, 9600, n, false, true, true), true);
        if (!potionMeta.hasDisplayName()) {
            Object object3 = string2.equals("SPLASH_POTION") ? "Splash Potion" : (object2 = string2.equals("LINGERING_POTION") ? "Lingering Potion" : "Potion");
            string = bl ? (n > 0 ? "Strength II" : "Strength") : "Weaving";
            potionMeta.setDisplayName("\u00a7r\u00a7f" + (String)object2 + " of " + string + " \u00a78(\u00a7f8:00\u00a78)");
        }
        itemStack.setItemMeta((ItemMeta)potionMeta);
        return true;
    }

    private PotionEffectType firstEffectType(String ... stringArray) {
        for (String string : stringArray) {
            PotionEffectType potionEffectType = PotionEffectType.getByName((String)string);
            if (potionEffectType == null) continue;
            return potionEffectType;
        }
        return null;
    }

    private boolean isCrimsonBlade(ItemStack itemStack) {
        if (itemStack == null || itemStack.getType() == Material.AIR || !itemStack.hasItemMeta()) {
            return false;
        }
        ItemMeta itemMeta = itemStack.getItemMeta();
        NamespacedKey namespacedKey = itemMeta.getItemModel();
        return namespacedKey != null && namespacedKey.toString().equals("hunt:crimson_blade");
    }

    private void extractBundledPack() {
        Path path = this.getDataFolder().toPath().resolve("generated-pack").resolve("HuntSMP-Crimson-Pack-1.22.3.zip");
        try {
            Files.createDirectories(path.getParent(), new FileAttribute[0]);
            try (InputStream inputStream = this.getResource(BUNDLED_PACK);){
                if (inputStream == null) {
                    this.getLogger().severe("Bundled Crimson resource pack is missing from the plugin JAR.");
                    return;
                }
                Files.copy(inputStream, path, StandardCopyOption.REPLACE_EXISTING);
            }
            this.getLogger().info("Extracted bundled Crimson pack to " + String.valueOf(path.toAbsolutePath()));
        }
        catch (IOException iOException) {
            this.getLogger().severe("Could not extract bundled Crimson pack: " + iOException.getMessage());
        }
    }
}

