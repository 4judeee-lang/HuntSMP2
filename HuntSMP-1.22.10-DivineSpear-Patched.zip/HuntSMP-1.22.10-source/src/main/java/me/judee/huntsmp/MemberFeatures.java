/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntsmp;

import com.destroystokyo.paper.entity.villager.Reputation;
import com.destroystokyo.paper.entity.villager.ReputationType;
import java.io.File;
import java.io.IOException;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import me.judee.huntsmp.HuntPlugin;
import me.judee.huntsmp.PremiumText;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Statistic;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Leaves;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.AbstractVillager;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.VillagerAcquireTradeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerBedLeaveEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitTask;

final class MemberFeatures
implements Listener {
    private static final EnchantOffer[] DESIRABLE_BOOKS = new EnchantOffer[]{new EnchantOffer(Enchantment.PROTECTION, 4), new EnchantOffer(Enchantment.SHARPNESS, 5), new EnchantOffer(Enchantment.MENDING, 1), new EnchantOffer(Enchantment.UNBREAKING, 3), new EnchantOffer(Enchantment.DEPTH_STRIDER, 3), new EnchantOffer(Enchantment.AQUA_AFFINITY, 1)};
    private final HuntPlugin plugin;
    private final Set<TrustLink> trustLinks = new HashSet<TrustLink>();
    private final Map<TrustLink, BetrayalCounter> betrayalCounters = new HashMap<TrustLink, BetrayalCounter>();
    private final File statsFile;
    private final YamlConfiguration stats;
    private BukkitTask sleepTask;
    private UUID sleepLeader;

    MemberFeatures(HuntPlugin plugin) {
        this.plugin = plugin;
        this.statsFile = new File(plugin.getDataFolder(), "player-stats.yml");
        this.stats = YamlConfiguration.loadConfiguration((File)this.statsFile);
        this.loadTrustLinks();
    }

    boolean handleMemberCommand(CommandSender sender, String[] args) {
        if (args.length == 0) {
            return false;
        }
        if (args[0].equalsIgnoreCase("stats")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(MemberFeatures.color("&cOnly players have Hunt statistics."));
                return true;
            }
            Player player = (Player)sender;
            if (args.length != 1) {
                sender.sendMessage(MemberFeatures.color("&6&lHUNT &8\u00bb &fUsage: &e/hunt stats"));
                return true;
            }
            this.openStats(player);
            return true;
        }
        if (!args[0].equalsIgnoreCase("trust")) {
            return false;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(MemberFeatures.color("&cOnly players can manage trust."));
            return true;
        }
        Player player = (Player)sender;
        if (args.length != 2) {
            player.sendMessage(MemberFeatures.color("&6&lHUNT &8\u00bb &fUsage: &e/hunt trust <player>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact((String)args[1]);
        if (target == null || !target.isOnline()) {
            player.sendMessage(MemberFeatures.color("&6&lHUNT &8\u00bb &cThat player is not online."));
            return true;
        }
        if (target.equals((Object)player)) {
            player.sendMessage(MemberFeatures.color("&6&lHUNT &8\u00bb &cYou cannot trust yourself."));
            return true;
        }
        this.toggleTrust(player, target);
        return true;
    }

    List<String> tabComplete(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            return List.of();
        }
        if (args.length == 1) {
            String typed = args[0].toLowerCase();
            return List.of("stats", "trust").stream().filter(value -> value.startsWith(typed)).toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("trust")) {
            String typed = args[1].toLowerCase();
            return Bukkit.getOnlinePlayers().stream().filter(player -> !player.equals((Object)sender)).map(Player::getName).filter(name -> name.toLowerCase().startsWith(typed)).sorted(String.CASE_INSENSITIVE_ORDER).toList();
        }
        return List.of();
    }

    void recordVault(Player player) {
        this.increment(player.getUniqueId(), "vaults-opened");
    }

    void recordMace(Player player) {
        this.increment(player.getUniqueId(), "maces-crafted");
    }

    boolean blocksDamage(Player victim, Player attacker) {
        return this.trustLinks.contains(new TrustLink(victim.getUniqueId(), attacker.getUniqueId()));
    }

    void shutdown() {
        this.cancelSleep(false);
        this.saveStats();
        this.saveTrustLinks();
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPluginList(PlayerCommandPreprocessEvent event) {
        if (event.getPlayer().isOp()) {
            return;
        }
        String command = event.getMessage().substring(1).trim().split("\\s+")[0].toLowerCase();
        if (command.contains(":")) {
            command = command.substring(command.indexOf(58) + 1);
        }
        if (command.equals("pl") || command.equals("plugins")) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(MemberFeatures.color("&fPlugins (1): &aHuntSMP"));
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onTrustedDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player)) {
            return;
        }
        Player victim = (Player)entity;
        Player attacker = this.responsiblePlayer(event);
        if (attacker == null || attacker.equals((Object)victim)) {
            return;
        }
        TrustLink link = new TrustLink(victim.getUniqueId(), attacker.getUniqueId());
        if (!this.trustLinks.contains(link)) {
            return;
        }
        event.setCancelled(true);
        this.registerBetrayalAttempt(link, victim, attacker);
    }

    private Player responsiblePlayer(EntityDamageEvent event) {
        Projectile projectile;
        ProjectileSource shooter;
        Entity causing = event.getDamageSource().getCausingEntity();
        if (causing instanceof Player) {
            Player player = (Player)causing;
            return player;
        }
        Entity direct = event.getDamageSource().getDirectEntity();
        if (direct instanceof Projectile && (shooter = (projectile = (Projectile)direct).getShooter()) instanceof Player) {
            Player player = (Player)shooter;
            return player;
        }
        return null;
    }

    private void registerBetrayalAttempt(TrustLink link, Player victim, Player attacker) {
        long now = System.currentTimeMillis();
        long window = (long)Math.max(1, this.plugin.getConfig().getInt("trust.betrayal-window-seconds", 10)) * 1000L;
        BetrayalCounter previous = this.betrayalCounters.get(link);
        int attempts = previous == null || now - previous.lastAttempt() > window ? 1 : previous.attempts() + 1;
        this.betrayalCounters.put(link, new BetrayalCounter(attempts, now));
        int threshold = Math.max(1, this.plugin.getConfig().getInt("trust.betrayal-hit-threshold", 3));
        if (attempts >= threshold) {
            this.trustLinks.remove(link);
            this.betrayalCounters.remove(link);
            this.saveTrustLinks();
            victim.sendMessage(MemberFeatures.color("&6&lHUNT &8\u00bb &c" + attacker.getName() + " was automatically untrusted after repeated attacks."));
            attacker.sendMessage(MemberFeatures.color("&6&lHUNT &8\u00bb &c" + victim.getName() + " no longer trusts you."));
            Bukkit.broadcastMessage((String)MemberFeatures.color("&c&lBETRAYAL &8\u00bb &f" + attacker.getName() + " &7broke &f" + victim.getName() + "&7's trust."));
        } else {
            attacker.sendActionBar((Component)Component.text((String)("Trusted hit blocked: " + attempts + "/" + threshold), (TextColor)NamedTextColor.RED));
        }
    }

    private void toggleTrust(Player owner, Player target) {
        TrustLink link = new TrustLink(owner.getUniqueId(), target.getUniqueId());
        if (this.trustLinks.remove(link)) {
            this.betrayalCounters.remove(link);
            owner.sendMessage(MemberFeatures.color("&6&lHUNT &8\u00bb &cYou no longer trust &f" + target.getName() + "&c."));
            target.sendMessage(MemberFeatures.color("&6&lHUNT &8\u00bb &e" + owner.getName() + " no longer trusts you."));
        } else {
            this.trustLinks.add(link);
            owner.sendMessage(MemberFeatures.color("&6&lHUNT &8\u00bb &aYou now trust &f" + target.getName() + "&a. Their damage against you will be blocked."));
            target.sendMessage(MemberFeatures.color("&6&lHUNT &8\u00bb &a" + owner.getName() + " now trusts you."));
        }
        this.saveTrustLinks();
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onVillagerHit(EntityDamageEvent event) {
        Villager villager;
        block5: {
            block4: {
                Entity entity = event.getEntity();
                if (!(entity instanceof Villager)) break block4;
                villager = (Villager)entity;
                if (this.plugin.getConfig().getBoolean("villagers.prevent-hit-price-increase", true)) break block5;
            }
            return;
        }
        Player attacker = this.responsiblePlayer(event);
        if (attacker == null) {
            return;
        }
        Reputation snapshot = this.copyReputation(villager.getReputation(attacker.getUniqueId()));
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
            if (villager.isValid()) {
                villager.setReputation(attacker.getUniqueId(), snapshot);
            }
        });
    }

    private Reputation copyReputation(Reputation source) {
        EnumMap<ReputationType, Integer> values = new EnumMap<ReputationType, Integer>(ReputationType.class);
        for (ReputationType type : ReputationType.values()) {
            if (!source.hasReputationSet(type)) continue;
            values.put(type, source.getReputation(type));
        }
        return new Reputation(values);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onLibrarianTrade(VillagerAcquireTradeEvent event) {
        Villager villager;
        AbstractVillager abstractVillager = event.getEntity();
        if (!(abstractVillager instanceof Villager) || (villager = (Villager)abstractVillager).getProfession() != Villager.Profession.LIBRARIAN || event.getRecipe().getResult().getType() != Material.ENCHANTED_BOOK) {
            return;
        }
        double chance = Math.max(0.0, Math.min(100.0, this.plugin.getConfig().getDouble("villagers.desirable-book-chance-percent", 75.0)));
        if (ThreadLocalRandom.current().nextDouble(100.0) >= chance) {
            return;
        }
        EnchantOffer offer = DESIRABLE_BOOKS[ThreadLocalRandom.current().nextInt(DESIRABLE_BOOKS.length)];
        ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
        EnchantmentStorageMeta meta = (EnchantmentStorageMeta)book.getItemMeta();
        meta.addStoredEnchant(offer.enchantment(), offer.level(), true);
        book.setItemMeta((ItemMeta)meta);
        MerchantRecipe original = event.getRecipe();
        MerchantRecipe replacement = new MerchantRecipe(book, original.getUses(), original.getMaxUses(), original.hasExperienceReward(), original.getVillagerExperience(), original.getPriceMultiplier(), original.getDemand(), original.getSpecialPrice(), original.shouldIgnoreDiscounts());
        replacement.setIngredients(original.getIngredients());
        event.setRecipe(replacement);
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBedEnter(PlayerBedEnterEvent event) {
        if (!this.plugin.getConfig().getBoolean("qol.one-player-sleep", true) || event.getBedEnterResult() != PlayerBedEnterEvent.BedEnterResult.OK) {
            return;
        }
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
            if (event.getPlayer().isSleeping()) {
                this.startSleepCountdown(event.getPlayer());
            }
        });
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onBedLeave(PlayerBedLeaveEvent event) {
        if (event.getPlayer().getUniqueId().equals(this.sleepLeader)) {
            this.cancelSleep(true);
        }
    }

    private void startSleepCountdown(Player player) {
        if (this.sleepTask != null) {
            return;
        }
        this.sleepLeader = player.getUniqueId();
        int[] seconds = new int[]{Math.max(1, this.plugin.getConfig().getInt("qol.sleep-countdown-seconds", 5))};
        this.sleepTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, () -> {
            Player sleeper = Bukkit.getPlayer((UUID)this.sleepLeader);
            if (sleeper == null || !sleeper.isOnline() || !sleeper.isSleeping()) {
                this.cancelSleep(true);
                return;
            }
            if (seconds[0] <= 0) {
                World world = sleeper.getWorld();
                this.sleepTask.cancel();
                this.sleepTask = null;
                this.sleepLeader = null;
                world.setTime(0L);
                world.setStorm(false);
                world.setThundering(false);
                for (Player online : world.getPlayers()) {
                    online.sendActionBar((Component)Component.text((String)"Good morning!", (TextColor)NamedTextColor.GOLD));
                    if (!online.isSleeping()) continue;
                    online.wakeup(false);
                }
                return;
            }
            TextComponent message = Component.text((String)(sleeper.getName() + " is skipping the night in " + seconds[0] + "s"), (TextColor)NamedTextColor.YELLOW);
            for (Player online : sleeper.getWorld().getPlayers()) {
                online.sendActionBar((Component)message);
            }
            seconds[0] = seconds[0] - 1;
        }, 0L, 20L);
    }

    private void cancelSleep(boolean announce) {
        if (this.sleepTask != null) {
            this.sleepTask.cancel();
            this.sleepTask = null;
            if (announce) {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.sendActionBar((Component)Component.text((String)"Sleep countdown cancelled", (TextColor)NamedTextColor.GRAY));
                }
            }
        }
        this.sleepLeader = null;
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onLogBreak(BlockBreakEvent event) {
        if (!this.plugin.getConfig().getBoolean("qol.fast-leaf-decay", true) || !Tag.LOGS.isTagged((Keyed)event.getBlock().getType())) {
            return;
        }
        Block origin = event.getBlock();
        for (long delay : new long[]{5L, 12L, 24L}) {
            Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.decayLeaves(origin), delay);
        }
    }

    private void decayLeaves(Block origin) {
        int radius = Math.max(2, Math.min(8, this.plugin.getConfig().getInt("qol.leaf-decay-radius", 6)));
        World world = origin.getWorld();
        for (int x = -radius; x <= radius; ++x) {
            for (int y = -radius; y <= radius; ++y) {
                for (int z = -radius; z <= radius; ++z) {
                    Leaves leaves;
                    Block block = world.getBlockAt(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                    BlockData blockData = block.getBlockData();
                    if (!(blockData instanceof Leaves) || (leaves = (Leaves)blockData).isPersistent() || leaves.getDistance() < leaves.getMaximumDistance()) continue;
                    block.breakNaturally();
                }
            }
        }
    }

    private void openStats(Player player) {
        Inventory inventory;
        StatsHolder holder = new StatsHolder();
        holder.inventory = inventory = Bukkit.createInventory((InventoryHolder)holder, (int)27, (Component)PremiumText.mini("HUNT   |   YOUR PROFILE", 0xFF9A9A, 10298180));
        ItemStack filler = this.menuItem(Material.BLACK_STAINED_GLASS_PANE, "&0", List.of());
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta headMeta = (SkullMeta)head.getItemMeta();
        headMeta.setOwningPlayer((OfflinePlayer)player);
        headMeta.displayName(PremiumText.mini(player.getName().toUpperCase() + "   |   HUNT PROFILE", 0xFF9A9A, 12135243));
        head.setItemMeta((ItemMeta)headMeta);
        inventory.setItem(4, head);
        inventory.setItem(10, this.menuItem(Material.DIAMOND_SWORD, "&cPlayer kills", List.of("&f" + player.getStatistic(Statistic.PLAYER_KILLS))));
        inventory.setItem(12, this.menuItem(Material.SKELETON_SKULL, "&7Deaths", List.of("&f" + player.getStatistic(Statistic.DEATHS))));
        inventory.setItem(14, this.menuItem(Material.CLOCK, "&ePlaytime", List.of("&f" + this.formatPlaytime(player.getStatistic(Statistic.PLAY_ONE_MINUTE)))));
        inventory.setItem(16, this.menuItem(Material.VAULT, "&6Vaults opened", List.of("&f" + this.stat(player.getUniqueId(), "vaults-opened"))));
        inventory.setItem(22, this.menuItem(Material.MACE, "&bMaces crafted", List.of("&f" + this.stat(player.getUniqueId(), "maces-crafted"))));
        player.openInventory(inventory);
    }

    @EventHandler
    public void onStatsClick(InventoryClickEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof StatsHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onStatsDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof StatsHolder) {
            event.setCancelled(true);
        }
    }

    private String formatPlaytime(int ticks) {
        long seconds = (long)ticks / 20L;
        long hours = seconds / 3600L;
        return String.format("%dh %02dm", hours, seconds % 3600L / 60L);
    }

    private int stat(UUID uuid, String key) {
        return Math.max(0, this.stats.getInt("players." + String.valueOf(uuid) + "." + key, 0));
    }

    private void increment(UUID uuid, String key) {
        this.stats.set("players." + String.valueOf(uuid) + "." + key, (Object)(this.stat(uuid, key) + 1));
        this.saveStats();
    }

    private void saveStats() {
        try {
            this.stats.save(this.statsFile);
        }
        catch (IOException exception) {
            this.plugin.getLogger().warning("Could not save player-stats.yml: " + exception.getMessage());
        }
    }

    private void loadTrustLinks() {
        this.trustLinks.clear();
        for (String encoded : this.plugin.getConfig().getStringList("trusted-players")) {
            String[] parts = encoded.split(">");
            if (parts.length != 2) continue;
            try {
                this.trustLinks.add(new TrustLink(UUID.fromString(parts[0]), UUID.fromString(parts[1])));
            }
            catch (IllegalArgumentException ignored) {
                this.plugin.getLogger().warning("Ignored invalid trust entry: " + encoded);
            }
        }
    }

    private void saveTrustLinks() {
        this.plugin.getConfig().set("trusted-players", this.trustLinks.stream().map(link -> String.valueOf(link.owner()) + ">" + String.valueOf(link.trusted())).sorted().toList());
        this.plugin.saveConfig();
    }

    private ItemStack menuItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(PremiumText.menuTitle(name));
        meta.lore(lore.stream().map(PremiumText::menuLore).toList());
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
        item.setItemMeta(meta);
        return item;
    }

    private static String color(String text) {
        return PremiumText.legacyStyled(text);
    }

    private record TrustLink(UUID owner, UUID trusted) {
    }

    private record BetrayalCounter(int attempts, long lastAttempt) {
    }

    private record EnchantOffer(Enchantment enchantment, int level) {
    }

    private static final class StatsHolder
    implements InventoryHolder {
        private Inventory inventory;

        private StatsHolder() {
        }

        public Inventory getInventory() {
            return this.inventory;
        }
    }
}

