/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntsmp;

import java.lang.invoke.CallSite;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import me.judee.huntsmp.FeaturePatch;
import me.judee.huntsmp.HuntPlugin;
import me.judee.huntsmp.PremiumText;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.CommandSender;
import org.bukkit.damage.DamageType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TextDisplay;
import org.bukkit.entity.Trident;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

final class AltarManager
implements Listener {
    private static final int DRILL_SLOT = 11;
    private static final int MACE_SLOT = 13;
    private static final int LIGHTNING_SLOT = 15;
    private static final int LIGHTNING_MAX_CHARGES = 3;
    private static final long LIGHTNING_RECHARGE_MILLIS = 90000L;
    private static final long MACE_DOMAIN_COOLDOWN_MILLIS = 180000L;
    private static final long MACE_DOMAIN_DURATION_MILLIS = 18000L;
    private static final double MACE_DOMAIN_RADIUS = 12.0;
    private static final double LIGHTNING_DAMAGE = 10.0;
    private static final double LIGHTNING_IMPACT_RADIUS = 3.0;
    private static final Particle.DustOptions LIGHTNING_TRAIL_DUST = new Particle.DustOptions(Color.fromRGB((int)255, (int)225, (int)74), 1.15f);
    private final HuntPlugin plugin;
    private final NamespacedKey weaponKey;
    private final NamespacedKey drillModeKey;
    private final NamespacedKey chargeKey;
    private final NamespacedKey rechargeKey;
    private final NamespacedKey maceCooldownKey;
    private final NamespacedKey altarRoleKey;
    private final NamespacedKey altarTypeKey;
    private final NamespacedKey altarGroupKey;
    private final NamespacedKey drillRecipeKey;
    private final NamespacedKey lightningRecipeKey;
    private final NamespacedKey maceRecipeKey;
    private final Set<UUID> drillBreaking = new HashSet<UUID>();
    private final Set<UUID> altarRelics = new HashSet<UUID>();
    private final Map<UUID, BossBar> lightningBars = new HashMap<UUID, BossBar>();
    private final Map<UUID, BossBar> maceBars = new HashMap<UUID, BossBar>();
    private final Map<UUID, MaceCombo> maceCombos = new HashMap<UUID, MaceCombo>();
    private final Map<UUID, Long> stunnedUntil = new HashMap<UUID, Long>();
    private final Map<UUID, BukkitTask> activeDomains = new HashMap<UUID, BukkitTask>();
    private BukkitTask animationTask;

    AltarManager(HuntPlugin plugin) {
        this.plugin = plugin;
        this.weaponKey = new NamespacedKey((Plugin)plugin, "altar_weapon");
        this.drillModeKey = new NamespacedKey((Plugin)plugin, "drill_mode");
        this.chargeKey = new NamespacedKey((Plugin)plugin, "lightning_charges");
        this.rechargeKey = new NamespacedKey((Plugin)plugin, "lightning_recharge_at");
        this.maceCooldownKey = new NamespacedKey((Plugin)plugin, "mace_domain_cooldown_at");
        this.altarRoleKey = new NamespacedKey((Plugin)plugin, "altar_role");
        this.altarTypeKey = new NamespacedKey((Plugin)plugin, "altar_type");
        this.altarGroupKey = new NamespacedKey((Plugin)plugin, "altar_group");
        this.drillRecipeKey = new NamespacedKey((Plugin)plugin, "drill_pickaxe");
        this.lightningRecipeKey = new NamespacedKey((Plugin)plugin, "lightning_bolt");
        this.maceRecipeKey = new NamespacedKey((Plugin)plugin, "sovereign_mace");
    }

    void start() {
        this.registerRecipes();
        for (World world : Bukkit.getWorlds()) {
            String role;
            for (TextDisplay text : new ArrayList(world.getEntitiesByClass(TextDisplay.class))) {
                role = (String)text.getPersistentDataContainer().get(this.altarRoleKey, PersistentDataType.STRING);
                if (!"title".equals(role) && !"recipe".equals(role)) continue;
                text.remove();
            }
            for (ItemDisplay display : world.getEntitiesByClass(ItemDisplay.class)) {
                role = (String)display.getPersistentDataContainer().get(this.altarRoleKey, PersistentDataType.STRING);
                if ("relic".equals(role)) {
                    this.altarRelics.add(display.getUniqueId());
                    continue;
                }
                if (!"base".equals(role)) continue;
                AltarWeapon weapon = AltarWeapon.parse((String)display.getPersistentDataContainer().get(this.altarTypeKey, PersistentDataType.STRING));
                String group = (String)display.getPersistentDataContainer().get(this.altarGroupKey, PersistentDataType.STRING);
                if (weapon == null) continue;
                this.spawnAltarText(display.getLocation().clone().subtract(0.5, 0.5, 0.5), weapon, group == null ? UUID.randomUUID().toString() : group);
            }
        }
        this.animationTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::animateAltarsAndHud, 1L, 1L);
    }

    void shutdown() {
        if (this.animationTask != null) {
            this.animationTask.cancel();
        }
        for (BossBar bar : this.lightningBars.values()) {
            bar.removeAll();
        }
        for (BossBar bar : this.maceBars.values()) {
            bar.removeAll();
        }
        this.lightningBars.clear();
        this.maceBars.clear();
        for (BukkitTask task : this.activeDomains.values()) {
            task.cancel();
        }
        this.activeDomains.clear();
        Bukkit.removeRecipe((NamespacedKey)this.drillRecipeKey);
        Bukkit.removeRecipe((NamespacedKey)this.lightningRecipeKey);
        Bukkit.removeRecipe((NamespacedKey)this.maceRecipeKey);
    }

    boolean handleCommand(CommandSender sender, String[] args) {
        SelectionAction action;
        if (args.length == 0 || !args[0].equalsIgnoreCase("altar")) {
            return false;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only a player can place or receive Hunt altars.");
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 2 && args[1].equalsIgnoreCase("remove")) {
            this.removeLookedAtAltar(player);
            return true;
        }
        if (args.length < 2 || args.length > 3 || !args[1].equalsIgnoreCase("give") && !args[1].equalsIgnoreCase("spawn")) {
            this.sendUsage(player);
            return true;
        }
        SelectionAction selectionAction = action = args[1].equalsIgnoreCase("give") ? SelectionAction.GIVE : SelectionAction.SPAWN;
        if (args.length == 2 || args[2].equalsIgnoreCase("weapon")) {
            this.openSelector(player, action);
            return true;
        }
        AltarWeapon weapon = AltarWeapon.parse(args[2]);
        if (weapon == null) {
            this.sendUsage(player);
            return true;
        }
        this.perform(player, action, weapon);
        return true;
    }

    List<String> tabComplete(String[] args) {
        if (args.length == 1) {
            return "altar".startsWith(args[0].toLowerCase()) ? List.of("altar") : List.of();
        }
        if (!args[0].equalsIgnoreCase("altar")) {
            return List.of();
        }
        if (args.length == 2) {
            String typed = args[1].toLowerCase();
            return List.of("give", "spawn", "remove").stream().filter(option -> option.startsWith(typed)).toList();
        }
        if (args.length == 3) {
            String typed = args[2].toLowerCase();
            return List.of("weapon", "drill", "mace", "lightning").stream().filter(option -> option.startsWith(typed)).toList();
        }
        return List.of();
    }

    boolean handleWeaponSwap(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (!player.isSneaking() || !this.canFireLightningNow(player, player.getInventory().getItemInMainHand(), AltarWeapon.LIGHTNING)) {
            return false;
        }
        event.setCancelled(true);
        player.setCooldown(player.getInventory().getItemInMainHand().getType(), 16);
        this.fireLightning(player, player.getInventory().getItemInMainHand());
        return true;
    }

    boolean isSovereignMace(ItemStack item) {
        return this.isWeapon(item, AltarWeapon.MACE);
    }

    void refreshInventoryText(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            this.refreshWeaponText(item);
        }
    }

    private void refreshWeaponText(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return;
        }
        String id = (String)item.getItemMeta().getPersistentDataContainer().get(this.weaponKey, PersistentDataType.STRING);
        AltarWeapon weapon = AltarWeapon.parse(id);
        if (weapon == null) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        meta.displayName(this.weaponItemName(weapon));
        if (weapon == AltarWeapon.DRILL) {
            meta.lore(this.drillLore(this.getDrillMode(item)));
        } else if (weapon == AltarWeapon.LIGHTNING) {
            int charges = (Integer)meta.getPersistentDataContainer().getOrDefault(this.chargeKey, PersistentDataType.INTEGER, (Object)3);
            meta.lore(this.lightningLore(charges));
        } else {
            meta.lore(this.maceLore());
        }
        item.setItemMeta(meta);
    }

    private void sendUsage(Player player) {
        player.sendMessage(Component.text((String)"HUNT ALTAR \u00bb ", (TextColor)NamedTextColor.GOLD).append((Component)Component.text((String)"/hunt altar <give|spawn> <weapon|drill|mace|lightning> or /hunt altar remove", (TextColor)NamedTextColor.YELLOW)));
    }

    private void perform(Player player, SelectionAction action, AltarWeapon weapon) {
        if (action == SelectionAction.GIVE) {
            ItemStack item = this.createWeapon(weapon);
            if (player.getInventory().addItem(new ItemStack[]{item}).isEmpty()) {
                player.sendMessage(Component.text((String)"HUNT ALTAR \u00bb ", (TextColor)NamedTextColor.GOLD).append((Component)Component.text((String)("You received " + weapon.displayName + "."), (TextColor)weapon.color)));
            } else {
                player.getWorld().dropItemNaturally(player.getLocation(), item);
            }
            player.playSound(player.getLocation(), Sound.BLOCK_VAULT_OPEN_SHUTTER, 0.9f, 1.25f);
            return;
        }
        this.spawnAltar(player, weapon);
    }

    private void openSelector(Player player, SelectionAction action) {
        Inventory inventory;
        AltarSelector holder = new AltarSelector(action);
        holder.inventory = inventory = Bukkit.createInventory((InventoryHolder)holder, (int)27, (Component)PremiumText.mini(action == SelectionAction.GIVE ? "RELIC ARCHIVE   |   ACQUIRE" : "ALTAR ARCHIVE   |   RELEASE", 0xFFB0B0, 9316683));
        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.displayName((Component)Component.empty());
        filler.setItemMeta(fillerMeta);
        for (int slot = 0; slot < 27; ++slot) {
            inventory.setItem(slot, filler);
        }
        inventory.setItem(11, this.createWeapon(AltarWeapon.DRILL));
        inventory.setItem(13, this.createWeapon(AltarWeapon.MACE));
        inventory.setItem(15, this.createWeapon(AltarWeapon.LIGHTNING));
        player.openInventory(inventory);
    }

    @EventHandler
    public void onSelectorClick(InventoryClickEvent event) {
        AltarWeapon weapon;
        Player player;
        InventoryHolder inventoryHolder = event.getView().getTopInventory().getHolder();
        if (!(inventoryHolder instanceof AltarSelector)) {
            return;
        }
        AltarSelector holder = (AltarSelector)inventoryHolder;
        event.setCancelled(true);
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player) || !(player = (Player)humanEntity).isOp()) {
            return;
        }
        AltarWeapon altarWeapon = event.getRawSlot() == 11 ? AltarWeapon.DRILL : (event.getRawSlot() == 13 ? AltarWeapon.MACE : (weapon = event.getRawSlot() == 15 ? AltarWeapon.LIGHTNING : null));
        if (weapon == null) {
            return;
        }
        player.closeInventory();
        this.perform(player, holder.action, weapon);
    }

    @EventHandler
    public void onSelectorDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof AltarSelector) {
            event.setCancelled(true);
        }
    }

    private void spawnAltar(Player player, AltarWeapon weapon) {
        Block target = player.getTargetBlockExact(8);
        Location anchor = target == null ? player.getLocation().getBlock().getLocation() : target.getLocation().add(0.0, 1.0, 0.0);
        Block collision = anchor.getBlock();
        if (!collision.isEmpty() && collision.getType() != Material.BARRIER) {
            player.sendMessage((Component)Component.text((String)"HUNT ALTAR \u00bb That space is blocked.", (TextColor)NamedTextColor.RED));
            return;
        }
        collision.setType(Material.BARRIER, false);
        String group = UUID.randomUUID().toString();
        Location center = anchor.clone().add(0.5, 0.5, 0.5);
        ItemDisplay base = (ItemDisplay)anchor.getWorld().spawn(center, ItemDisplay.class, display -> {
            display.setItemStack(this.modelItem(Material.PAPER, "weapon_altar"));
            display.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            display.setBrightness(new Display.Brightness(15, 15));
            display.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(1.02f), new Quaternionf()));
            this.tag((Display)display, "base", weapon, group);
        });
        base.setPersistent(true);
        ItemDisplay relic = (ItemDisplay)anchor.getWorld().spawn(anchor.clone().add(0.5, 1.85, 0.5), ItemDisplay.class, display -> {
            display.setItemStack(this.createWeapon(weapon));
            display.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            display.setBrightness(new Display.Brightness(15, 15));
            display.setBillboard(Display.Billboard.FIXED);
            display.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(0.85f), new Quaternionf()));
            this.tag((Display)display, "relic", weapon, group);
        });
        relic.setPersistent(true);
        this.altarRelics.add(relic.getUniqueId());
        this.spawnAltarText(anchor, weapon, group);
        anchor.getWorld().playSound(center, Sound.BLOCK_END_PORTAL_SPAWN, 0.8f, 1.45f);
        anchor.getWorld().spawnParticle(Particle.ITEM, center.clone().add(0.0, 1.0, 0.0), 55, 0.8, 1.0, 0.8, 0.08, (Object)this.particleItem(weapon));
        player.sendMessage(Component.text((String)"HUNT ALTAR \u00bb ", (TextColor)NamedTextColor.GOLD).append((Component)Component.text((String)(weapon.displayName + " altar released."), (TextColor)weapon.color)));
    }

    private void spawnAltarText(Location anchor, AltarWeapon weapon, String group) {
        List<Component> rows = this.recipeRows(weapon);
        for (int index = 0; index < rows.size(); ++index) {
            int rowIndex = index;
            TextDisplay row = (TextDisplay)anchor.getWorld().spawn(anchor.clone().add(0.5, 3.91 - (double)index * 0.205, 0.5), TextDisplay.class, display -> {
                display.text((Component)rows.get(rowIndex));
                display.setBillboard(Display.Billboard.CENTER);
                display.setSeeThrough(false);
                display.setShadowed(true);
                display.setLineWidth(310);
                display.setBackgroundColor(Color.fromARGB((int)(rowIndex == 0 ? 158 : 96), (int)7, (int)8, (int)12));
                display.setBrightness(new Display.Brightness(15, 15));
                display.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(rowIndex == 0 ? 1.08f : (rowIndex == 1 ? 0.86f : 0.94f)), new Quaternionf()));
                this.tag((Display)display, rowIndex == 0 ? "title" : "recipe", weapon, group);
            });
            row.setPersistent(true);
        }
    }

    private void removeLookedAtAltar(Player player) {
        Vector sight = player.getEyeLocation().getDirection().normalize();
        ItemDisplay selected = null;
        double bestScore = Double.NEGATIVE_INFINITY;
        for (ItemDisplay display : player.getWorld().getEntitiesByClass(ItemDisplay.class)) {
            double score;
            double alignment;
            Vector offset;
            double distance;
            if (!"base".equals(display.getPersistentDataContainer().get(this.altarRoleKey, PersistentDataType.STRING)) || (distance = (offset = display.getLocation().toVector().subtract(player.getEyeLocation().toVector())).length()) > 12.0 || distance < 0.1 || (alignment = sight.dot(offset.normalize())) < 0.72 || !((score = alignment * 4.0 - distance * 0.08) > bestScore)) continue;
            bestScore = score;
            selected = display;
        }
        if (selected == null) {
            player.sendMessage(Component.text((String)"HUNT ALTAR \u00bb ", (TextColor)NamedTextColor.GOLD).append((Component)Component.text((String)"Look toward an altar within 12 blocks.", (TextColor)NamedTextColor.RED)));
            return;
        }
        String group = (String)selected.getPersistentDataContainer().get(this.altarGroupKey, PersistentDataType.STRING);
        String type = (String)selected.getPersistentDataContainer().get(this.altarTypeKey, PersistentDataType.STRING);
        Location center = selected.getLocation().clone();
        for (Entity entity : new ArrayList(player.getWorld().getEntities())) {
            boolean legacyMatch;
            Display display;
            if (!(entity instanceof Display) || (display = (Display)entity).getPersistentDataContainer().get(this.altarRoleKey, PersistentDataType.STRING) == null) continue;
            String entityGroup = (String)display.getPersistentDataContainer().get(this.altarGroupKey, PersistentDataType.STRING);
            boolean sameGroup = group != null && group.equals(entityGroup);
            boolean bl = legacyMatch = group == null && type != null && type.equals(display.getPersistentDataContainer().get(this.altarTypeKey, PersistentDataType.STRING)) && display.getLocation().distanceSquared(center) <= 16.0;
            if (!sameGroup && !legacyMatch) continue;
            this.altarRelics.remove(display.getUniqueId());
            display.remove();
        }
        Block collision = center.getBlock();
        if (collision.getType() == Material.BARRIER) {
            collision.setType(Material.AIR, false);
        }
        player.getWorld().spawnParticle(Particle.SMOKE, center.clone().add(0.0, 0.5, 0.0), 24, 0.55, 0.65, 0.55, 0.03);
        player.playSound(center, Sound.BLOCK_VAULT_CLOSE_SHUTTER, 0.9f, 0.75f);
        player.sendMessage(Component.text((String)"HUNT ALTAR \u00bb ", (TextColor)NamedTextColor.GOLD).append((Component)Component.text((String)"The altar has been removed.", (TextColor)NamedTextColor.GRAY)));
    }

    private void tag(Display display, String role, AltarWeapon weapon, String group) {
        display.getPersistentDataContainer().set(this.altarRoleKey, PersistentDataType.STRING, (Object)role);
        display.getPersistentDataContainer().set(this.altarTypeKey, PersistentDataType.STRING, (Object)weapon.id);
        display.getPersistentDataContainer().set(this.altarGroupKey, PersistentDataType.STRING, (Object)group);
    }

    private List<Component> recipeRows(AltarWeapon weapon) {
        if (weapon == AltarWeapon.DRILL) {
            return List.of(this.relicHeading("DRILL PICKAXE", 16749028, 9522431), this.forgingHeading(), this.ingredient("x1", "Netherite Pickaxe", 0xFF8A8A, 13122915), this.ingredient("x1", "Nether Star", 12124118, 3262328), this.ingredient("x4", "Netherite Block", 0xFFFFFF, 9541800), this.ingredient("x2", "Echo Shard", 14215423, 8229321), this.ingredient("x1", "Heavy Core", 16771235, 12026672));
        }
        if (weapon == AltarWeapon.MACE) {
            return List.of(this.relicHeading("SOVEREIGN MACE", 15907071, 6824604), this.forgingHeading(), this.ingredient("x1", "Netherite Axe", 0xFF8A8A, 13122915), this.ingredient("x1", "Nether Star", 12124118, 3262328), this.ingredient("x4", "Netherite Block", 0xFFFFFF, 9541800), this.ingredient("x2", "Echo Shard", 14215423, 8229321), this.ingredient("x1", "Heavy Core", 16771235, 12026672));
        }
        return List.of(this.relicHeading("LIGHTNING BOLT", 16774307, 3592191), this.forgingHeading(), this.ingredient("x1", "Trident", 10418943, 3116287), this.ingredient("x1", "Nether Star", 12124118, 3262328), this.ingredient("x4", "Diamond Block", 0xD8FFFF, 4441816), this.ingredient("x2", "Echo Shard", 14215423, 8229321), this.ingredient("x1", "Heavy Core", 16771235, 12026672));
    }

    private Component ingredient(String amount, String name, int startRgb, int endRgb) {
        return ((TextComponent)Component.text((String)"\u25aa  ", (TextColor)NamedTextColor.DARK_GRAY).append(PremiumText.mini(amount + "  ", 16770979, 12684337))).append(PremiumText.mini(name.toUpperCase(), startRgb, endRgb));
    }

    private Component relicHeading(String name, int startRgb, int endRgb) {
        return ((TextComponent)Component.text((String)"\u2726  ", (TextColor)NamedTextColor.DARK_GRAY).append(PremiumText.mini(" " + name + " ", startRgb, endRgb))).append((Component)Component.text((String)"  \u2726", (TextColor)NamedTextColor.DARK_GRAY));
    }

    private Component forgingHeading() {
        return PremiumText.mini("F O R G I N G   R E Q U I R E M E N T S", 15324315, 7695194);
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onAltarForge(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND || event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null || event.getClickedBlock().getType() != Material.BARRIER) {
            return;
        }
        Location center = event.getClickedBlock().getLocation().add(0.5, 0.5, 0.5);
        ItemDisplay base = null;
        for (Entity entity : center.getWorld().getNearbyEntities(center, 0.72, 0.72, 0.72)) {
            ItemDisplay candidate;
            if (!(entity instanceof ItemDisplay) || !"base".equals((candidate = (ItemDisplay)entity).getPersistentDataContainer().get(this.altarRoleKey, PersistentDataType.STRING))) continue;
            base = candidate;
            break;
        }
        if (base == null) {
            return;
        }
        event.setCancelled(true);
        AltarWeapon weapon = AltarWeapon.parse((String)base.getPersistentDataContainer().get(this.altarTypeKey, PersistentDataType.STRING));
        if (weapon == null) {
            return;
        }
        Player player = event.getPlayer();
        Map<Material, Integer> costs = this.recipeCosts(weapon);
        ArrayList<CallSite> missing = new ArrayList<CallSite>();
        for (Map.Entry<Material, Integer> cost : costs.entrySet()) {
            int owned = this.countMaterial(player, cost.getKey());
            if (owned >= cost.getValue()) continue;
            missing.add((CallSite)((Object)(cost.getValue() - owned + "x " + this.friendlyName(cost.getKey()))));
        }
        if (!missing.isEmpty()) {
            player.sendMessage(PremiumText.mini("FORGING FAILED   |   MISSING ", 16756879, 14826072).append(PremiumText.mini(String.join((CharSequence)"  /  ", missing).toUpperCase(), 0xFFFFFF, 11449536)));
            player.playSound(center, Sound.BLOCK_VAULT_REJECT_REWARDED_PLAYER, 0.8f, 0.7f);
            center.getWorld().spawnParticle(Particle.SMOKE, center.clone().add(0.0, 0.9, 0.0), 14, 0.35, 0.45, 0.35, 0.015);
            return;
        }
        costs.forEach((material, amount) -> this.removeMaterial(player, (Material)material, (int)amount));
        ItemStack result = this.createWeapon(weapon);
        HashMap overflow = player.getInventory().addItem(new ItemStack[]{result});
        overflow.values().forEach(item -> center.getWorld().dropItemNaturally(center.clone().add(0.0, 1.1, 0.0), item));
        player.sendMessage(PremiumText.mini("RELIC FORGED   |   ", 16771232, 12618289).append(PremiumText.mini(weapon.displayName.toUpperCase(), this.relicStart(weapon), this.relicEnd(weapon))));
        center.getWorld().playSound(center, Sound.BLOCK_VAULT_EJECT_ITEM, 1.0f, 0.8f);
        center.getWorld().playSound(center, Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.8f, 1.45f);
        center.getWorld().spawnParticle(Particle.ITEM, center.clone().add(0.0, 1.2, 0.0), 48, 0.65, 0.85, 0.65, 0.08, (Object)this.particleItem(weapon));
        center.getWorld().spawnParticle(Particle.END_ROD, center.clone().add(0.0, 1.2, 0.0), 22, 0.5, 0.75, 0.5, 0.025);
        this.collapseClaimedAltar(base, center, player, weapon);
        FeaturePatch.altarForged(player, weapon.displayName);
    }

    private void collapseClaimedAltar(ItemDisplay base, Location center, Player crafter, AltarWeapon weapon) {
        String group = (String)base.getPersistentDataContainer().get(this.altarGroupKey, PersistentDataType.STRING);
        String type = (String)base.getPersistentDataContainer().get(this.altarTypeKey, PersistentDataType.STRING);
        for (Entity entity : new ArrayList(center.getWorld().getEntities())) {
            boolean legacyMatch;
            Display display;
            if (!(entity instanceof Display) || (display = (Display)entity).getPersistentDataContainer().get(this.altarRoleKey, PersistentDataType.STRING) == null) continue;
            String entityGroup = (String)display.getPersistentDataContainer().get(this.altarGroupKey, PersistentDataType.STRING);
            boolean sameGroup = group != null && group.equals(entityGroup);
            boolean bl = legacyMatch = group == null && type != null && type.equals(display.getPersistentDataContainer().get(this.altarTypeKey, PersistentDataType.STRING)) && display.getLocation().distanceSquared(center) <= 16.0;
            if (!sameGroup && !legacyMatch) continue;
            this.altarRelics.remove(display.getUniqueId());
            display.remove();
        }
        Block altarBlock = center.getBlock();
        if (altarBlock.getType() == Material.BARRIER) {
            altarBlock.setType(Material.AIR, false);
        }
        center.getWorld().spawnParticle(Particle.END_ROD, center.clone().add(0.0, 1.2, 0.0), 48, 0.8, 1.2, 0.8, 0.05);
        center.getWorld().playSound(center, Sound.BLOCK_END_PORTAL_FRAME_FILL, 1.1f, 0.55f);
        Component announcement = PremiumText.gradient("HUNT RELIC", this.relicStart(weapon), this.relicEnd(weapon)).append((Component)Component.text((String)"   |   ", (TextColor)NamedTextColor.DARK_GRAY)).append(PremiumText.gradient(crafter.getName().toUpperCase() + " HAS CLAIMED " + weapon.displayName.toUpperCase(), 0xFFFFFF, this.relicEnd(weapon))).append((Component)Component.text((String)". The altar has collapsed.", (TextColor)NamedTextColor.GRAY));
        for (Player online : Bukkit.getOnlinePlayers()) {
            online.sendMessage(announcement);
        }
    }

    private Map<Material, Integer> recipeCosts(AltarWeapon weapon) {
        LinkedHashMap<Material, Integer> costs = new LinkedHashMap<Material, Integer>();
        if (weapon == AltarWeapon.DRILL) {
            costs.put(Material.NETHERITE_PICKAXE, 1);
            costs.put(Material.NETHER_STAR, 1);
            costs.put(Material.NETHERITE_BLOCK, 4);
        } else if (weapon == AltarWeapon.MACE) {
            costs.put(Material.NETHERITE_AXE, 1);
            costs.put(Material.NETHER_STAR, 1);
            costs.put(Material.NETHERITE_BLOCK, 4);
        } else {
            costs.put(Material.TRIDENT, 1);
            costs.put(Material.NETHER_STAR, 1);
            costs.put(Material.DIAMOND_BLOCK, 4);
        }
        costs.put(Material.ECHO_SHARD, 2);
        costs.put(Material.HEAVY_CORE, 1);
        return costs;
    }

    private int countMaterial(Player player, Material material) {
        int total = 0;
        for (ItemStack item : player.getInventory().getStorageContents()) {
            if (item == null || item.getType() != material) continue;
            total += item.getAmount();
        }
        return total;
    }

    private void removeMaterial(Player player, Material material, int amount) {
        ItemStack[] contents = player.getInventory().getStorageContents();
        int remaining = amount;
        for (int slot = 0; slot < contents.length && remaining > 0; ++slot) {
            ItemStack item = contents[slot];
            if (item == null || item.getType() != material) continue;
            int removed = Math.min(remaining, item.getAmount());
            remaining -= removed;
            if (item.getAmount() == removed) {
                contents[slot] = null;
                continue;
            }
            item.setAmount(item.getAmount() - removed);
        }
        player.getInventory().setStorageContents(contents);
    }

    private String friendlyName(Material material) {
        String[] words = material.name().toLowerCase().split("_");
        StringBuilder name = new StringBuilder();
        for (String word : words) {
            if (!name.isEmpty()) {
                name.append(' ');
            }
            name.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return name.toString();
    }

    private int relicStart(AltarWeapon weapon) {
        return weapon == AltarWeapon.DRILL ? 16749028 : (weapon == AltarWeapon.MACE ? 15907071 : 16774307);
    }

    private int relicEnd(AltarWeapon weapon) {
        return weapon == AltarWeapon.DRILL ? 9522431 : (weapon == AltarWeapon.MACE ? 6824604 : 3592191);
    }

    private void animateAltarsAndHud() {
        long tick = Bukkit.getCurrentTick();
        Iterator<UUID> iterator = this.altarRelics.iterator();
        while (iterator.hasNext()) {
            ItemDisplay display;
            Entity entity = Bukkit.getEntity((UUID)iterator.next());
            if (entity == null) continue;
            if (!(entity instanceof ItemDisplay) || !(display = (ItemDisplay)entity).isValid()) {
                iterator.remove();
                continue;
            }
            Object weapon = AltarWeapon.parse((String)display.getPersistentDataContainer().get(this.altarTypeKey, PersistentDataType.STRING));
            if (weapon == null) {
                iterator.remove();
                continue;
            }
            Location location = display.getLocation();
            location.setYaw((float)tick * 3.6f % 360.0f);
            double baseY = Math.floor(location.getY()) + 0.85;
            location.setY(baseY + Math.sin((double)tick * 0.08) * 0.12);
            display.teleport(location);
            if (tick % 10L != 0L) continue;
            display.getWorld().spawnParticle(Particle.ITEM, location, 2, 0.32, 0.25, 0.32, 0.015, (Object)this.particleItem((AltarWeapon)((Object)weapon)));
        }
        if (tick % 10L != 0L) {
            return;
        }
        HashSet<UUID> lightningViewers = new HashSet<UUID>();
        HashSet<UUID> maceViewers = new HashSet<UUID>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            ItemStack coolingMace;
            ItemStack held = player.getInventory().getItemInMainHand();
            if (this.isWeapon(held, AltarWeapon.DRILL)) {
                boolean drill = this.getDrillMode(held);
                player.sendActionBar(((TextComponent)((TextComponent)Component.text((String)"DRILL", (TextColor)NamedTextColor.DARK_GRAY).decorate(TextDecoration.BOLD)).append((Component)Component.text((String)"  |  ", (TextColor)NamedTextColor.GRAY))).append(Component.text((String)(drill ? "3\u00d73" : "1\u00d71"), (TextColor)(drill ? NamedTextColor.RED : NamedTextColor.GREEN)).decorate(TextDecoration.BOLD)));
                continue;
            }
            if (this.isWeapon(held, AltarWeapon.LIGHTNING)) {
                this.refreshCharges(held);
                lightningViewers.add(player.getUniqueId());
                this.updateLightningBossBar(player, held);
                continue;
            }
            if (this.isWeapon(held, AltarWeapon.MACE)) {
                maceViewers.add(player.getUniqueId());
                this.updateMaceBossBar(player, held);
                continue;
            }
            ItemStack recharging = this.findRechargingLightning(player);
            if (recharging != null) {
                this.refreshCharges(recharging);
                if ((Integer)recharging.getItemMeta().getPersistentDataContainer().getOrDefault(this.chargeKey, PersistentDataType.INTEGER, (Object)3) == 0) {
                    lightningViewers.add(player.getUniqueId());
                    this.updateLightningBossBar(player, recharging);
                }
            }
            if ((coolingMace = this.findCoolingMace(player)) == null) continue;
            maceViewers.add(player.getUniqueId());
            this.updateMaceBossBar(player, coolingMace);
        }
        Iterator<Map.Entry<UUID, BossBar>> bars = this.lightningBars.entrySet().iterator();
        while (bars.hasNext()) {
            Map.Entry<UUID, BossBar> entry = bars.next();
            if (lightningViewers.contains(entry.getKey())) continue;
            entry.getValue().removeAll();
            bars.remove();
        }
        Iterator<Map.Entry<UUID, BossBar>> maceBarIterator = this.maceBars.entrySet().iterator();
        while (maceBarIterator.hasNext()) {
            Map.Entry<UUID, BossBar> entry = maceBarIterator.next();
            if (maceViewers.contains(entry.getKey())) continue;
            entry.getValue().removeAll();
            maceBarIterator.remove();
        }
    }

    private ItemStack findRechargingLightning(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            int charges;
            if (!this.isWeapon(item, AltarWeapon.LIGHTNING) || (charges = ((Integer)item.getItemMeta().getPersistentDataContainer().getOrDefault(this.chargeKey, PersistentDataType.INTEGER, (Object)3)).intValue()) != 0) continue;
            return item;
        }
        return null;
    }

    private ItemStack findCoolingMace(Player player) {
        long now = System.currentTimeMillis();
        for (ItemStack item : player.getInventory().getContents()) {
            long until;
            if (!this.isWeapon(item, AltarWeapon.MACE) || (until = ((Long)item.getItemMeta().getPersistentDataContainer().getOrDefault(this.maceCooldownKey, PersistentDataType.LONG, (Object)0L)).longValue()) <= now) continue;
            return item;
        }
        return null;
    }

    private void updateLightningBossBar(Player player, ItemStack weapon) {
        ItemMeta meta = weapon.getItemMeta();
        int charges = (Integer)meta.getPersistentDataContainer().getOrDefault(this.chargeKey, PersistentDataType.INTEGER, (Object)3);
        long rechargeAt = (Long)meta.getPersistentDataContainer().getOrDefault(this.rechargeKey, PersistentDataType.LONG, (Object)0L);
        BossBar bar = this.lightningBars.computeIfAbsent(player.getUniqueId(), ignored -> {
            BossBar created = Bukkit.createBossBar((String)"", (BarColor)BarColor.YELLOW, (BarStyle)BarStyle.SEGMENTED_6, (BarFlag[])new BarFlag[0]);
            created.addPlayer(player);
            return created;
        });
        if (!bar.getPlayers().contains(player)) {
            bar.addPlayer(player);
        }
        if (charges > 0) {
            bar.setTitle(PremiumText.legacyMini("LIGHTNING BOLT", 16774307, 3526655) + PremiumText.legacyMini("   |   ", 0x555A65, 7567751) + PremiumText.legacyMini(charges + "/3 CHARGES", 0xFFFFFF, 9494527));
            bar.setProgress((double)charges / 3.0);
            bar.setColor(BarColor.YELLOW);
        } else {
            long remainingMillis = Math.max(0L, rechargeAt - System.currentTimeMillis());
            long seconds = (remainingMillis + 999L) / 1000L;
            long minutes = seconds / 60L;
            long remainder = seconds % 60L;
            bar.setTitle(PremiumText.legacyMini("LIGHTNING RECHARGING", 16765309, 15747934) + PremiumText.legacyMini("   |   ", 0x555A65, 7567751) + PremiumText.legacyMini(minutes + ":" + String.format("%02d", remainder), 0xFFFFFF, 12041416));
            bar.setProgress(Math.max(0.0, Math.min(1.0, 1.0 - (double)remainingMillis / 90000.0)));
            bar.setColor(BarColor.RED);
        }
        bar.setVisible(true);
    }

    private void updateMaceBossBar(Player player, ItemStack mace) {
        long until = (Long)mace.getItemMeta().getPersistentDataContainer().getOrDefault(this.maceCooldownKey, PersistentDataType.LONG, (Object)0L);
        long remaining = Math.max(0L, until - System.currentTimeMillis());
        BossBar bar = this.maceBars.computeIfAbsent(player.getUniqueId(), ignored -> {
            BossBar created = Bukkit.createBossBar((String)"", (BarColor)BarColor.PURPLE, (BarStyle)BarStyle.SEGMENTED_10, (BarFlag[])new BarFlag[0]);
            created.addPlayer(player);
            return created;
        });
        if (!bar.getPlayers().contains(player)) {
            bar.addPlayer(player);
        }
        if (remaining <= 0L) {
            bar.setTitle(PremiumText.legacyMini("SOVEREIGN DOMAIN", 15840767, 8271538) + PremiumText.legacyMini("   |   ", 0x555A65, 7567751) + PremiumText.legacyMini("READY", 12648389, 0x37D777));
            bar.setProgress(1.0);
            bar.setColor(BarColor.PURPLE);
        } else {
            long seconds = (remaining + 999L) / 1000L;
            bar.setTitle(PremiumText.legacyMini("SOVEREIGN DOMAIN", 15840767, 8271538) + PremiumText.legacyMini("   |   ", 0x555A65, 7567751) + PremiumText.legacyMini("REFORGING   |   " + seconds / 60L + ":" + String.format("%02d", seconds % 60L), 16756638, 14561625));
            bar.setProgress(Math.max(0.0, Math.min(1.0, 1.0 - (double)remaining / 180000.0)));
            bar.setColor(BarColor.RED);
        }
        bar.setVisible(true);
    }

    @EventHandler
    public void onAltarChunkLoad(ChunkLoadEvent event) {
        for (Entity entity : event.getChunk().getEntities()) {
            ItemDisplay display;
            if (!(entity instanceof ItemDisplay) || !"relic".equals((display = (ItemDisplay)entity).getPersistentDataContainer().get(this.altarRoleKey, PersistentDataType.STRING))) continue;
            this.altarRelics.add(display.getUniqueId());
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onMaceConsecutiveHit(EntityDamageByEntityEvent event) {
        int hits;
        Player victim;
        Player attacker;
        block5: {
            block4: {
                Entity entity = event.getDamager();
                if (!(entity instanceof Player)) break block4;
                attacker = (Player)entity;
                entity = event.getEntity();
                if (!(entity instanceof Player)) break block4;
                victim = (Player)entity;
                if (this.isWeapon(attacker.getInventory().getItemInMainHand(), AltarWeapon.MACE) && !this.plugin.isGraceActive() && !this.plugin.isDamageBlockedByTrust(victim, attacker)) break block5;
            }
            return;
        }
        long now = System.currentTimeMillis();
        MaceCombo previous = this.maceCombos.get(attacker.getUniqueId());
        int n = hits = previous != null && previous.target().equals(victim.getUniqueId()) && now - previous.lastHitAt() <= 8000L ? previous.hits() + 1 : 1;
        if (hits < 5) {
            this.maceCombos.put(attacker.getUniqueId(), new MaceCombo(victim.getUniqueId(), hits, now));
            attacker.sendActionBar(PremiumText.mini("MACE RESONANCE   |   " + hits + "/5", 15775231, 7680934));
            return;
        }
        this.maceCombos.remove(attacker.getUniqueId());
        this.stunnedUntil.put(victim.getUniqueId(), now + 3000L);
        victim.setVelocity(new Vector());
        victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 65, 9, false, true, true));
        victim.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 65, 1, false, true, true));
        victim.showTitle(Title.title((Component)PremiumText.gradient("S T U N N E D", 15909119, 6824854), (Component)PremiumText.mini("SOVEREIGN IMPACT", 0xFFFFFF, 12155094), (Title.Times)Title.Times.times((Duration)Duration.ofMillis(50L), (Duration)Duration.ofMillis(900L), (Duration)Duration.ofMillis(250L))));
        victim.getWorld().spawnParticle(Particle.ITEM, victim.getLocation().add(0.0, 1.0, 0.0), 36, 0.75, 0.95, 0.75, 0.08, (Object)this.particleItem(AltarWeapon.MACE));
        victim.getWorld().playSound(victim.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 0.75f, 1.65f);
        victim.getWorld().playSound(victim.getLocation(), Sound.BLOCK_HEAVY_CORE_PLACE, 1.0f, 0.55f);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onMaceStunnedMove(PlayerMoveEvent event) {
        if (!event.hasChangedPosition()) {
            return;
        }
        Long until = this.stunnedUntil.get(event.getPlayer().getUniqueId());
        if (until == null) {
            return;
        }
        if (until <= System.currentTimeMillis()) {
            this.stunnedUntil.remove(event.getPlayer().getUniqueId());
            return;
        }
        Location locked = event.getFrom().clone();
        locked.setYaw(event.getTo().getYaw());
        locked.setPitch(event.getTo().getPitch());
        event.setTo(locked);
        event.getPlayer().setVelocity(new Vector());
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onMaceDomainActivation(PlayerInteractEvent event) {
        if (!(event.getHand() == EquipmentSlot.HAND && event.getPlayer().isSneaking() && event.getAction().isRightClick() && this.isWeapon(event.getItem(), AltarWeapon.MACE))) {
            return;
        }
        event.setCancelled(true);
        this.activateMaceDomain(event.getPlayer(), event.getPlayer().getInventory().getItemInMainHand());
    }

    private void activateMaceDomain(Player caster, ItemStack mace) {
        BukkitTask[] task;
        if (this.plugin.isGraceActive()) {
            caster.sendMessage(Component.text((String)"HUNT ALTAR \u00bb ", (TextColor)NamedTextColor.GOLD).append((Component)Component.text((String)"The domain cannot open during grace.", (TextColor)NamedTextColor.RED)));
            return;
        }
        if (this.activeDomains.containsKey(caster.getUniqueId())) {
            return;
        }
        ItemMeta meta = mace.getItemMeta();
        long now = System.currentTimeMillis();
        long readyAt = (Long)meta.getPersistentDataContainer().getOrDefault(this.maceCooldownKey, PersistentDataType.LONG, (Object)0L);
        if (readyAt > now) {
            this.updateMaceBossBar(caster, mace);
            caster.playSound(caster.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.7f, 0.55f);
            return;
        }
        meta.getPersistentDataContainer().set(this.maceCooldownKey, PersistentDataType.LONG, (Object)(now + 180000L));
        mace.setItemMeta(meta);
        this.updateMaceBossBar(caster, mace);
        Location center = caster.getLocation().clone();
        long endsAt = now + 18000L;
        HashSet introduced = new HashSet();
        caster.showTitle(Title.title((Component)PremiumText.gradient("DOMAIN EXPANSION", 16041471, 6627470), (Component)PremiumText.mini("S O V E R E I G N   I M P A C T", 0xFFFFFF, 12089557), (Title.Times)Title.Times.times((Duration)Duration.ofMillis(150L), (Duration)Duration.ofSeconds(2L), (Duration)Duration.ofMillis(450L))));
        caster.getWorld().playSound(center, Sound.BLOCK_END_PORTAL_SPAWN, 1.2f, 0.55f);
        caster.getWorld().playSound(center, Sound.ENTITY_WITHER_SPAWN, 0.65f, 0.7f);
        caster.getWorld().playSound(center, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.9f, 0.45f);
        int[] elapsed = new int[]{0};
        task = new BukkitTask[]{Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, () -> {
            if (!caster.isOnline() || caster.isDead() || caster.getWorld() != center.getWorld() || System.currentTimeMillis() >= endsAt) {
                task[0].cancel();
                this.activeDomains.remove(caster.getUniqueId());
                if (caster.isOnline()) {
                    center.getWorld().playSound(center, Sound.BLOCK_RESPAWN_ANCHOR_DEPLETE, 1.0f, 0.65f);
                    caster.sendMessage(Component.text((String)"SOVEREIGN DOMAIN", (TextColor)NamedTextColor.DARK_PURPLE).append((Component)Component.text((String)"  \u25c6  The boundary has collapsed.", (TextColor)NamedTextColor.GRAY)));
                }
                return;
            }
            this.renderDomainBoundary(center, elapsed[0]);
            if (elapsed[0] % 10 == 0) {
                if (caster.getLocation().distanceSquared(center) <= 144.0) {
                    caster.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 30, 1, false, true, true));
                    caster.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30, 1, false, true, true));
                    caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 30, 0, false, true, true));
                    caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 30, 0, false, true, true));
                }
                for (Player target : center.getWorld().getPlayers()) {
                    if (target.equals((Object)caster) || target.getLocation().distanceSquared(center) > 144.0 || this.plugin.isDamageBlockedByTrust(target, caster)) continue;
                    target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 30, 1, false, true, true));
                    target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 30, 1, false, true, true));
                    target.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 30, 0, false, false, true));
                    target.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 30, 0, false, false, true));
                    if (!introduced.add(target.getUniqueId())) continue;
                    target.showTitle(Title.title((Component)PremiumText.gradient("DOMAIN EXPANSION", 16041471, 6627470), (Component)PremiumText.mini("S O V E R E I G N   I M P A C T", 0xFFB0B0, 0xB52B5B), (Title.Times)Title.Times.times((Duration)Duration.ofMillis(100L), (Duration)Duration.ofSeconds(1L), (Duration)Duration.ofMillis(300L))));
                    target.playSound(target.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, 0.85f, 0.6f);
                }
            }
            if (elapsed[0] % 40 == 0) {
                center.getWorld().playSound(center, Sound.ENTITY_WARDEN_HEARTBEAT, 1.2f, 0.55f);
                center.getWorld().playSound(center, Sound.BLOCK_SCULK_SHRIEKER_SHRIEK, 0.45f, 0.8f);
            }
            elapsed[0] = elapsed[0] + 2;
        }, 0L, 2L)};
        this.activeDomains.put(caster.getUniqueId(), task[0]);
    }

    private void renderDomainBoundary(Location center, int elapsed) {
        double angle;
        int index;
        for (index = 0; index < 24; ++index) {
            angle = Math.PI * 2 * (double)index / 24.0 + (double)elapsed * 0.025;
            double x = Math.cos(angle) * 12.0;
            double z = Math.sin(angle) * 12.0;
            double y = 0.25 + (double)((index + elapsed / 2) % 8) * 0.48;
            center.getWorld().spawnParticle(Particle.ITEM, center.clone().add(x, y, z), 1, 0.0, 0.0, 0.0, 0.0, (Object)this.particleItem(AltarWeapon.MACE));
            if (index % 3 != 0) continue;
            center.getWorld().spawnParticle(Particle.SCULK_SOUL, center.clone().add(x, 0.4, z), 1, 0.05, 0.2, 0.05, 0.01);
        }
        for (index = 0; index < 8; ++index) {
            angle = (double)elapsed * 0.05 + (double)index * Math.PI / 4.0;
            center.getWorld().spawnParticle(Particle.ITEM, center.clone().add(Math.cos(angle) * 4.5, 0.3 + (double)index * 0.3, Math.sin(angle) * 4.5), 1, 0.0, 0.0, 0.0, 0.0, (Object)this.particleItem(AltarWeapon.MACE));
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onDrillToggle(PlayerInteractEvent event) {
        if (!(event.getHand() == EquipmentSlot.HAND && event.getPlayer().isSneaking() && event.getAction().isRightClick() && this.isWeapon(event.getItem(), AltarWeapon.DRILL))) {
            return;
        }
        event.setCancelled(true);
        ItemStack drill = event.getPlayer().getInventory().getItemInMainHand();
        ItemMeta meta = drill.getItemMeta();
        boolean next = !this.getDrillMode(drill);
        meta.getPersistentDataContainer().set(this.drillModeKey, PersistentDataType.BYTE, (Object)((byte)(next ? 1 : 0)));
        meta.lore(this.drillLore(next));
        drill.setItemMeta(meta);
        event.getPlayer().sendActionBar(Component.text((String)(next ? "3\u00d73 DRILL MODE" : "1\u00d71 PRECISION MODE"), (TextColor)(next ? NamedTextColor.RED : NamedTextColor.GREEN)).decorate(TextDecoration.BOLD));
        event.getPlayer().playSound(event.getPlayer().getLocation(), Sound.BLOCK_PISTON_EXTEND, 0.75f, next ? 0.7f : 1.35f);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onLightningThrowAttempt(PlayerInteractEvent event) {
        if (!event.getAction().isRightClick() || !this.isWeapon(event.getItem(), AltarWeapon.LIGHTNING)) {
            return;
        }
        event.setCancelled(true);
        this.updateLightningBossBar(event.getPlayer(), event.getItem());
        event.getPlayer().playSound(event.getPlayer().getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.45f, 1.45f);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onLightningProjectileLaunch(ProjectileLaunchEvent event) {
        Trident trident;
        Projectile projectile = event.getEntity();
        if (!(projectile instanceof Trident) || !((trident = (Trident)projectile).getShooter() instanceof Player)) {
            return;
        }
        if (this.isWeapon(trident.getItemStack(), AltarWeapon.LIGHTNING)) {
            event.setCancelled(true);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onDrillBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!this.isWeapon(tool, AltarWeapon.DRILL) || !this.getDrillMode(tool) || this.drillBreaking.contains(player.getUniqueId())) {
            return;
        }
        this.drillBreaking.add(player.getUniqueId());
        try {
            for (Block block : this.drillPlane(event.getBlock(), player)) {
                if (block.equals((Object)event.getBlock()) || !this.canDrill(block)) continue;
                BlockBreakEvent extra = new BlockBreakEvent(block, player);
                Bukkit.getPluginManager().callEvent((Event)extra);
                if (extra.isCancelled()) continue;
                block.breakNaturally(tool);
            }
            player.getWorld().spawnParticle(Particle.ITEM, event.getBlock().getLocation().add(0.5, 0.5, 0.5), 18, 1.1, 1.1, 1.1, 0.06, (Object)this.particleItem(AltarWeapon.DRILL));
            player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.28f, 1.8f);
        }
        finally {
            this.drillBreaking.remove(player.getUniqueId());
        }
    }

    private List<Block> drillPlane(Block center, Player player) {
        ArrayList<Block> blocks = new ArrayList<Block>(9);
        Vector direction = player.getEyeLocation().getDirection();
        for (int first = -1; first <= 1; ++first) {
            for (int second = -1; second <= 1; ++second) {
                if (Math.abs(direction.getY()) > 0.65) {
                    blocks.add(center.getRelative(first, 0, second));
                    continue;
                }
                if (Math.abs(direction.getX()) > Math.abs(direction.getZ())) {
                    blocks.add(center.getRelative(0, first, second));
                    continue;
                }
                blocks.add(center.getRelative(first, second, 0));
            }
        }
        return blocks;
    }

    private boolean canDrill(Block block) {
        Material material = block.getType();
        return !material.isAir() && material.isBlock() && material.getHardness() >= 0.0f && !List.of(Material.BARRIER, Material.STRUCTURE_BLOCK, Material.JIGSAW, Material.END_PORTAL_FRAME, Material.END_PORTAL, Material.NETHER_PORTAL, Material.REINFORCED_DEEPSLATE).contains(material) && !(block.getState() instanceof Container);
    }

    private void fireLightning(Player player, ItemStack weapon) {
        this.refreshCharges(weapon);
        ItemMeta meta = weapon.getItemMeta();
        int charges = (Integer)meta.getPersistentDataContainer().getOrDefault(this.chargeKey, PersistentDataType.INTEGER, (Object)3);
        if (charges <= 0) {
            this.updateLightningBossBar(player, weapon);
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.7f, 0.65f);
            return;
        }
        meta.getPersistentDataContainer().set(this.chargeKey, PersistentDataType.INTEGER, (Object)(--charges));
        if (charges == 0) {
            meta.getPersistentDataContainer().set(this.rechargeKey, PersistentDataType.LONG, (Object)(System.currentTimeMillis() + 90000L));
        }
        meta.lore(this.lightningLore(charges));
        weapon.setItemMeta(meta);
        this.updateLightningBossBar(player, weapon);
        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection().normalize();
        RayTraceResult entityHit = player.getWorld().rayTraceEntities(eye, direction, 42.0, 0.7, entity -> {
            Player target;
            return entity instanceof Player && !(target = (Player)entity).equals((Object)player) && !target.isDead() && player.canSee(target);
        });
        RayTraceResult blockHit = player.getWorld().rayTraceBlocks(eye, direction, 42.0);
        double distance = 42.0;
        Player target = null;
        if (blockHit != null) {
            distance = eye.toVector().distance(blockHit.getHitPosition());
        }
        if (entityHit != null && eye.toVector().distance(entityHit.getHitPosition()) <= distance) {
            distance = eye.toVector().distance(entityHit.getHitPosition());
            Entity entity2 = entityHit.getHitEntity();
            if (entity2 instanceof Player) {
                Player hit;
                target = hit = (Player)entity2;
            }
        }
        for (double step = 0.4; step <= distance; step += 0.45) {
            player.getWorld().spawnParticle(Particle.DUST, eye.clone().add(direction.clone().multiply(step)), 1, 0.0, 0.0, 0.0, 0.0, (Object)LIGHTNING_TRAIL_DUST);
        }
        Location impact = eye.clone().add(direction.multiply(distance));
        player.getWorld().strikeLightningEffect(impact);
        player.getWorld().spawnParticle(Particle.ITEM, impact, 35, 0.8, 1.0, 0.8, 0.12, (Object)this.particleItem(AltarWeapon.LIGHTNING));
        player.getWorld().playSound(impact, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.9f, 1.45f);
        if (!this.plugin.isGraceActive()) {
            HashSet<Player> victims = new HashSet<Player>();
            if (target != null) {
                victims.add(target);
            }
            for (Entity nearby : player.getWorld().getNearbyEntities(impact, 3.0, 3.0, 3.0)) {
                Player nearbyPlayer;
                if (!(nearby instanceof Player) || (nearbyPlayer = (Player)nearby).equals((Object)player) || !(nearbyPlayer.getLocation().distanceSquared(impact) <= 9.0)) continue;
                victims.add(nearbyPlayer);
            }
            for (Player victim : victims) {
                this.plugin.dealHuntDamage(player, victim, 10.0, DamageType.LIGHTNING_BOLT);
            }
        }
    }

    private void refreshCharges(ItemStack item) {
        if (!this.isWeapon(item, AltarWeapon.LIGHTNING)) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        int charges = (Integer)meta.getPersistentDataContainer().getOrDefault(this.chargeKey, PersistentDataType.INTEGER, (Object)3);
        long rechargeAt = (Long)meta.getPersistentDataContainer().getOrDefault(this.rechargeKey, PersistentDataType.LONG, (Object)0L);
        if (charges == 0 && rechargeAt > 0L && rechargeAt <= System.currentTimeMillis()) {
            meta.getPersistentDataContainer().set(this.chargeKey, PersistentDataType.INTEGER, (Object)3);
            meta.getPersistentDataContainer().remove(this.rechargeKey);
            meta.lore(this.lightningLore(3));
            item.setItemMeta(meta);
        }
    }

    private boolean getDrillMode(ItemStack item) {
        return item != null && item.hasItemMeta() && (Byte)item.getItemMeta().getPersistentDataContainer().getOrDefault(this.drillModeKey, PersistentDataType.BYTE, (Object)1) == 1;
    }

    private boolean isWeapon(ItemStack item, AltarWeapon weapon) {
        return item != null && item.hasItemMeta() && weapon.id.equals(item.getItemMeta().getPersistentDataContainer().get(this.weaponKey, PersistentDataType.STRING));
    }

    private ItemStack createWeapon(AltarWeapon weapon) {
        ItemStack item = new ItemStack(weapon.material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(this.weaponItemName(weapon));
        meta.setItemModel(new NamespacedKey("hunt", weapon.model));
        meta.getPersistentDataContainer().set(this.weaponKey, PersistentDataType.STRING, (Object)weapon.id);
        meta.setEnchantmentGlintOverride(Boolean.valueOf(true));
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_UNBREAKABLE});
        if (weapon == AltarWeapon.DRILL) {
            meta.addEnchant(Enchantment.EFFICIENCY, 5, true);
            meta.addEnchant(Enchantment.UNBREAKING, 3, true);
            meta.addEnchant(Enchantment.MENDING, 1, true);
            meta.addEnchant(Enchantment.SILK_TOUCH, 1, true);
            meta.getPersistentDataContainer().set(this.drillModeKey, PersistentDataType.BYTE, (Object)1);
            meta.lore(this.drillLore(true));
        } else if (weapon == AltarWeapon.LIGHTNING) {
            meta.getPersistentDataContainer().set(this.chargeKey, PersistentDataType.INTEGER, (Object)3);
            meta.lore(this.lightningLore(3));
        } else {
            meta.getPersistentDataContainer().set(this.maceCooldownKey, PersistentDataType.LONG, (Object)0L);
            meta.lore(this.maceLore());
        }
        item.setItemMeta(meta);
        return item;
    }

    private List<Component> drillLore(boolean drillMode) {
        return List.of(PremiumText.mini("EXCAVATION INSTRUMENT", 0xAA86A8, 0x554452), Component.empty(), PremiumText.mini("SNEAK + RIGHT CLICK  |  SWITCH ARRAY", 16765677, 10769569), PremiumText.mini("ACTIVE ARRAY         |  " + (drillMode ? "3x3 DEMOLITION" : "1x1 PRECISION"), drillMode ? 0xFF9A9A : 12058562, drillMode ? 12922703 : 3713122), Component.empty(), PremiumText.mini("SILK TOUCH           |  CALIBRATED", 15593718, 9673384), PremiumText.mini("EFFICIENCY V         |  OVERDRIVEN", 15593718, 9673384), PremiumText.mini("UNBREAKING III       |  MENDING", 15593718, 9673384));
    }

    private Component weaponItemName(AltarWeapon weapon) {
        if (weapon == AltarWeapon.MACE) {
            return PremiumText.gradient("SOVEREIGN", this.relicStart(weapon), this.relicEnd(weapon)).decorate(TextDecoration.BOLD);
        }
        return PremiumText.gradient(weapon.displayName.toUpperCase() + "   |   HUNT RELIC", this.relicStart(weapon), this.relicEnd(weapon));
    }

    private List<Component> lightningLore(int charges) {
        String meter = "[" + "I".repeat(Math.max(0, charges)) + "-".repeat(Math.max(0, 3 - charges)) + "]";
        return List.of(PremiumText.mini("ATMOSPHERIC WEAPON", 11773557, 5656637), Component.empty(), PremiumText.mini("SNEAK + F       |  DISCHARGE BOLT", 16773793, 3521771), PremiumText.mini("IMPACT DAMAGE   |  05 HEARTS", 16773536, 15043372), PremiumText.mini("IMPACT RADIUS   |  03 BLOCKS", 15399935, 5812171), PremiumText.mini("CHARGE ARRAY    |  " + meter + "  " + charges + "/3", 0xCFFBFF, 3775691), PremiumText.mini("FULL RECOVERY   |  01:30", 15593718, 9673384), Component.empty(), PremiumText.mini("THROW PROTOCOL  |  PERMANENTLY SEALED", 16755357, 12664149));
    }

    private List<Component> maceLore() {
        return List.of(PremiumText.mini("SOVEREIGN CLASS WEAPON", 11111346, 5260119), Component.empty(), PremiumText.mini("FIFTH IMPACT         |  SOVEREIGN STUN 00:03", 15316223, 8468404), PremiumText.mini("SNEAK + RIGHT CLICK  |  EXPAND DOMAIN", 16770464, 12417323), PremiumText.mini("DOMAIN WINDOW        |  00:18", 15264497, 9607591), PremiumText.mini("REFORGING CYCLE      |  03:00", 16755357, 12664149), Component.empty(), PremiumText.mini("EVERY BOUNDARY YIELDS TO ITS WIELDER", 14271967, 7955839));
    }

    private ItemStack modelItem(Material material, String model) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setItemModel(new NamespacedKey("hunt", model));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack particleItem(AltarWeapon weapon) {
        return this.modelItem(Material.PAPER, weapon.particleModel);
    }

    private void registerRecipes() {
        Bukkit.removeRecipe((NamespacedKey)this.drillRecipeKey);
        ShapedRecipe drill = new ShapedRecipe(this.drillRecipeKey, this.createWeapon(AltarWeapon.DRILL));
        drill.shape(new String[]{"BHB", "EPE", "BNB"});
        drill.setIngredient('B', Material.NETHERITE_BLOCK);
        drill.setIngredient('H', Material.HEAVY_CORE);
        drill.setIngredient('E', Material.ECHO_SHARD);
        drill.setIngredient('P', Material.NETHERITE_PICKAXE);
        drill.setIngredient('N', Material.NETHER_STAR);
        Bukkit.addRecipe((Recipe)drill);
        Bukkit.removeRecipe((NamespacedKey)this.lightningRecipeKey);
        ShapedRecipe lightning = new ShapedRecipe(this.lightningRecipeKey, this.createWeapon(AltarWeapon.LIGHTNING));
        lightning.shape(new String[]{"DHD", "ENE", "DTD"});
        lightning.setIngredient('D', Material.DIAMOND_BLOCK);
        lightning.setIngredient('H', Material.HEAVY_CORE);
        lightning.setIngredient('E', Material.ECHO_SHARD);
        lightning.setIngredient('N', Material.NETHER_STAR);
        lightning.setIngredient('T', Material.TRIDENT);
        Bukkit.addRecipe((Recipe)lightning);
        Bukkit.removeRecipe((NamespacedKey)this.maceRecipeKey);
        ShapedRecipe mace = new ShapedRecipe(this.maceRecipeKey, this.createWeapon(AltarWeapon.MACE));
        mace.shape(new String[]{"BHB", "EAE", "BNB"});
        mace.setIngredient('B', Material.NETHERITE_BLOCK);
        mace.setIngredient('H', Material.HEAVY_CORE);
        mace.setIngredient('E', Material.ECHO_SHARD);
        mace.setIngredient('A', Material.NETHERITE_AXE);
        mace.setIngredient('N', Material.NETHER_STAR);
        Bukkit.addRecipe((Recipe)mace);
    }

    private boolean canFireLightningNow(Player player, ItemStack itemStack, AltarWeapon altarWeapon) {
        return (this.isWeapon(itemStack, altarWeapon) & (Integer.signum(player.getCooldown(itemStack.getType())) ^ 1)) != 0;
    }

    private static enum AltarWeapon {
        DRILL("drill", "Drill Pickaxe", NamedTextColor.LIGHT_PURPLE, Material.NETHERITE_PICKAXE, "drill_pickaxe", "drill_particle"),
        MACE("mace", "Sovereign Mace", NamedTextColor.DARK_PURPLE, Material.MACE, "domain_mace", "domain_particle"),
        LIGHTNING("lightning", "Lightning Bolt", NamedTextColor.YELLOW, Material.TRIDENT, "lightning_bolt", "lightning_particle");

        private final String id;
        private final String displayName;
        private final NamedTextColor color;
        private final Material material;
        private final String model;
        private final String particleModel;

        private AltarWeapon(String id, String displayName, NamedTextColor color, Material material, String model, String particleModel) {
            this.id = id;
            this.displayName = displayName;
            this.color = color;
            this.material = material;
            this.model = model;
            this.particleModel = particleModel;
        }

        static AltarWeapon parse(String value) {
            if (value == null) {
                return null;
            }
            if (value.equalsIgnoreCase("drill") || value.equalsIgnoreCase("drill_pickaxe")) {
                return DRILL;
            }
            if (value.equalsIgnoreCase("mace") || value.equalsIgnoreCase("sovereign_mace")) {
                return MACE;
            }
            if (value.equalsIgnoreCase("lightning") || value.equalsIgnoreCase("lightning_bolt") || value.equalsIgnoreCase("spear")) {
                return LIGHTNING;
            }
            return null;
        }
    }

    private static enum SelectionAction {
        GIVE,
        SPAWN;

    }

    private static final class AltarSelector
    implements InventoryHolder {
        private final SelectionAction action;
        private Inventory inventory;

        private AltarSelector(SelectionAction action) {
            this.action = action;
        }

        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private record MaceCombo(UUID target, int hits, long lastHitAt) {
    }
}

