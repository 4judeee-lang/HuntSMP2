package me.judee.huntsmp;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

/**
 * Runtime feature module for the Divine Spear.
 *
 * The item is identified by PDC instead of its display name, preventing renamed
 * vanilla items from gaining abilities. All state is UUID-based and cleaned on quit.
 */
public final class DivineSpearFeature implements Listener, CommandExecutor {
    private static final long DOUBLE_JUMP_COOLDOWN_MS = 1_000L;
    private static final long STUN_DURATION_MS = 3_000L;
    private static final long STUN_IMMUNITY_MS = 1_000L; // grace window after a stun ends before another can land
    private static final long SATURATION_PROTECTION_MS = 1_500L;
    private static final long FALLBACK_LUNGE_COOLDOWN_MS = 750L;
    private static final double STUN_CHANCE = 0.60D;

    private static final MiniMessage MINI = MiniMessage.miniMessage();
    private static final Particle.DustOptions DIVINE_DUST =
            new Particle.DustOptions(Color.fromRGB(255, 210, 52), 1.35F);

    private final Plugin plugin;
    private final NamespacedKey spearKey;
    private final Material spearMaterial;

    private final Map<UUID, Long> stunnedUntil = new HashMap<>();
    private final Map<UUID, Long> stunImmuneUntil = new HashMap<>();
    private final Map<UUID, Long> jumpCooldownUntil = new HashMap<>();
    private final Map<UUID, Long> saturationProtectedUntil = new HashMap<>();
    private final Map<UUID, Float> saturationFloor = new HashMap<>();
    private final Map<UUID, Integer> foodLevelFloor = new HashMap<>();
    private final Map<UUID, Long> fallbackLungeCooldownUntil = new HashMap<>();
    private final Set<UUID> jumpUsedSinceGround = new HashSet<>();
    private final Set<UUID> managedFlight = new HashSet<>();

    private BukkitTask ticker;

    private DivineSpearFeature(Plugin plugin) {
        this.plugin = plugin;
        this.spearKey = new NamespacedKey(plugin, "divine_spear");

        Material detected = Material.matchMaterial("SPEAR");
        if (detected == null) {
            detected = Material.matchMaterial("TRIDENT");
        }
        if (detected == null) {
            throw new IllegalStateException("Neither SPEAR nor TRIDENT exists on this server build.");
        }
        this.spearMaterial = detected;
    }

    public static void register(Plugin plugin) {
        DivineSpearFeature feature = new DivineSpearFeature(plugin);
        Bukkit.getPluginManager().registerEvents(feature, plugin);

        if (plugin instanceof JavaPlugin javaPlugin) {
            PluginCommand command = javaPlugin.getCommand("divinespear");
            if (command != null) {
                command.setExecutor(feature);
            } else {
                plugin.getLogger().warning("The /divinespear command is missing from plugin.yml.");
            }
        }

        feature.ticker = Bukkit.getScheduler().runTaskTimer(plugin, feature::tick, 1L, 1L);
        plugin.getLogger().info("Divine Spear loaded: Sunbreak model, 60% three-second stun, saturation-free lunge, and grounded double jump.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("divinespear")) {
            return false;
        }
        if (!sender.hasPermission("hunt.admin")) {
            sender.sendMessage("§cYou do not have permission to use this command.");
            return true;
        }

        Player target;
        if (args.length >= 1) {
            target = plugin.getServer().getPlayer(args[0]);
            if (target == null) {
                sender.sendMessage("§cThat player is not online.");
                return true;
            }
        } else if (sender instanceof Player player) {
            target = player;
        } else {
            sender.sendMessage("§cUsage: /divinespear <player>");
            return true;
        }

        ItemStack spear = createSpear();
        Map<Integer, ItemStack> leftover = target.getInventory().addItem(spear);
        if (!leftover.isEmpty()) {
            for (ItemStack item : leftover.values()) {
                target.getWorld().dropItemNaturally(target.getLocation(), item);
            }
        }

        target.sendMessage("§8[§6Divine Spear§8] §fThe heavens have answered.");
        sender.sendMessage("§aGave §fDivine Spear §ato §f" + target.getName() + "§a.");
        play(target, "BLOCK_BEACON_ACTIVATE", 0.9F, 1.7F);
        spawnDivineBurst(target.getLocation().add(0.0D, 1.0D, 0.0D), 34);
        return true;
    }

    private ItemStack createSpear() {
        ItemStack item = new ItemStack(spearMaterial);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        meta.displayName(mm("<italic:false><bold><gradient:#FFFDF3:#FFD43B:#FFFFFF>Divine Spear</gradient></bold>"));

        List<Component> lore = new ArrayList<>();
        lore.add(mm("<italic:false><dark_gray>✦ Celestial Relic ✦</dark_gray>"));
        lore.add(mm("<italic:false><gray>Forged from light beyond the mortal realm.</gray>"));
        lore.add(mm(""));
        lore.add(mm("<italic:false><gold><bold>PASSIVE</bold></gold> <dark_gray>•</dark_gray> <white>Sanctified Lunge</white>"));
        lore.add(mm("<italic:false><gray>Lunging consumes <yellow>no saturation</yellow>.</gray>"));
        lore.add(mm(""));
        lore.add(mm("<italic:false><gold><bold>ABILITY I</bold></gold> <dark_gray>•</dark_gray> <white>Divine Judgment</white>"));
        lore.add(mm("<italic:false><gray>Melee hits have a <yellow>60%</yellow> chance to stun</gray>"));
        lore.add(mm("<italic:false><gray>the victim for <white>3 seconds</white>.</gray>"));
        lore.add(mm(""));
        lore.add(mm("<italic:false><gold><bold>PASSIVE</bold></gold> <dark_gray>•</dark_gray> <white>Heavenbound</white>"));
        lore.add(mm("<italic:false><gray>Keep the spear in your hotbar to double jump.</gray>"));
        lore.add(mm("<italic:false><dark_gray>Resets after touching the ground • 1s cooldown</dark_gray>"));
        meta.lore(lore);

        meta.setItemModel(new NamespacedKey("hunt", "divine_spear"));
        meta.getPersistentDataContainer().set(spearKey, PersistentDataType.BYTE, (byte) 1);
        meta.setUnbreakable(true);
        meta.addItemFlags(
                ItemFlag.HIDE_ATTRIBUTES,
                ItemFlag.HIDE_ENCHANTS,
                ItemFlag.HIDE_UNBREAKABLE
        );

        tryAddLungeEnchant(meta);
        item.setItemMeta(meta);
        return item;
    }

    private static Component mm(String input) {
        return MINI.deserialize(input);
    }

    /** Adds the native Lunge enchant when it exists, without hard-linking to a specific API revision. */
    private static void tryAddLungeEnchant(ItemMeta meta) {
        try {
            Class<?> registryType = Class.forName("org.bukkit.Registry");
            Field enchantmentField = registryType.getField("ENCHANTMENT");
            Object registry = enchantmentField.get(null);
            Method get = registry.getClass().getMethod("get", NamespacedKey.class);
            Object lunge = get.invoke(registry, NamespacedKey.minecraft("lunge"));
            if (lunge == null) {
                return;
            }

            Class<?> enchantmentType = Class.forName("org.bukkit.enchantments.Enchantment");
            Method addEnchant = meta.getClass().getMethod("addEnchant", enchantmentType, int.class, boolean.class);
            addEnchant.invoke(meta, lunge, 1, true);
        } catch (ReflectiveOperationException ignored) {
            // Older API: fallback lunge is provided by onSpearUse.
        }
    }

    private boolean isDivineSpear(ItemStack item) {
        if (item == null || item.getType() != spearMaterial) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.getPersistentDataContainer().has(spearKey, PersistentDataType.BYTE);
    }

    private boolean hasSpearInHotbar(Player player) {
        PlayerInventory inventory = player.getInventory();
        for (int slot = 0; slot < 9; slot++) {
            if (isDivineSpear(inventory.getItem(slot))) {
                return true;
            }
        }
        return false;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpearHit(EntityDamageByEntityEvent event) {
        Entity damagerEntity = event.getDamager();
        if (damagerEntity instanceof Player stunnedAttacker && isStunned(stunnedAttacker)) {
            event.setCancelled(true);
            return;
        }

        if (!(damagerEntity instanceof Player attacker)) {
            return;
        }
        if (!(event.getEntity() instanceof Player victim)) {
            return;
        }
        if (!isDivineSpear(attacker.getInventory().getItemInMainHand())) {
            return;
        }

        // Without this guard, consecutive hits on an already-stunned (and therefore
        // easy-to-hit) victim could keep re-rolling and refreshing the stun, chaining
        // into an unbreakable lock. A stunned or recently-stunned victim can't be
        // re-stunned until the immunity window passes.
        if (isStunned(victim) || isStunImmune(victim)) {
            spawnDivineSparks(victim.getLocation().add(0.0D, 1.0D, 0.0D), 8);
            return;
        }

        if (ThreadLocalRandom.current().nextDouble() >= STUN_CHANCE) {
            spawnDivineSparks(victim.getLocation().add(0.0D, 1.0D, 0.0D), 8);
            return;
        }

        applyStun(attacker, victim);
    }

    private boolean isStunImmune(Player player) {
        Long until = stunImmuneUntil.get(player.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    private void clearStun(UUID id) {
        if (stunnedUntil.remove(id) != null) {
            stunImmuneUntil.put(id, System.currentTimeMillis() + STUN_IMMUNITY_MS);
        }
    }

    private void applyStun(Player attacker, Player victim) {
        long endsAt = System.currentTimeMillis() + STUN_DURATION_MS;
        stunnedUntil.put(victim.getUniqueId(), endsAt);

        victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 10, false, false, false));
        victim.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 4, false, false, false));
        victim.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 60, 4, false, false, false));

        victim.sendTitle("§6§lSTUNNED", "§fDivine Judgment", 2, 42, 8);
        attacker.sendActionBar(mm("<italic:false><gradient:#FFFDF3:#FFD43B><bold>DIVINE JUDGMENT</bold></gradient> <gray>•</gray> <white>Target stunned for 3.0s</white>"));

        Location centre = victim.getLocation().add(0.0D, 1.0D, 0.0D);
        spawnDivineBurst(centre, 48);
        play(victim, "BLOCK_BEACON_POWER_SELECT", 1.0F, 1.65F);
        play(victim, "BLOCK_AMETHYST_BLOCK_RESONATE", 0.8F, 1.9F);
        play(attacker, "ENTITY_PLAYER_ATTACK_CRIT", 0.8F, 1.35F);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpearUse(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (isStunned(player)) {
            event.setCancelled(true);
            return;
        }

        Action action = event.getAction();
        if (action == null || !action.isRightClick() || !isDivineSpear(event.getItem())) {
            return;
        }

        UUID id = player.getUniqueId();
        long now = System.currentTimeMillis();
        saturationFloor.put(id, player.getSaturation());
        // If saturation is already near 0 (the common case), vanilla exhaustion drains
        // food level instead. Pin food level too, or "no saturation cost" quietly still
        // costs the player food whenever they lunge on empty saturation.
        foodLevelFloor.put(id, player.getFoodLevel());
        saturationProtectedUntil.put(id, now + SATURATION_PROTECTION_MS);

        // Newer servers perform native spear Lunge. TRIDENT fallback emulates the same movement.
        if (!"SPEAR".equalsIgnoreCase(spearMaterial.name())) {
            long readyAt = fallbackLungeCooldownUntil.getOrDefault(id, 0L);
            if (readyAt > now) {
                return;
            }
            fallbackLungeCooldownUntil.put(id, now + FALLBACK_LUNGE_COOLDOWN_MS);
            event.setCancelled(true);

            Vector direction = player.getLocation().getDirection().normalize().multiply(1.28D);
            direction.setY(Math.max(0.18D, direction.getY() * 0.35D + 0.18D));
            player.setVelocity(direction);
            spawnDivineSparks(player.getLocation().add(0.0D, 0.75D, 0.0D), 22);
            play(player, "ITEM_TRIDENT_RIPTIDE_1", 0.75F, 1.45F);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDoubleJump(PlayerToggleFlightEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();

        if (!managedFlight.contains(id)) {
            return;
        }
        if (isStunned(player)) {
            event.setCancelled(true);
            player.setFlying(false);
            return;
        }
        if (isCreativeFlight(player) || !hasSpearInHotbar(player) || player.isOnGround()) {
            return;
        }

        long now = System.currentTimeMillis();
        if (jumpUsedSinceGround.contains(id) || jumpCooldownUntil.getOrDefault(id, 0L) > now) {
            event.setCancelled(true);
            player.setFlying(false);
            player.setAllowFlight(false);
            return;
        }

        event.setCancelled(true);
        player.setFlying(false);
        player.setAllowFlight(false);
        jumpUsedSinceGround.add(id);
        jumpCooldownUntil.put(id, now + DOUBLE_JUMP_COOLDOWN_MS);

        Vector leap = player.getLocation().getDirection().normalize().multiply(0.42D);
        leap.setY(0.88D);
        player.setVelocity(leap);

        Location feet = player.getLocation().add(0.0D, 0.15D, 0.0D);
        spawnDivineBurst(feet, 26);
        play(player, "BLOCK_AMETHYST_BLOCK_CHIME", 0.85F, 1.8F);
        play(player, "ENTITY_FIREWORK_ROCKET_LAUNCH", 0.55F, 1.6F);
        player.sendActionBar(mm("<italic:false><gradient:#FFFFFF:#FFD43B><bold>HEAVENBOUND</bold></gradient>"));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onStunnedMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!isStunned(player) || event.getTo() == null) {
            return;
        }

        Location from = event.getFrom();
        Location to = event.getTo();
        if (from.getX() == to.getX() && from.getY() == to.getY() && from.getZ() == to.getZ()) {
            return;
        }

        Location locked = from.clone();
        locked.setYaw(to.getYaw());
        locked.setPitch(to.getPitch());
        event.setTo(locked);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        restoreManagedFlight(event.getPlayer());
        stunnedUntil.remove(id);
        stunImmuneUntil.remove(id);
        jumpCooldownUntil.remove(id);
        saturationProtectedUntil.remove(id);
        saturationFloor.remove(id);
        foodLevelFloor.remove(id);
        fallbackLungeCooldownUntil.remove(id);
        jumpUsedSinceGround.remove(id);
    }

    private void tick() {
        long now = System.currentTimeMillis();
        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID id = player.getUniqueId();

            Long protectedUntil = saturationProtectedUntil.get(id);
            if (protectedUntil != null) {
                if (protectedUntil > now) {
                    float floor = saturationFloor.getOrDefault(id, player.getSaturation());
                    if (player.getSaturation() < floor) {
                        player.setSaturation(floor);
                    }
                    Integer foodFloor = foodLevelFloor.get(id);
                    if (foodFloor != null && player.getFoodLevel() < foodFloor) {
                        player.setFoodLevel(foodFloor);
                    }
                } else {
                    saturationProtectedUntil.remove(id);
                    saturationFloor.remove(id);
                    foodLevelFloor.remove(id);
                }
            }

            Long stunEnd = stunnedUntil.get(id);
            if (stunEnd != null && stunEnd <= now) {
                clearStun(id);
                player.sendActionBar(mm("<italic:false><gray>Divine stun ended.</gray>"));
            }

            if (isCreativeFlight(player) || !hasSpearInHotbar(player)) {
                restoreManagedFlight(player);
                jumpUsedSinceGround.remove(id);
                continue;
            }

            if (player.isOnGround()) {
                jumpUsedSinceGround.remove(id);
            }

            if (!jumpUsedSinceGround.contains(id)
                    && jumpCooldownUntil.getOrDefault(id, 0L) <= now
                    && !player.isFlying()) {
                if (!player.getAllowFlight()) {
                    player.setAllowFlight(true);
                    managedFlight.add(id);
                }
            }
        }
    }

    private boolean isCreativeFlight(Player player) {
        GameMode mode = player.getGameMode();
        return mode == GameMode.CREATIVE || mode == GameMode.SPECTATOR;
    }

    private void restoreManagedFlight(Player player) {
        UUID id = player.getUniqueId();
        if (managedFlight.remove(id) && !isCreativeFlight(player) && !player.isFlying()) {
            player.setAllowFlight(false);
        }
    }

    private boolean isStunned(Player player) {
        Long until = stunnedUntil.get(player.getUniqueId());
        if (until == null) {
            return false;
        }
        if (until <= System.currentTimeMillis()) {
            clearStun(player.getUniqueId());
            return false;
        }
        return true;
    }

    private static void spawnDivineBurst(Location location, int count) {
        World world = location.getWorld();
        if (world == null) {
            return;
        }
        world.spawnParticle(Particle.DUST, location, count, 0.55D, 0.8D, 0.55D, 0.02D, DIVINE_DUST);
        world.spawnParticle(Particle.END_ROD, location, Math.max(4, count / 5), 0.45D, 0.65D, 0.45D, 0.035D);
        world.spawnParticle(Particle.FIREWORK, location, Math.max(3, count / 7), 0.38D, 0.55D, 0.38D, 0.02D);
    }

    private static void spawnDivineSparks(Location location, int count) {
        World world = location.getWorld();
        if (world == null) {
            return;
        }
        world.spawnParticle(Particle.DUST, location, count, 0.38D, 0.45D, 0.38D, 0.01D, DIVINE_DUST);
        world.spawnParticle(Particle.END_ROD, location, Math.max(2, count / 6), 0.25D, 0.3D, 0.25D, 0.02D);
    }

    private static void play(Player player, String soundName, float volume, float pitch) {
        try {
            player.playSound(player.getLocation(), Sound.valueOf(soundName), volume, pitch);
        } catch (IllegalArgumentException ignored) {
            // Sound names can differ slightly between minor server revisions.
        }
    }
}
