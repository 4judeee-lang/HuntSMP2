/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntsmp;

import net.kyori.adventure.text.format.NamedTextColor;

enum HuntAbility {
    BLOODLORD("bloodlord", "Bloodlord", "\ue200", "MYTHIC", NamedTextColor.DARK_RED, 3, 100, 50, "Blood Tether", "Steal two maximum hearts for thirty seconds.", "Crimson Rupture", "Burst nearby enemies and heal from the damage.", "Permanent Strength II", "Player kills instantly restore three hearts"),
    CHRONOWARDEN("chronowarden", "Chronowarden", "\ue205", "MYTHIC", NamedTextColor.GOLD, 4, 100, 75, "Time Lock", "Suspend the enemy in your crosshair for five seconds.", "Rewind", "Return to your location and health from six seconds ago.", "Ability cooldowns recover 15% faster", "Escape fatal damage once every eight minutes"),
    RIFTWALKER("riftwalker", "Riftwalker", "\ue201", "LEGENDARY", NamedTextColor.LIGHT_PURPLE, 8, 35, 55, "Rift Step", "Blink eighteen blocks toward your crosshair.", "Void Snare", "Collapse a rift that pulls and wounds nearby enemies.", "Permanent Speed I", "20% chance to phase through projectiles"),
    SOULWEAVER("soulweaver", "Soulweaver", "\ue206", "LEGENDARY", NamedTextColor.DARK_AQUA, 10, 60, 45, "Soul Siphon", "Drain up to three nearby enemies into absorption hearts.", "Spirit Swap", "Exchange places with the enemy in your crosshair.", "Player kills grant six absorption hearts", "Gain Soul Ward while below five hearts"),
    STORMBORN("stormborn", "Stormborn", "\ue202", "EPIC", NamedTextColor.AQUA, 14, 60, 50, "Storm Leap", "Launch forward and create a damaging landing burst.", "Chain Lightning", "Arc lightning through up to three enemies.", "Complete fall-damage immunity", "Deal one and a half extra hearts during storms"),
    FROSTBOUND("frostbound", "Frostbound", "\ue207", "EPIC", NamedTextColor.BLUE, 16, 60, 45, "Glacier Cage", "Freeze the nearest enemy in place for six seconds.", "Frost Nova", "Damage and deeply freeze every nearby enemy.", "Immune to freezing and powder snow", "Attacks have a 15% chance to frost enemies"),
    IRONHEART("ironheart", "Ironheart", "\ue203", "RARE", NamedTextColor.GOLD, 20, 75, 50, "Bastion", "Gain Resistance II and six absorption hearts for ten seconds.", "Groundbreaker", "Smash the earth, damaging and launching nearby enemies.", "30% permanent knockback resistance", "Take 20% less damage below six hearts"),
    HUNTSMAN("huntsman", "Huntsman", "\ue204", "COMMON", NamedTextColor.GREEN, 25, 50, 35, "Quarry Mark", "Track the nearest player for thirty-five seconds.", "Piercing Shot", "Fire an instant shot through the enemy in your crosshair.", "Sense trails from injured players", "Gain speed while closing on wounded prey");

    private final String id;
    private final String displayName;
    private final String icon;
    private final String rarity;
    private final NamedTextColor color;
    private final int weight;
    private final int primaryCooldownSeconds;
    private final int secondaryCooldownSeconds;
    private final String primaryName;
    private final String primaryDescription;
    private final String secondaryName;
    private final String secondaryDescription;
    private final String passiveOne;
    private final String passiveTwo;

    private HuntAbility(String id, String displayName, String icon, String rarity, NamedTextColor color, int weight, int primaryCooldownSeconds, int secondaryCooldownSeconds, String primaryName, String primaryDescription, String secondaryName, String secondaryDescription, String passiveOne, String passiveTwo) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.rarity = rarity;
        this.color = color;
        this.weight = weight;
        this.primaryCooldownSeconds = primaryCooldownSeconds;
        this.secondaryCooldownSeconds = secondaryCooldownSeconds;
        this.primaryName = primaryName;
        this.primaryDescription = primaryDescription;
        this.secondaryName = secondaryName;
        this.secondaryDescription = secondaryDescription;
        this.passiveOne = passiveOne;
        this.passiveTwo = passiveTwo;
    }

    String id() {
        return this.id;
    }

    String displayName() {
        return this.displayName;
    }

    String icon() {
        return this.icon;
    }

    String rarity() {
        return this.rarity;
    }

    NamedTextColor color() {
        return this.color;
    }

    int weight() {
        return this.weight;
    }

    int primaryCooldownSeconds() {
        return this.primaryCooldownSeconds;
    }

    int secondaryCooldownSeconds() {
        return this.secondaryCooldownSeconds;
    }

    String primaryName() {
        return this.primaryName;
    }

    String primaryDescription() {
        return this.primaryDescription;
    }

    String secondaryName() {
        return this.secondaryName;
    }

    String secondaryDescription() {
        return this.secondaryDescription;
    }

    String passiveOne() {
        return this.passiveOne;
    }

    String passiveTwo() {
        return this.passiveTwo;
    }

    static HuntAbility byId(String id) {
        if (id == null) {
            return null;
        }
        for (HuntAbility ability : HuntAbility.values()) {
            if (!ability.id.equalsIgnoreCase(id) && !ability.name().equalsIgnoreCase(id)) continue;
            return ability;
        }
        return null;
    }
}

