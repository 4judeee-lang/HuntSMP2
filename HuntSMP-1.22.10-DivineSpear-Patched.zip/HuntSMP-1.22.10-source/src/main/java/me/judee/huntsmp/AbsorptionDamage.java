/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntsmp;

import org.bukkit.entity.Player;

final class AbsorptionDamage {
    private AbsorptionDamage() {
    }

    static double clamp(Player player, double d) {
        if (player == null || !Double.isFinite(d) || d <= 0.0) {
            return 0.0;
        }
        double d2 = Math.max(0.0, player.getHealth());
        double d3 = Math.max(0.0, player.getAbsorptionAmount());
        return Math.min(d, d2 + d3);
    }

    static void apply(Player player, double d) {
        double d2;
        if (player == null || !Double.isFinite(d) || d <= 0.0) {
            return;
        }
        double d3 = d;
        double d4 = Math.max(0.0, player.getAbsorptionAmount());
        if (d4 > 0.0) {
            d2 = Math.min(d4, d3);
            player.setAbsorptionAmount(Math.max(0.0, d4 - d2));
            d3 -= d2;
        }
        if (d3 > 0.0) {
            d2 = Math.max(0.0, player.getHealth());
            player.setHealth(Math.max(0.0, d2 - Math.min(d2, d3)));
        }
    }
}

