/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntsmp;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import me.judee.huntsmp.HuntAbility;
import me.judee.huntsmp.HuntPlugin;
import me.judee.huntsmp.PremiumText;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

final class AbilityManager
implements Listener {
    private static final Key ICON_FONT = Key.key((String)"hunt:ability_icons");
    private static final int[] GUI_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 22};
    private static final int[] ROLL_DELAYS = new int[]{2, 2, 2, 3, 3, 3, 4, 4, 5, 5, 6, 7, 8, 10, 12};
    private final HuntPlugin plugin;
    private final File file;
    private final YamlConfiguration data;
    private final Map<UUID, HuntAbility> assignments = new HashMap<UUID, HuntAbility>();
    private final Map<UUID, Long> primaryCooldowns = new HashMap<UUID, Long>();
    private final Map<UUID, Long> secondaryCooldowns = new HashMap<UUID, Long>();
    private final Map<UUID, BukkitTask> bloodRestoreTasks = new HashMap<UUID, BukkitTask>();
    private final Map<UUID, UUID> bloodTargets = new HashMap<UUID, UUID>();
    private final Set<UUID> stormLandings = new HashSet<UUID>();
    private final Map<UUID, Long> huntsmanMarks = new HashMap<UUID, Long>();
    private final Map<UUID, Long> frozenUntil = new HashMap<UUID, Long>();
    private final Map<UUID, Long> chronowardenSaves = new HashMap<UUID, Long>();
    private final Map<UUID, ArrayDeque<PlayerSnapshot>> snapshots = new HashMap<UUID, ArrayDeque<PlayerSnapshot>>();
    private final Set<UUID> rollingPlayers = new HashSet<UUID>();
    private final Map<UUID, BukkitTask> rollTasks = new HashMap<UUID, BukkitTask>();
    private BukkitTask statusTask;
    private final NamespacedKey ironheartModifierKey;
    private final NamespacedKey bloodGainKey;
    private final NamespacedKey bloodLossKey;

    AbilityManager(HuntPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "abilities.yml");
        this.data = YamlConfiguration.loadConfiguration((File)this.file);
        this.ironheartModifierKey = new NamespacedKey((Plugin)plugin, "ironheart_knockback");
        this.bloodGainKey = new NamespacedKey((Plugin)plugin, "bloodlord_gain");
        this.bloodLossKey = new NamespacedKey((Plugin)plugin, "bloodlord_loss");
        this.load();
    }

    void start() {
        this.statusTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::tickPlayers, 10L, 10L);
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.applyPassive(player);
        }
    }

    void shutdown() {
        if (this.statusTask != null) {
            this.statusTask.cancel();
        }
        for (BukkitTask task : this.rollTasks.values()) {
            task.cancel();
        }
        this.rollTasks.clear();
        this.rollingPlayers.clear();
        for (UUID casterId : new HashSet<UUID>(this.bloodRestoreTasks.keySet())) {
            this.restoreBloodTransfer(casterId);
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.removePassive(player);
        }
        this.save();
    }

    boolean handleMemberCommand(CommandSender sender, String[] args) {
        if (args.length >= 2 && AbilityManager.isAbilityRoot(args[0]) && args[1].equalsIgnoreCase("info")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(AbilityManager.color("&cOnly players have Hunt abilities."));
                return true;
            }
            Player player = (Player)sender;
            this.showInfo(player);
            return true;
        }
        if (args.length == 2 && AbilityManager.isAbilityRoot(args[0]) && args[1].equalsIgnoreCase("chances")) {
            sender.sendMessage(AbilityManager.color("&6&lHUNT ABILITY CHANCES"));
            for (HuntAbility ability : HuntAbility.values()) {
                sender.sendMessage(AbilityManager.color("&8\u2022 " + this.legacyColor(ability) + ability.displayName() + " &8\u2014 &f" + ability.weight() + "% &7(" + ability.rarity() + ")"));
            }
            return true;
        }
        return false;
    }

    boolean handleOperatorCommand(CommandSender sender, String[] args) {
        if (args.length == 0) {
            return false;
        }
        if (args[0].equalsIgnoreCase("abilities")) {
            Player target;
            if (!(sender instanceof Player)) {
                sender.sendMessage(AbilityManager.color("&cOnly a player can open the ability selector."));
                return true;
            }
            Player player = (Player)sender;
            Player player2 = target = args.length >= 2 ? Bukkit.getPlayerExact((String)args[1]) : player;
            if (target == null) {
                sender.sendMessage(AbilityManager.color("&6&lHUNT &8\u00bb &cThat player is not online."));
                return true;
            }
            this.openSelector(player, target);
            return true;
        }
        if (!AbilityManager.isAbilityRoot(args[0]) || args.length < 2) {
            return false;
        }
        if (args[1].equalsIgnoreCase("reroll")) {
            if (args.length >= 3 && args[2].equalsIgnoreCase("@a")) {
                int queued = 0;
                for (Player online : Bukkit.getOnlinePlayers()) {
                    if (!this.queueReroll(online)) continue;
                    ++queued;
                }
                sender.sendMessage(PremiumText.legacyStyled("&6HUNT &8| &fQueued private ability rerolls for &e" + queued + " &fonline players."));
                return true;
            }
            Player target = this.resolveTarget(sender, args.length >= 3 ? args[2] : null);
            if (target != null) {
                this.queueReroll(target);
            }
            return true;
        }
        if (args[1].equalsIgnoreCase("give") && args.length == 4) {
            Player target = Bukkit.getPlayerExact((String)args[2]);
            HuntAbility ability = HuntAbility.byId(args[3]);
            if (target == null || ability == null) {
                sender.sendMessage(AbilityManager.color("&6&lHUNT &8\u00bb &cUsage: /hunt ability give <player> <ability>"));
                return true;
            }
            this.assign(target, ability, true);
            return true;
        }
        return false;
    }

    List<String> memberTab(CommandSender sender, String[] args) {
        if (args.length == 1) {
            return "ability".startsWith(args[0].toLowerCase()) ? List.of("ability") : List.of();
        }
        if (args.length == 2 && AbilityManager.isAbilityRoot(args[0])) {
            String typed = args[1].toLowerCase();
            return List.of("info", "chances").stream().filter(value -> value.startsWith(typed)).toList();
        }
        return List.of();
    }

    List<String> operatorTab(String[] args) {
        if (args.length == 1) {
            String typed = args[0].toLowerCase();
            return List.of("abilities", "ability").stream().filter(value -> value.startsWith(typed)).toList();
        }
        if (args.length == 2 && AbilityManager.isAbilityRoot(args[0])) {
            String typed = args[1].toLowerCase();
            return List.of("info", "chances", "reroll", "give").stream().filter(value -> value.startsWith(typed)).toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("abilities") || args.length == 3 && AbilityManager.isAbilityRoot(args[0]) && List.of("reroll", "give").contains(args[1].toLowerCase())) {
            String typed = args[args.length - 1].toLowerCase();
            ArrayList<String> targets = new ArrayList<String>();
            if (args[1].equalsIgnoreCase("reroll") && "@a".startsWith(typed)) {
                targets.add("@a");
            }
            targets.addAll(Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase().startsWith(typed)).toList());
            return targets;
        }
        if (args.length == 4 && AbilityManager.isAbilityRoot(args[0]) && args[1].equalsIgnoreCase("give")) {
            String typed = args[3].toLowerCase();
            return Arrays.stream(HuntAbility.values()).map(HuntAbility::id).filter(id -> id.startsWith(typed)).toList();
        }
        return List.of();
    }

    boolean queueReroll(Player player) {
        if (player == null || !player.isOnline() || !this.rollingPlayers.add(player.getUniqueId())) {
            return false;
        }
        this.removePassive(player);
        player.showTitle(Title.title((Component)PremiumText.gradient("H U N T   P O W E R", 16773286, 12941055), (Component)PremiumText.mini("YOUR FATE IS AWAKENING", 16050687, 11102975), (Title.Times)Title.Times.times((Duration)Duration.ofMillis(150L), (Duration)Duration.ofSeconds(1L), (Duration)Duration.ofMillis(150L))));
        player.playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.75f, 1.2f);
        this.rollTasks.put(player.getUniqueId(), Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.showRollFrame(player.getUniqueId(), 0), 12L));
        return true;
    }

    private void showRollFrame(UUID playerId, int frameIndex) {
        Player rolling = Bukkit.getPlayer((UUID)playerId);
        if (rolling == null || !rolling.isOnline()) {
            this.finishRoll(playerId);
            return;
        }
        if (frameIndex >= ROLL_DELAYS.length) {
            HuntAbility result = this.weightedRoll();
            this.assign(rolling, result, false);
            Component finalTitle = this.abilityName(result);
            Component finalSubtitle = PremiumText.mini(result.rarity() + "  |  " + result.primaryName().toUpperCase(), this.paletteStart(result), this.paletteEnd(result));
            rolling.showTitle(Title.title((Component)finalTitle, (Component)finalSubtitle, (Title.Times)Title.Times.times((Duration)Duration.ofMillis(100L), (Duration)Duration.ofSeconds(3L), (Duration)Duration.ofMillis(500L))));
            rolling.playSound(rolling.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.9f, this.rarityPitch(result));
            this.sendPrivateRollResult(rolling, result);
            this.finishRoll(playerId);
            return;
        }
        HuntAbility preview = HuntAbility.values()[Math.floorMod(playerId.hashCode() + frameIndex, HuntAbility.values().length)];
        Component centerTitle = this.abilityName(preview);
        Component centerSubtitle = PremiumText.mini(preview.rarity() + "  |  " + preview.weight() + "%", this.paletteStart(preview), this.paletteEnd(preview));
        int delay = ROLL_DELAYS[frameIndex];
        rolling.showTitle(Title.title((Component)centerTitle, (Component)centerSubtitle, (Title.Times)Title.Times.times((Duration)Duration.ZERO, (Duration)Duration.ofMillis((long)delay * 50L + 180L), (Duration)Duration.ZERO)));
        rolling.playSound(rolling.getLocation(), Sound.UI_BUTTON_CLICK, 0.27f, Math.min(1.75f, 0.82f + (float)frameIndex * 0.045f));
        this.rollTasks.put(playerId, Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.showRollFrame(playerId, frameIndex + 1), (long)delay));
    }

    private void sendPrivateRollResult(Player player, HuntAbility result) {
        player.sendMessage(PremiumText.mini("- - - - -  POWER AWAKENED  - - - - -", 9271632, 16770714));
        player.sendMessage(this.abilityName(result).append((Component)Component.text((String)"   ")).append(PremiumText.mini(result.rarity(), this.paletteStart(result), this.paletteEnd(result))));
        player.sendMessage(PremiumText.mini(result.primaryName().toUpperCase() + "  |  ", 16767363, 15178808).append(PremiumText.mini(result.primaryDescription(), 15987960, 9476006)));
        player.sendMessage(PremiumText.mini("SNEAK + F  PRIMARY     |     F  SECONDARY", 16769406, 5626367));
    }

    private void finishRoll(UUID playerId) {
        BukkitTask task = this.rollTasks.remove(playerId);
        if (task != null) {
            task.cancel();
        }
        this.rollingPlayers.remove(playerId);
    }

    private HuntAbility weightedRoll() {
        int total = Arrays.stream(HuntAbility.values()).mapToInt(HuntAbility::weight).sum();
        int value = ThreadLocalRandom.current().nextInt(total);
        for (HuntAbility ability : HuntAbility.values()) {
            if ((value -= ability.weight()) >= 0) continue;
            return ability;
        }
        return HuntAbility.HUNTSMAN;
    }

    private void assign(Player player, HuntAbility ability, boolean announce) {
        this.removePassive(player);
        this.assignments.put(player.getUniqueId(), ability);
        this.primaryCooldowns.remove(player.getUniqueId());
        this.secondaryCooldowns.remove(player.getUniqueId());
        this.applyPassive(player);
        this.save();
        if (announce) {
            player.sendMessage(((TextComponent)Component.text((String)"Your Hunt ability is ", (TextColor)NamedTextColor.GRAY).append(this.abilityName(ability))).append((Component)Component.text((String)(" (" + ability.rarity() + ")"), (TextColor)ability.color())));
        }
    }

    private void openSelector(Player operator, Player target) {
        Inventory inventory;
        AbilityHolder holder = new AbilityHolder(target.getUniqueId());
        holder.inventory = inventory = Bukkit.createInventory((InventoryHolder)holder, (int)27, (Component)PremiumText.mini("ABILITY ARCHIVE   |   " + target.getName().toUpperCase(), 0xFF9C9C, 9054541));
        ItemStack filler = this.menuItem(Material.BLACK_STAINED_GLASS_PANE, "&0", List.of());
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
        HuntAbility[] values = HuntAbility.values();
        for (int index = 0; index < values.length; ++index) {
            HuntAbility ability = values[index];
            inventory.setItem(GUI_SLOTS[index], this.abilityItem(ability));
            holder.abilities.put(GUI_SLOTS[index], ability);
        }
        operator.openInventory(inventory);
    }

    @EventHandler
    public void onAbilityGuiClick(InventoryClickEvent event) {
        Player operator;
        InventoryHolder inventoryHolder = event.getView().getTopInventory().getHolder();
        if (!(inventoryHolder instanceof AbilityHolder)) {
            return;
        }
        AbilityHolder holder = (AbilityHolder)inventoryHolder;
        event.setCancelled(true);
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player) || !(operator = (Player)humanEntity).isOp()) {
            return;
        }
        HuntAbility ability = holder.abilities.get(event.getRawSlot());
        Player target = Bukkit.getPlayer((UUID)holder.target);
        if (ability != null && target != null) {
            this.assign(target, ability, true);
            operator.sendMessage(AbilityManager.color("&6&lHUNT &8\u00bb &aAssigned &f" + ability.displayName() + " &ato &f" + target.getName() + "&a."));
            operator.closeInventory();
        }
    }

    @EventHandler
    public void onAbilityGuiDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof AbilityHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onAbilityKey(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (this.plugin.handleAltarWeaponSwap(event)) {
            return;
        }
        if (!this.assignments.containsKey(player.getUniqueId()) || this.plugin.shouldSuppressAbilityBar(player) || this.rollingPlayers.contains(player.getUniqueId())) {
            return;
        }
        event.setCancelled(true);
        if (player.isSneaking()) {
            this.activatePrimary(player);
        } else {
            this.activateSecondary(player);
        }
    }

    private void activatePrimary(Player player) {
        boolean used;
        HuntAbility ability = this.assignments.get(player.getUniqueId());
        long remaining = this.cooldownRemaining(this.primaryCooldowns, player);
        if (remaining > 0L) {
            player.sendActionBar((Component)Component.text((String)(ability.primaryName() + " cooldown: " + remaining + "s"), (TextColor)NamedTextColor.RED));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.6f, 0.7f);
            return;
        }
        switch (ability) {
            default: {
                throw new MatchException(null, null);
            }
            case BLOODLORD: {
                boolean bl = this.useBloodlord(player);
                break;
            }
            case CHRONOWARDEN: {
                boolean bl = this.useTimeLock(player);
                break;
            }
            case RIFTWALKER: {
                boolean bl = this.useRiftwalker(player);
                break;
            }
            case SOULWEAVER: {
                boolean bl = this.useSoulSiphon(player);
                break;
            }
            case STORMBORN: {
                boolean bl = this.useStormborn(player);
                break;
            }
            case FROSTBOUND: {
                boolean bl = this.useGlacierCage(player);
                break;
            }
            case IRONHEART: {
                boolean bl = this.useIronheart(player);
                break;
            }
            case HUNTSMAN: {
                boolean bl = used = this.useHuntsman(player);
            }
        }
        if (used) {
            this.primaryCooldowns.put(player.getUniqueId(), this.cooldownEnd(ability, ability.primaryCooldownSeconds()));
            this.save();
        }
    }

    private void activateSecondary(Player player) {
        boolean used;
        HuntAbility ability = this.assignments.get(player.getUniqueId());
        long remaining = this.cooldownRemaining(this.secondaryCooldowns, player);
        if (remaining > 0L) {
            player.sendActionBar((Component)Component.text((String)(ability.secondaryName() + " cooldown: " + remaining + "s"), (TextColor)NamedTextColor.RED));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.6f, 0.7f);
            return;
        }
        switch (ability) {
            default: {
                throw new MatchException(null, null);
            }
            case BLOODLORD: {
                boolean bl = this.useCrimsonRupture(player);
                break;
            }
            case CHRONOWARDEN: {
                boolean bl = this.useRewind(player);
                break;
            }
            case RIFTWALKER: {
                boolean bl = this.useVoidSnare(player);
                break;
            }
            case SOULWEAVER: {
                boolean bl = this.useSpiritSwap(player);
                break;
            }
            case STORMBORN: {
                boolean bl = this.useChainLightning(player);
                break;
            }
            case FROSTBOUND: {
                boolean bl = this.useFrostNova(player);
                break;
            }
            case IRONHEART: {
                boolean bl = this.useGroundbreaker(player);
                break;
            }
            case HUNTSMAN: {
                boolean bl = used = this.usePiercingShot(player);
            }
        }
        if (used) {
            this.secondaryCooldowns.put(player.getUniqueId(), this.cooldownEnd(ability, ability.secondaryCooldownSeconds()));
            this.save();
        }
    }

    private long cooldownEnd(HuntAbility ability, int seconds) {
        double multiplier = ability == HuntAbility.CHRONOWARDEN ? 0.85 : 1.0;
        return System.currentTimeMillis() + Math.round((double)((long)seconds * 1000L) * multiplier);
    }

    private boolean useBloodlord(Player caster) {
        if (this.plugin.isGraceActive()) {
            this.fail(caster, "Blood Tether cannot be used during grace.");
            return false;
        }
        Player target = this.nearestTarget(caster, 18.0, true);
        if (target == null || this.bloodTargets.containsValue(target.getUniqueId())) {
            this.fail(caster, "No valid nearby heart to tether.");
            return false;
        }
        if (this.plugin.isDamageBlockedByTrust(target, caster)) {
            this.fail(caster, "Your trust bond protects that player from Blood Tether.");
            return false;
        }
        AttributeInstance casterHealth = caster.getAttribute(Attribute.MAX_HEALTH);
        AttributeInstance targetHealth = target.getAttribute(Attribute.MAX_HEALTH);
        if (casterHealth == null || targetHealth == null || targetHealth.getValue() <= 6.0) {
            this.fail(caster, "That target cannot lose more hearts.");
            return false;
        }
        casterHealth.removeModifier((Key)this.bloodGainKey);
        targetHealth.removeModifier((Key)this.bloodLossKey);
        casterHealth.addTransientModifier(new AttributeModifier(this.bloodGainKey, 4.0, AttributeModifier.Operation.ADD_NUMBER));
        targetHealth.addTransientModifier(new AttributeModifier(this.bloodLossKey, -4.0, AttributeModifier.Operation.ADD_NUMBER));
        target.setHealth(Math.min(target.getHealth(), targetHealth.getValue()));
        caster.setHealth(Math.min(casterHealth.getValue(), caster.getHealth() + 4.0));
        this.bloodTargets.put(caster.getUniqueId(), target.getUniqueId());
        BukkitTask restore = Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.restoreBloodTransfer(caster.getUniqueId()), 600L);
        this.bloodRestoreTasks.put(caster.getUniqueId(), restore);
        caster.sendMessage(AbilityManager.color("&4&lBLOOD TETHER &8\u00bb &fYou stole two hearts from &c" + target.getName() + "&f."));
        target.sendMessage(AbilityManager.color("&4&lBLOOD TETHER &8\u00bb &c" + caster.getName() + " stole two hearts for thirty seconds."));
        this.animateBloodTether(caster, target);
        return true;
    }

    private void animateBloodTether(Player caster, Player target) {
        BukkitTask[] task;
        int[] pulses = new int[]{0};
        task = new BukkitTask[]{Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, () -> {
            block3: {
                block2: {
                    if (!caster.isOnline() || !target.isOnline() || caster.getWorld() != target.getWorld()) break block2;
                    int n = pulses[0];
                    pulses[0] = n + 1;
                    if (n < 30) break block3;
                }
                task[0].cancel();
                return;
            }
            this.renderLine(caster, target, HuntAbility.BLOODLORD, 28);
        }, 0L, 2L)};
    }

    private void restoreBloodTransfer(UUID casterId) {
        Player target;
        BukkitTask task = this.bloodRestoreTasks.remove(casterId);
        if (task != null) {
            task.cancel();
        }
        UUID targetId = this.bloodTargets.remove(casterId);
        Player caster = Bukkit.getPlayer((UUID)casterId);
        Player player = target = targetId == null ? null : Bukkit.getPlayer((UUID)targetId);
        if (caster != null) {
            this.removeModifier(caster, Attribute.MAX_HEALTH, this.bloodGainKey);
        }
        if (target != null) {
            this.removeModifier(target, Attribute.MAX_HEALTH, this.bloodLossKey);
            AttributeInstance health = target.getAttribute(Attribute.MAX_HEALTH);
            if (health != null) {
                target.setHealth(Math.min(target.getHealth() + 4.0, health.getValue()));
            }
        }
    }

    private boolean useRiftwalker(Player player) {
        Location start = player.getLocation().clone();
        Vector direction = player.getEyeLocation().getDirection().normalize();
        RayTraceResult hit = player.getWorld().rayTraceBlocks(player.getEyeLocation(), direction, 18.0, FluidCollisionMode.NEVER, true);
        double distance = hit == null ? 18.0 : Math.max(1.0, hit.getHitPosition().distance(player.getEyeLocation().toVector()) - 1.25);
        Location destination = start.clone().add(direction.multiply(distance));
        destination.setYaw(start.getYaw());
        destination.setPitch(start.getPitch());
        if (!player.teleport(destination)) {
            this.fail(player, "The rift could not find a safe destination.");
            return false;
        }
        this.renderPath(player, start, destination, HuntAbility.RIFTWALKER);
        player.playSound(destination, Sound.ENTITY_ENDERMAN_TELEPORT, 0.9f, 1.35f);
        return true;
    }

    private boolean useStormborn(Player player) {
        Vector velocity = player.getLocation().getDirection().normalize().multiply(1.35).setY(0.82);
        player.setVelocity(velocity);
        this.stormLandings.add(player.getUniqueId());
        player.getWorld().spawnParticle(Particle.ITEM, player.getLocation().add(0.0, 1.0, 0.0), 20, 0.45, 0.7, 0.45, 0.12, (Object)this.particleItem(HuntAbility.STORMBORN));
        player.playSound(player.getLocation(), Sound.ENTITY_BREEZE_WIND_BURST, 1.0f, 0.85f);
        return true;
    }

    private void stormLanding(Player player) {
        Location center = player.getLocation().add(0.0, 0.2, 0.0);
        player.getWorld().strikeLightningEffect(center);
        player.getWorld().spawnParticle(Particle.ITEM, center, 45, 2.2, 0.4, 2.2, 0.18, (Object)this.particleItem(HuntAbility.STORMBORN));
        for (Player other : player.getWorld().getPlayers()) {
            if (other.equals((Object)player) || other.getLocation().distanceSquared(center) > 36.0 || this.plugin.isGraceActive() || !this.plugin.dealHuntDamage(player, other, 8.0, DamageType.MAGIC)) continue;
            Vector knock = other.getLocation().toVector().subtract(center.toVector()).normalize().multiply(1.1).setY(0.45);
            other.setVelocity(knock);
        }
        player.playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.85f, 1.25f);
    }

    private boolean useIronheart(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 1, false, true, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 2, false, true, true));
        player.getWorld().spawnParticle(Particle.ITEM, player.getLocation().add(0.0, 1.0, 0.0), 35, 0.8, 1.0, 0.8, 0.08, (Object)this.particleItem(HuntAbility.IRONHEART));
        player.playSound(player.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1.0f, 0.65f);
        return true;
    }

    private boolean useHuntsman(Player player) {
        Player target = this.nearestTarget(player, 50.0, false);
        if (target == null) {
            this.fail(player, "No quarry is close enough to mark.");
            return false;
        }
        this.huntsmanMarks.put(player.getUniqueId(), System.currentTimeMillis() + 35000L);
        this.data.set("marks." + String.valueOf(player.getUniqueId()) + ".target", (Object)target.getUniqueId().toString());
        player.sendMessage(AbilityManager.color("&2&lQUARRY MARK &8\u00bb &fTracking &a" + target.getName() + " &ffor 35 seconds."));
        player.playSound(player.getLocation(), Sound.ENTITY_ARROW_HIT_PLAYER, 0.8f, 1.4f);
        return true;
    }

    private boolean useCrimsonRupture(Player caster) {
        if (this.plugin.isGraceActive()) {
            this.fail(caster, "Crimson Rupture cannot be used during grace.");
            return false;
        }
        int hits = 0;
        Location center = caster.getLocation().add(0.0, 1.0, 0.0);
        this.burst(center, HuntAbility.BLOODLORD, 55, 2.7);
        for (Player target : caster.getWorld().getPlayers()) {
            if (!this.canDamage(caster, target) || target.getLocation().distanceSquared(center) > 49.0 || !this.plugin.dealHuntDamage(caster, target, 7.0, DamageType.MAGIC)) continue;
            this.renderLine(caster, target, HuntAbility.BLOODLORD, 16);
            ++hits;
        }
        if (hits == 0) {
            this.fail(caster, "No enemy is close enough to rupture.");
            return false;
        }
        caster.setHealth(Math.min(this.maxHealth(caster), caster.getHealth() + Math.min(8.0, (double)hits * 3.0)));
        caster.playSound(center, Sound.ENTITY_WARDEN_HEARTBEAT, 1.0f, 1.35f);
        return true;
    }

    private boolean useTimeLock(Player caster) {
        Player target = this.aimedTarget(caster, 22.0);
        if (target == null) {
            this.fail(caster, "Keep an enemy in your crosshair to lock them.");
            return false;
        }
        this.frozenUntil.put(target.getUniqueId(), System.currentTimeMillis() + 5000L);
        target.setVelocity(new Vector());
        target.sendMessage(AbilityManager.color("&6&lTIME LOCK &8\u00bb &eTime has stopped around you."));
        this.animateOrbit(target, HuntAbility.CHRONOWARDEN, 100);
        caster.playSound(caster.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 1.0f, 1.55f);
        return true;
    }

    private boolean useRewind(Player player) {
        ArrayDeque<PlayerSnapshot> history = this.snapshots.get(player.getUniqueId());
        if (history == null || history.isEmpty()) {
            this.fail(player, "Your timeline has not formed yet.");
            return false;
        }
        PlayerSnapshot snapshot = history.peekFirst();
        Location before = player.getLocation().clone();
        if (!player.teleport(snapshot.location())) {
            this.fail(player, "That point in time is no longer safe.");
            return false;
        }
        player.setHealth(Math.min(this.maxHealth(player), snapshot.health()));
        this.renderPath(player, before, snapshot.location(), HuntAbility.CHRONOWARDEN);
        this.burst(snapshot.location().add(0.0, 1.0, 0.0), HuntAbility.CHRONOWARDEN, 45, 1.2);
        player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1.0f, 0.65f);
        return true;
    }

    private boolean useVoidSnare(Player caster) {
        if (this.plugin.isGraceActive()) {
            this.fail(caster, "Void Snare cannot be used during grace.");
            return false;
        }
        Location center = caster.getEyeLocation().add(caster.getEyeLocation().getDirection().normalize().multiply(9.0));
        int hits = 0;
        this.burst(center, HuntAbility.RIFTWALKER, 60, 2.4);
        for (Player target : caster.getWorld().getPlayers()) {
            if (!this.canDamage(caster, target) || target.getLocation().distanceSquared(center) > 64.0 || !this.plugin.dealHuntDamage(caster, target, 6.0, DamageType.MAGIC)) continue;
            Vector pull = center.toVector().subtract(target.getLocation().toVector()).normalize().multiply(1.15).setY(0.25);
            target.setVelocity(pull);
            ++hits;
        }
        if (hits == 0) {
            this.fail(caster, "The rift found no enemies.");
            return false;
        }
        caster.getWorld().playSound(center, Sound.BLOCK_RESPAWN_ANCHOR_DEPLETE, 1.1f, 0.6f);
        return true;
    }

    private boolean useSoulSiphon(Player caster) {
        if (this.plugin.isGraceActive()) {
            this.fail(caster, "Soul Siphon cannot be used during grace.");
            return false;
        }
        List<Player> targets = caster.getWorld().getPlayers().stream().filter(target -> this.canDamage(caster, (Player)target) && target.getLocation().distanceSquared(caster.getLocation()) <= 196.0).sorted(Comparator.comparingDouble(target -> target.getLocation().distanceSquared(caster.getLocation()))).limit(3L).toList();
        if (targets.isEmpty()) {
            this.fail(caster, "No souls are close enough to siphon.");
            return false;
        }
        int drained = 0;
        for (Player target2 : targets) {
            if (!this.plugin.dealHuntDamage(caster, target2, 6.0, DamageType.MAGIC)) continue;
            this.renderLine(caster, target2, HuntAbility.SOULWEAVER, 22);
            ++drained;
        }
        if (drained == 0) {
            this.fail(caster, "Every nearby soul is protected.");
            return false;
        }
        caster.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 240, Math.min(2, drained - 1), false, true, true));
        this.burst(caster.getLocation().add(0.0, 1.0, 0.0), HuntAbility.SOULWEAVER, 45, 1.3);
        caster.playSound(caster.getLocation(), Sound.ENTITY_ALLAY_AMBIENT_WITH_ITEM, 1.2f, 0.55f);
        return true;
    }

    private boolean useSpiritSwap(Player caster) {
        Player target = this.aimedTarget(caster, 26.0);
        if (target == null) {
            this.fail(caster, "No spirit is in your crosshair.");
            return false;
        }
        Location casterLocation = caster.getLocation().clone();
        Location targetLocation = target.getLocation().clone();
        if (!caster.teleport(targetLocation) || !target.teleport(casterLocation)) {
            caster.teleport(casterLocation);
            this.fail(caster, "The spirit exchange collapsed.");
            return false;
        }
        this.renderPath(caster, casterLocation, targetLocation, HuntAbility.SOULWEAVER);
        this.renderPath(target, targetLocation, casterLocation, HuntAbility.SOULWEAVER);
        caster.getWorld().playSound(casterLocation, Sound.ENTITY_ENDERMAN_TELEPORT, 0.9f, 0.7f);
        caster.getWorld().playSound(targetLocation, Sound.ENTITY_ENDERMAN_TELEPORT, 0.9f, 1.35f);
        return true;
    }

    private boolean useChainLightning(Player caster) {
        if (this.plugin.isGraceActive()) {
            this.fail(caster, "Chain Lightning cannot be used during grace.");
            return false;
        }
        Player current = this.nearestTarget(caster, 22.0, true);
        if (current == null) {
            this.fail(caster, "No enemy can conduct the storm.");
            return false;
        }
        HashSet<UUID> struck = new HashSet<UUID>();
        Player from = caster;
        for (int jump = 0; jump < 4 && current != null; ++jump) {
            this.renderLine(from, current, HuntAbility.STORMBORN, 24);
            this.plugin.dealHuntDamage(caster, current, 6.0, DamageType.MAGIC);
            current.getWorld().playSound(current.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.65f, 1.55f);
            struck.add(current.getUniqueId());
            Player origin = current;
            current = caster.getWorld().getPlayers().stream().filter(next -> this.canDamage(caster, (Player)next) && !struck.contains(next.getUniqueId())).filter(next -> next.getLocation().distanceSquared(origin.getLocation()) <= 81.0).min(Comparator.comparingDouble(next -> next.getLocation().distanceSquared(origin.getLocation()))).orElse(null);
            from = origin;
        }
        return true;
    }

    private boolean useGlacierCage(Player caster) {
        if (this.plugin.isGraceActive()) {
            this.fail(caster, "Glacier Cage cannot be used during grace.");
            return false;
        }
        Player target = this.nearestTarget(caster, 20.0, true);
        if (target == null) {
            this.fail(caster, "No enemy can be caged.");
            return false;
        }
        if (!this.plugin.dealHuntDamage(caster, target, 6.0, DamageType.MAGIC)) {
            this.fail(caster, "That enemy is protected from your cage.");
            return false;
        }
        this.frozenUntil.put(target.getUniqueId(), System.currentTimeMillis() + 6000L);
        target.setFreezeTicks(Math.max(target.getFreezeTicks(), 180));
        this.animateOrbit(target, HuntAbility.FROSTBOUND, 120);
        target.getWorld().playSound(target.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.0f, 0.55f);
        return true;
    }

    private boolean useFrostNova(Player caster) {
        if (this.plugin.isGraceActive()) {
            this.fail(caster, "Frost Nova cannot be used during grace.");
            return false;
        }
        int hits = 0;
        this.burst(caster.getLocation().add(0.0, 0.5, 0.0), HuntAbility.FROSTBOUND, 70, 3.0);
        for (Player target : caster.getWorld().getPlayers()) {
            if (!this.canDamage(caster, target) || target.getLocation().distanceSquared(caster.getLocation()) > 81.0 || !this.plugin.dealHuntDamage(caster, target, 7.0, DamageType.MAGIC)) continue;
            target.setFreezeTicks(Math.max(target.getFreezeTicks(), 220));
            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 140, 2, false, true, true));
            ++hits;
        }
        if (hits == 0) {
            this.fail(caster, "No enemies are inside the nova.");
            return false;
        }
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_PLAYER_HURT_FREEZE, 1.2f, 0.55f);
        return true;
    }

    private boolean useGroundbreaker(Player caster) {
        if (this.plugin.isGraceActive()) {
            this.fail(caster, "Groundbreaker cannot be used during grace.");
            return false;
        }
        int hits = 0;
        Location center = caster.getLocation();
        this.burst(center.add(0.0, 0.25, 0.0), HuntAbility.IRONHEART, 65, 2.8);
        for (Player target : caster.getWorld().getPlayers()) {
            if (!this.canDamage(caster, target) || target.getLocation().distanceSquared(caster.getLocation()) > 64.0 || !this.plugin.dealHuntDamage(caster, target, 7.0, DamageType.MAGIC)) continue;
            Vector knock = target.getLocation().toVector().subtract(caster.getLocation().toVector()).normalize().multiply(1.25).setY(0.65);
            target.setVelocity(knock);
            ++hits;
        }
        if (hits == 0) {
            this.fail(caster, "No enemies are close enough to break.");
            return false;
        }
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_IRON_GOLEM_ATTACK, 1.0f, 0.65f);
        return true;
    }

    private boolean usePiercingShot(Player caster) {
        if (this.plugin.isGraceActive()) {
            this.fail(caster, "Piercing Shot cannot be used during grace.");
            return false;
        }
        Player target = this.aimedTarget(caster, 36.0);
        if (target == null) {
            this.fail(caster, "No prey is in your sights.");
            return false;
        }
        this.renderLine(caster, target, HuntAbility.HUNTSMAN, 34);
        if (!this.plugin.dealHuntDamage(caster, target, 7.0, DamageType.MAGIC)) {
            this.fail(caster, "That quarry is protected from the shot.");
            return false;
        }
        target.setNoDamageTicks(0);
        caster.playSound(caster.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0f, 0.7f);
        target.playSound(target.getLocation(), Sound.ENTITY_ARROW_HIT_PLAYER, 1.0f, 1.2f);
        return true;
    }

    private Player nearestTarget(Player player, double range, boolean requireSight) {
        return player.getWorld().getPlayers().stream().filter(other -> !other.equals((Object)player) && !other.isDead() && player.canSee(other)).filter(other -> other.getLocation().distanceSquared(player.getLocation()) <= range * range).filter(other -> !requireSight || player.hasLineOfSight((Entity)other)).min(Comparator.comparingDouble(other -> other.getLocation().distanceSquared(player.getLocation()))).orElse(null);
    }

    private Player aimedTarget(Player player, double range) {
        Player target;
        Entity entity2;
        RayTraceResult result = player.getWorld().rayTraceEntities(player.getEyeLocation(), player.getEyeLocation().getDirection().normalize(), range, 0.75, entity -> {
            Player target;
            return entity instanceof Player && !(target = (Player)entity).equals((Object)player) && !target.isDead() && player.canSee(target);
        });
        return result != null && (entity2 = result.getHitEntity()) instanceof Player ? (target = (Player)entity2) : null;
    }

    private void tickPlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.recordSnapshot(player);
            this.applyPassive(player);
            HuntAbility ability = this.assignments.get(player.getUniqueId());
            if (ability != null && player.getTicksLived() % 40 < 10) {
                player.getWorld().spawnParticle(Particle.ITEM, player.getLocation().add(0.0, 0.15, 0.0), 1, 0.32, 0.04, 0.32, 0.01, (Object)this.particleItem(ability));
            }
            if (ability == HuntAbility.STORMBORN && this.stormLandings.contains(player.getUniqueId()) && player.isOnGround()) {
                this.stormLandings.remove(player.getUniqueId());
                this.stormLanding(player);
            }
            if (ability == HuntAbility.HUNTSMAN) {
                this.renderHuntsmanPassive(player);
            }
            if (ability == HuntAbility.HUNTSMAN) {
                this.applyHuntsmanPursuit(player);
            }
            if (ability == HuntAbility.FROSTBOUND) {
                player.setFreezeTicks(0);
            }
            this.renderHuntsmanMark(player);
            if (this.rollingPlayers.contains(player.getUniqueId()) || this.plugin.shouldSuppressAbilityBar(player)) continue;
            this.sendStatusBar(player);
        }
    }

    private void applyPassive(Player player) {
        HuntAbility ability = this.assignments.get(player.getUniqueId());
        if (ability == null) {
            return;
        }
        switch (ability) {
            case BLOODLORD: {
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 40, 1, false, false, true));
                break;
            }
            case RIFTWALKER: {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 0, false, false, true));
                break;
            }
            case SOULWEAVER: {
                if (!(player.getHealth() <= 10.0)) break;
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 40, 0, false, false, true));
                break;
            }
            case IRONHEART: {
                AttributeInstance attribute = player.getAttribute(Attribute.KNOCKBACK_RESISTANCE);
                if (attribute == null || attribute.getModifier((Key)this.ironheartModifierKey) != null) break;
                attribute.addTransientModifier(new AttributeModifier(this.ironheartModifierKey, 0.3, AttributeModifier.Operation.ADD_NUMBER));
                break;
            }
        }
    }

    private void removePassive(Player player) {
        this.removeManagedEffect(player, PotionEffectType.STRENGTH);
        this.removeManagedEffect(player, PotionEffectType.SPEED);
        this.removeManagedEffect(player, PotionEffectType.RESISTANCE);
        this.removeModifier(player, Attribute.KNOCKBACK_RESISTANCE, this.ironheartModifierKey);
    }

    private void removeManagedEffect(Player player, PotionEffectType type) {
        PotionEffect effect = player.getPotionEffect(type);
        if (effect != null && (effect.getAmplifier() == 0 || type == PotionEffectType.STRENGTH && effect.getAmplifier() == 1) && effect.getDuration() <= 45 && !effect.hasParticles()) {
            player.removePotionEffect(type);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onAbilityDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player)) {
            return;
        }
        Player player = (Player)entity;
        HuntAbility ability = this.assignments.get(player.getUniqueId());
        if (ability == HuntAbility.STORMBORN && event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            event.setCancelled(true);
            player.setFallDistance(0.0f);
            return;
        }
        if (ability == HuntAbility.FROSTBOUND && event.getCause() == EntityDamageEvent.DamageCause.FREEZE) {
            event.setCancelled(true);
            player.setFreezeTicks(0);
            return;
        }
        if (ability == HuntAbility.IRONHEART && player.getHealth() <= 12.0) {
            event.setDamage(event.getDamage() * 0.8);
        }
        if (ability == HuntAbility.CHRONOWARDEN && event.getFinalDamage() >= player.getHealth()) {
            long readyAt = this.chronowardenSaves.getOrDefault(player.getUniqueId(), 0L);
            ArrayDeque<PlayerSnapshot> history = this.snapshots.get(player.getUniqueId());
            if (readyAt <= System.currentTimeMillis() && history != null && !history.isEmpty()) {
                event.setCancelled(true);
                PlayerSnapshot snapshot = history.peekFirst();
                player.teleport(snapshot.location());
                player.setHealth(Math.min(this.maxHealth(player), Math.max(12.0, snapshot.health())));
                player.setFireTicks(0);
                this.chronowardenSaves.put(player.getUniqueId(), System.currentTimeMillis() + 480000L);
                this.burst(player.getLocation().add(0.0, 1.0, 0.0), HuntAbility.CHRONOWARDEN, 70, 1.6);
                player.sendMessage(AbilityManager.color("&6&lSECOND CHANCE &8\u00bb &eYour timeline refused to end."));
                player.playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_SET_SPAWN, 1.2f, 1.6f);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onAbilityAttack(EntityDamageByEntityEvent event) {
        Entity attacker;
        Projectile projectile;
        Entity entity = event.getEntity();
        if (!(entity instanceof Player)) {
            return;
        }
        Player victim = (Player)entity;
        Entity entity2 = event.getDamager();
        if (entity2 instanceof Projectile && (entity2 = (projectile = (Projectile)entity2).getShooter()) instanceof Player) {
            attacker = (Player)entity2;
            if (this.assignments.get(victim.getUniqueId()) == HuntAbility.RIFTWALKER && ThreadLocalRandom.current().nextDouble() < 0.2) {
                event.setCancelled(true);
                this.burst(victim.getLocation().add(0.0, 1.0, 0.0), HuntAbility.RIFTWALKER, 24, 0.8);
                victim.playSound(victim.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.7f, 1.7f);
                attacker.sendActionBar((Component)Component.text((String)(victim.getName() + " phased through your projectile"), (TextColor)NamedTextColor.LIGHT_PURPLE));
                return;
            }
        }
        if (!((attacker = event.getDamager()) instanceof Player)) {
            return;
        }
        Player attacker2 = (Player)attacker;
        if (this.plugin.isGraceActive() || this.plugin.isDamageBlockedByTrust(victim, attacker2)) {
            return;
        }
        HuntAbility attackingAbility = this.assignments.get(attacker2.getUniqueId());
        if (attackingAbility == HuntAbility.STORMBORN && attacker2.getWorld().hasStorm()) {
            event.setDamage(event.getDamage() + 3.0);
            this.burst(victim.getLocation().add(0.0, 1.0, 0.0), HuntAbility.STORMBORN, 12, 0.45);
        }
        if (attackingAbility == HuntAbility.FROSTBOUND && ThreadLocalRandom.current().nextDouble() < 0.15) {
            victim.setFreezeTicks(Math.max(victim.getFreezeTicks(), 120));
            victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1, false, true, true));
            this.burst(victim.getLocation().add(0.0, 1.0, 0.0), HuntAbility.FROSTBOUND, 18, 0.6);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onAbilityKill(PlayerDeathEvent event) {
        Player killer = event.getPlayer().getKiller();
        if (killer == null) {
            return;
        }
        HuntAbility ability = this.assignments.get(killer.getUniqueId());
        if (ability == HuntAbility.BLOODLORD) {
            killer.setHealth(Math.min(this.maxHealth(killer), killer.getHealth() + 6.0));
            this.burst(killer.getLocation().add(0.0, 1.0, 0.0), HuntAbility.BLOODLORD, 30, 0.9);
        } else if (ability == HuntAbility.SOULWEAVER) {
            killer.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 600, 2, false, true, true));
            this.burst(killer.getLocation().add(0.0, 1.0, 0.0), HuntAbility.SOULWEAVER, 30, 0.9);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onFrozenMove(PlayerMoveEvent event) {
        if (!event.hasChangedPosition()) {
            return;
        }
        Long until = this.frozenUntil.get(event.getPlayer().getUniqueId());
        if (until == null) {
            return;
        }
        if (until <= System.currentTimeMillis()) {
            this.frozenUntil.remove(event.getPlayer().getUniqueId());
            return;
        }
        Location locked = event.getFrom().clone();
        locked.setYaw(event.getTo().getYaw());
        locked.setPitch(event.getTo().getPitch());
        event.setTo(locked);
        event.getPlayer().setVelocity(new Vector());
    }

    private void renderHuntsmanPassive(Player hunter) {
        for (Player target : hunter.getWorld().getPlayers()) {
            if (target.equals((Object)hunter) || target.getHealth() >= target.getAttribute(Attribute.MAX_HEALTH).getValue() * 0.5 || target.getLocation().distanceSquared(hunter.getLocation()) > 900.0) continue;
            hunter.spawnParticle(Particle.DUST, target.getLocation().add(0.0, 0.15, 0.0), 2, 0.25, 0.05, 0.25, 0.0, (Object)this.trailDust(HuntAbility.HUNTSMAN));
        }
    }

    private void renderHuntsmanMark(Player hunter) {
        UUID targetId;
        Long until = this.huntsmanMarks.get(hunter.getUniqueId());
        if (until == null) {
            return;
        }
        if (until <= System.currentTimeMillis()) {
            this.huntsmanMarks.remove(hunter.getUniqueId());
            this.data.set("marks." + String.valueOf(hunter.getUniqueId()), null);
            return;
        }
        String targetText = this.data.getString("marks." + String.valueOf(hunter.getUniqueId()) + ".target");
        try {
            targetId = UUID.fromString(targetText);
        }
        catch (Exception ignored) {
            return;
        }
        Player target = Bukkit.getPlayer((UUID)targetId);
        if (target == null || target.getWorld() != hunter.getWorld()) {
            return;
        }
        Vector difference = target.getEyeLocation().toVector().subtract(hunter.getEyeLocation().toVector());
        if (difference.lengthSquared() < 0.1) {
            return;
        }
        double distance = difference.length();
        Vector direction = difference.normalize();
        for (double step = 1.0; step <= Math.min(15.0, distance); step += 0.8) {
            hunter.spawnParticle(Particle.DUST, hunter.getEyeLocation().add(direction.clone().multiply(step)), 1, 0.0, 0.0, 0.0, 0.0, (Object)this.trailDust(HuntAbility.HUNTSMAN));
        }
    }

    private void applyHuntsmanPursuit(Player hunter) {
        boolean preyNearby = hunter.getWorld().getPlayers().stream().anyMatch(target -> !target.equals((Object)hunter) && target.getLocation().distanceSquared(hunter.getLocation()) <= 484.0 && target.getHealth() <= this.maxHealth((Player)target) * 0.5 && !this.plugin.isDamageBlockedByTrust((Player)target, hunter));
        if (preyNearby) {
            hunter.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30, 0, false, false, true));
        }
    }

    private void recordSnapshot(Player player) {
        if (this.assignments.get(player.getUniqueId()) != HuntAbility.CHRONOWARDEN || player.isDead()) {
            return;
        }
        ArrayDeque history = this.snapshots.computeIfAbsent(player.getUniqueId(), ignored -> new ArrayDeque());
        history.addLast(new PlayerSnapshot(player.getLocation().clone(), player.getHealth(), System.currentTimeMillis()));
        long cutoff = System.currentTimeMillis() - 6000L;
        while (history.size() > 1 && ((PlayerSnapshot)history.peekFirst()).time() < cutoff) {
            history.removeFirst();
        }
    }

    private boolean canDamage(Player attacker, Player victim) {
        return !attacker.equals((Object)victim) && !victim.isDead() && !this.plugin.isGraceActive();
    }

    private double maxHealth(Player player) {
        AttributeInstance attribute = player.getAttribute(Attribute.MAX_HEALTH);
        return attribute == null ? 20.0 : attribute.getValue();
    }

    private void burst(Location center, HuntAbility ability, int count, double spread) {
        center.getWorld().spawnParticle(Particle.ITEM, center, count, spread, Math.max(0.25, spread * 0.55), spread, 0.08, (Object)this.particleItem(ability));
    }

    private void animateOrbit(Player target, HuntAbility ability, int ticks) {
        BukkitTask[] task;
        int[] elapsed = new int[]{0};
        task = new BukkitTask[]{Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, () -> {
            if (!target.isOnline() || elapsed[0] >= ticks) {
                task[0].cancel();
                return;
            }
            for (int arm = 0; arm < 4; ++arm) {
                double angle = (double)elapsed[0] * 0.28 + (double)arm * Math.PI / 2.0;
                Location point = target.getLocation().add(Math.cos(angle) * 1.25, 0.25 + (double)(elapsed[0] % 20) / 10.0, Math.sin(angle) * 1.25);
                target.getWorld().spawnParticle(Particle.ITEM, point, 1, 0.0, 0.0, 0.0, 0.0, (Object)this.particleItem(ability));
            }
            elapsed[0] = elapsed[0] + 2;
        }, 0L, 2L)};
    }

    private void sendStatusBar(Player player) {
        Component status = this.statusComponent(player);
        if (!status.equals((Object)Component.empty())) {
            player.sendActionBar(status);
        }
    }

    Component statusComponent(Player player) {
        HuntAbility ability = this.assignments.get(player.getUniqueId());
        if (ability == null) {
            return Component.empty();
        }
        long primary = this.cooldownRemaining(this.primaryCooldowns, player);
        long secondary = this.cooldownRemaining(this.secondaryCooldowns, player);
        return ((TextComponent)((TextComponent)((TextComponent)((TextComponent)((TextComponent)((TextComponent)Component.empty().append(this.icon(ability))).append((Component)Component.text((String)"  "))).append(PremiumText.mini(ability.displayName().toUpperCase(), this.paletteStart(ability), this.paletteEnd(ability)))).append(PremiumText.mini("   |   P ", 5593444, 8949403))).append(this.cooldownText(primary))).append(PremiumText.mini("   |   S ", 5593444, 8949403))).append(this.cooldownText(secondary));
    }

    private Component cooldownText(long remaining) {
        return remaining <= 0L ? PremiumText.mini("READY", 12189629, 3725175) : PremiumText.mini(remaining + "s", 16756893, 14891869);
    }

    private long cooldownRemaining(Map<UUID, Long> cooldownMap, Player player) {
        long remaining = cooldownMap.getOrDefault(player.getUniqueId(), 0L) - System.currentTimeMillis();
        return remaining <= 0L ? 0L : (remaining + 999L) / 1000L;
    }

    private void showInfo(Player player) {
        HuntAbility ability = this.assignments.get(player.getUniqueId());
        if (ability == null) {
            player.sendMessage(AbilityManager.color("&6&lHUNT &8\u00bb &eYou have not rolled an ability yet."));
            return;
        }
        player.sendMessage((Component)Component.text((String)"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 HUNT ABILITY \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500", (TextColor)NamedTextColor.DARK_GRAY));
        player.sendMessage(this.abilityName(ability).append((Component)Component.text((String)("  " + ability.rarity()), (TextColor)ability.color())));
        player.sendMessage(Component.text((String)"Primary [Sneak + F]: ", (TextColor)NamedTextColor.GOLD).append((Component)Component.text((String)(ability.primaryName() + " \u2014 " + ability.primaryDescription()), (TextColor)NamedTextColor.WHITE)));
        player.sendMessage(Component.text((String)"Secondary [F]: ", (TextColor)NamedTextColor.AQUA).append((Component)Component.text((String)(ability.secondaryName() + " \u2014 " + ability.secondaryDescription()), (TextColor)NamedTextColor.WHITE)));
        player.sendMessage(Component.text((String)"Passive I: ", (TextColor)NamedTextColor.GREEN).append((Component)Component.text((String)ability.passiveOne(), (TextColor)NamedTextColor.WHITE)));
        player.sendMessage(Component.text((String)"Passive II: ", (TextColor)NamedTextColor.GREEN).append((Component)Component.text((String)ability.passiveTwo(), (TextColor)NamedTextColor.WHITE)));
        player.sendMessage((Component)Component.text((String)("Cooldowns: P " + ability.primaryCooldownSeconds() + "s  \u2022  S " + ability.secondaryCooldownSeconds() + "s"), (TextColor)NamedTextColor.GRAY));
    }

    private Component icon(HuntAbility ability) {
        return ((TextComponent)Component.text((String)ability.icon()).font(ICON_FONT)).color((TextColor)NamedTextColor.WHITE);
    }

    private Component abilityName(HuntAbility ability) {
        return ((TextComponent)((TextComponent)Component.empty().append(this.icon(ability))).append((Component)Component.text((String)"  "))).append(PremiumText.gradient(ability.displayName().toUpperCase(), this.paletteStart(ability), this.paletteEnd(ability)));
    }

    private int paletteStart(HuntAbility ability) {
        return switch (ability) {
            default -> throw new MatchException(null, null);
            case HuntAbility.BLOODLORD -> 16743796;
            case HuntAbility.CHRONOWARDEN -> 16773281;
            case HuntAbility.RIFTWALKER -> 15775999;
            case HuntAbility.SOULWEAVER -> 0x9FFFF1;
            case HuntAbility.STORMBORN -> 12974079;
            case HuntAbility.FROSTBOUND -> 12180991;
            case HuntAbility.IRONHEART -> 16769434;
            case HuntAbility.HUNTSMAN -> 12910503;
        };
    }

    private int paletteEnd(HuntAbility ability) {
        return switch (ability) {
            default -> throw new MatchException(null, null);
            case HuntAbility.BLOODLORD -> 9375788;
            case HuntAbility.CHRONOWARDEN -> 12745241;
            case HuntAbility.RIFTWALKER -> 7614665;
            case HuntAbility.SOULWEAVER -> 1473926;
            case HuntAbility.STORMBORN -> 2858206;
            case HuntAbility.FROSTBOUND -> 3232969;
            case HuntAbility.IRONHEART -> 11035168;
            case HuntAbility.HUNTSMAN -> 3246668;
        };
    }

    private ItemStack abilityItem(HuntAbility ability) {
        ItemStack item = this.particleItem(ability);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(PremiumText.mini(ability.displayName().toUpperCase() + "   |   " + ability.rarity(), this.paletteStart(ability), this.paletteEnd(ability)));
        meta.lore(List.of(PremiumText.mini("HUNT ABILITY   |   " + ability.rarity(), this.paletteStart(ability), this.paletteEnd(ability)), Component.empty(), PremiumText.mini("PRIMARY    |  " + ability.primaryName().toUpperCase(), 16769690, 12814637), PremiumText.mini(ability.primaryDescription(), 15133167, 9607590), Component.empty(), PremiumText.mini("SECONDARY  |  " + ability.secondaryName().toUpperCase(), 11138303, 3251647), PremiumText.mini(ability.secondaryDescription(), 15133167, 9607590), Component.empty(), PremiumText.mini("PASSIVE I   |  " + ability.passiveOne(), 12976055, 5022557), PremiumText.mini("PASSIVE II  |  " + ability.passiveTwo(), 12976055, 5022557), Component.empty(), PremiumText.mini("LEFT CLICK  |  ASSIGN TO PLAYER", 16773285, 12880430)));
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack particleItem(HuntAbility ability) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.setItemModel(new NamespacedKey("hunt", "ability_particle_" + ability.id()));
        item.setItemMeta(meta);
        return item;
    }

    private Particle.DustOptions trailDust(HuntAbility ability) {
        Color color = switch (ability) {
            default -> throw new MatchException(null, null);
            case HuntAbility.BLOODLORD -> Color.fromRGB((int)220, (int)28, (int)55);
            case HuntAbility.CHRONOWARDEN -> Color.fromRGB((int)255, (int)202, (int)72);
            case HuntAbility.RIFTWALKER -> Color.fromRGB((int)166, (int)72, (int)235);
            case HuntAbility.SOULWEAVER -> Color.fromRGB((int)45, (int)210, (int)190);
            case HuntAbility.STORMBORN -> Color.fromRGB((int)72, (int)205, (int)255);
            case HuntAbility.FROSTBOUND -> Color.fromRGB((int)92, (int)154, (int)255);
            case HuntAbility.IRONHEART -> Color.fromRGB((int)222, (int)150, (int)55);
            case HuntAbility.HUNTSMAN -> Color.fromRGB((int)72, (int)220, (int)104);
        };
        return new Particle.DustOptions(color, 1.05f);
    }

    private void renderLine(Player viewer, Player target, HuntAbility ability, int points) {
        Vector difference = target.getEyeLocation().toVector().subtract(viewer.getEyeLocation().toVector());
        Vector step = difference.clone().multiply(1.0 / (double)Math.max(1, points));
        Location point = viewer.getEyeLocation();
        for (int index = 0; index <= points; ++index) {
            viewer.getWorld().spawnParticle(Particle.DUST, point, 1, 0.0, 0.0, 0.0, 0.0, (Object)this.trailDust(ability));
            point.add(step);
        }
    }

    private void renderPath(Player viewer, Location start, Location end, HuntAbility ability) {
        Vector difference = end.toVector().subtract(start.toVector());
        double length = difference.length();
        if (length < 0.1) {
            return;
        }
        Vector direction = difference.normalize();
        for (double step = 0.0; step <= length; step += 0.45) {
            viewer.getWorld().spawnParticle(Particle.DUST, start.clone().add(direction.clone().multiply(step)).add(0.0, 1.0, 0.0), 1, 0.0, 0.0, 0.0, 0.0, (Object)this.trailDust(ability));
        }
    }

    private void fail(Player player, String message) {
        player.sendMessage(AbilityManager.color("&6&lHUNT &8\u00bb &c" + message));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.7f, 0.7f);
    }

    private Player resolveTarget(CommandSender sender, String name) {
        if (name != null) {
            Player target = Bukkit.getPlayerExact((String)name);
            if (target == null) {
                sender.sendMessage(AbilityManager.color("&6&lHUNT &8\u00bb &cThat player is not online."));
            }
            return target;
        }
        if (sender instanceof Player) {
            Player player = (Player)sender;
            return player;
        }
        sender.sendMessage(AbilityManager.color("&6&lHUNT &8\u00bb &cConsole must specify a player."));
        return null;
    }

    private void removeModifier(Player player, Attribute attribute, NamespacedKey key) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance != null) {
            instance.removeModifier((Key)key);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.applyPassive(event.getPlayer()), 2L);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.applyPassive(event.getPlayer()), 2L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID caster;
        UUID id = event.getPlayer().getUniqueId();
        this.finishRoll(id);
        if (this.bloodRestoreTasks.containsKey(id)) {
            this.restoreBloodTransfer(id);
        }
        if ((caster = (UUID)this.bloodTargets.entrySet().stream().filter(entry -> ((UUID)entry.getValue()).equals(id)).map(Map.Entry::getKey).findFirst().orElse(null)) != null) {
            this.restoreBloodTransfer(caster);
        }
        this.stormLandings.remove(id);
        this.huntsmanMarks.remove(id);
        this.frozenUntil.remove(id);
        this.snapshots.remove(id);
    }

    private void load() {
        this.assignments.clear();
        this.primaryCooldowns.clear();
        this.secondaryCooldowns.clear();
        if (this.data.isConfigurationSection("players")) {
            for (String idText : this.data.getConfigurationSection("players").getKeys(false)) {
                try {
                    UUID id = UUID.fromString(idText);
                    HuntAbility ability = HuntAbility.byId(this.data.getString("players." + idText + ".ability"));
                    if (ability != null) {
                        this.assignments.put(id, ability);
                    }
                    long legacyCooldown = this.data.getLong("players." + idText + ".cooldown-until", 0L);
                    long primary = this.data.getLong("players." + idText + ".primary-cooldown-until", legacyCooldown);
                    long secondary = this.data.getLong("players." + idText + ".secondary-cooldown-until", 0L);
                    if (primary > System.currentTimeMillis()) {
                        this.primaryCooldowns.put(id, primary);
                    }
                    if (secondary <= System.currentTimeMillis()) continue;
                    this.secondaryCooldowns.put(id, secondary);
                }
                catch (IllegalArgumentException ignored) {
                    this.plugin.getLogger().warning("Ignored invalid ability player UUID: " + idText);
                }
            }
        }
    }

    private void save() {
        this.data.set("players", null);
        for (Map.Entry<UUID, HuntAbility> entry : this.assignments.entrySet()) {
            String path = "players." + String.valueOf(entry.getKey());
            this.data.set(path + ".ability", (Object)entry.getValue().id());
            this.data.set(path + ".primary-cooldown-until", (Object)this.primaryCooldowns.getOrDefault(entry.getKey(), 0L));
            this.data.set(path + ".secondary-cooldown-until", (Object)this.secondaryCooldowns.getOrDefault(entry.getKey(), 0L));
        }
        try {
            this.data.save(this.file);
        }
        catch (IOException exception) {
            this.plugin.getLogger().warning("Could not save abilities.yml: " + exception.getMessage());
        }
    }

    private String legacyColor(HuntAbility ability) {
        return switch (ability) {
            default -> throw new MatchException(null, null);
            case HuntAbility.BLOODLORD -> "&4";
            case HuntAbility.CHRONOWARDEN -> "&6";
            case HuntAbility.RIFTWALKER -> "&d";
            case HuntAbility.SOULWEAVER -> "&3";
            case HuntAbility.STORMBORN -> "&b";
            case HuntAbility.FROSTBOUND -> "&9";
            case HuntAbility.IRONHEART -> "&6";
            case HuntAbility.HUNTSMAN -> "&a";
        };
    }

    private float rarityPitch(HuntAbility ability) {
        return switch (ability) {
            default -> throw new MatchException(null, null);
            case HuntAbility.BLOODLORD -> 0.62f;
            case HuntAbility.CHRONOWARDEN -> 0.68f;
            case HuntAbility.RIFTWALKER -> 0.78f;
            case HuntAbility.SOULWEAVER -> 0.86f;
            case HuntAbility.STORMBORN -> 0.95f;
            case HuntAbility.FROSTBOUND -> 1.03f;
            case HuntAbility.IRONHEART -> 1.12f;
            case HuntAbility.HUNTSMAN -> 1.32f;
        };
    }

    private ItemStack menuItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(PremiumText.menuTitle(name));
        meta.lore(lore.stream().map(PremiumText::menuLore).toList());
        item.setItemMeta(meta);
        return item;
    }

    private static String color(String text) {
        return PremiumText.legacyStyled(text);
    }

    private static boolean isAbilityRoot(String value) {
        return value.equalsIgnoreCase("ability") || value.equalsIgnoreCase("abiliy");
    }

    private static final class AbilityHolder
    implements InventoryHolder {
        private final UUID target;
        private final Map<Integer, HuntAbility> abilities = new HashMap<Integer, HuntAbility>();
        private Inventory inventory;

        private AbilityHolder(UUID target) {
            this.target = target;
        }

        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private record PlayerSnapshot(Location location, double health, long time) {
    }
}

