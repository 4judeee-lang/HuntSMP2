/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntsmp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public final class FeaturePatch
implements Listener {
    private static final long DOUBLE_CLICK_WINDOW_MS = 425L;
    private static final long STUN_DURATION_MS = 2000L;
    private static final long SHIELD_COOLDOWN_MS = 8000L;
    private static final double TARGET_RANGE_SQUARED = 36.0;
    private static final double MIN_AIM_DOT = 0.76;
    private final Map<UUID, Long> lastShieldClick = new HashMap<UUID, Long>();
    private final Map<UUID, Long> shieldCooldownEnds = new HashMap<UUID, Long>();
    private final Map<UUID, Long> stunnedUntil = new HashMap<UUID, Long>();

    private FeaturePatch() {
    }

    public static void register(Plugin plugin) {
        Bukkit.getPluginManager().registerEvents((Listener)new FeaturePatch(), plugin);
    }

    public static void altarForged(Player player, String string) {
        String string2 = string == null ? "RELIC" : string.toUpperCase();
        Bukkit.broadcastMessage((String)("\u00a78[\u00a7c\u00a7lHUNT\u00a78] \u00a7f" + player.getName() + " \u00a77has forged \u00a7c\u00a7l" + string2 + "\u00a77."));
        for (Player player2 : Bukkit.getOnlinePlayers()) {
            player2.sendTitle("\u00a7f\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588", "\u00a7f\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588", 0, 2, 6);
            player2.playSound(player2.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.85f, 1.9f);
            player2.playSound(player2.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 0.65f, 1.55f);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=false)
    public void onShieldClick(PlayerInteractEvent playerInteractEvent) {
        Player player = playerInteractEvent.getPlayer();
        Long l = this.stunnedUntil.get(player.getUniqueId());
        if (l != null && l > System.currentTimeMillis()) {
            playerInteractEvent.setCancelled(true);
            return;
        }
        if (!playerInteractEvent.getAction().isRightClick()) {
            return;
        }
        ItemStack itemStack = playerInteractEvent.getItem();
        if (itemStack == null || itemStack.getType() != Material.SHIELD) {
            return;
        }
        long l2 = System.currentTimeMillis();
        UUID uUID = player.getUniqueId();
        long l3 = this.lastShieldClick.getOrDefault(uUID, 0L);
        this.lastShieldClick.put(uUID, l2);
        if (l2 - l3 > 425L) {
            return;
        }
        long l4 = this.shieldCooldownEnds.getOrDefault(uUID, 0L);
        if (l4 > l2) {
            double d = (double)(l4 - l2) / 1000.0;
            player.sendMessage("\u00a78[\u00a7bShield Stun\u00a78] \u00a77Ready in \u00a7f" + String.format("%.1f", d) + "s\u00a77.");
            return;
        }
        Player player2 = this.findTarget(player);
        if (player2 == null) {
            player.sendMessage("\u00a78[\u00a7bShield Stun\u00a78] \u00a77No player in front of you.");
            return;
        }
        playerInteractEvent.setCancelled(true);
        this.lastShieldClick.remove(uUID);
        this.shieldCooldownEnds.put(uUID, l2 + 8000L);
        this.stunnedUntil.put(player2.getUniqueId(), l2 + 2000L);
        player.setCooldown(Material.SHIELD, 160);
        player2.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 10, false, false, false));
        player.playSound(player.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1.0f, 0.75f);
        player2.playSound(player2.getLocation(), Sound.ENTITY_ZOMBIE_ATTACK_IRON_DOOR, 0.9f, 1.35f);
        player2.playSound(player2.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.55f, 1.8f);
        player.sendTitle("\u00a7b\u00a7lSHIELD STUN", "\u00a7f" + player2.getName() + " \u00a78| \u00a7b2.0s", 0, 10, 6);
        player2.sendTitle("\u00a7c\u00a7lSTUNNED", "\u00a77Shield Bash \u00a78| \u00a7f2.0s", 0, 30, 8);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=false)
    public void onStunnedMove(PlayerMoveEvent playerMoveEvent) {
        Long l = this.stunnedUntil.get(playerMoveEvent.getPlayer().getUniqueId());
        if (l == null) {
            return;
        }
        if (l <= System.currentTimeMillis()) {
            this.stunnedUntil.remove(playerMoveEvent.getPlayer().getUniqueId());
            return;
        }
        if (playerMoveEvent.getTo() != null && playerMoveEvent.getFrom().distanceSquared(playerMoveEvent.getTo()) > 1.0E-6) {
            playerMoveEvent.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=false)
    public void onStunnedAttack(EntityDamageByEntityEvent entityDamageByEntityEvent) {
        Object object = entityDamageByEntityEvent.getDamager();
        if (!(object instanceof Player)) {
            return;
        }
        Player player = (Player)object;
        object = this.stunnedUntil.get(player.getUniqueId());
        if (object != null && (Long)object > System.currentTimeMillis()) {
            entityDamageByEntityEvent.setCancelled(true);
        }
    }

    private Player findTarget(Player player) {
        Location location = player.getEyeLocation();
        Vector vector = location.getDirection().normalize();
        Player player2 = null;
        double d = 0.76;
        List list = player.getNearbyEntities(6.0, 4.0, 6.0);
        for (Entity entity : list) {
            double d2;
            Vector vector2;
            Player player3;
            if (!(entity instanceof Player) || !(player3 = (Player)entity).isOnline() || player3.isDead() || !player.hasLineOfSight((Entity)player3) || location.distanceSquared(player3.getEyeLocation()) > 36.0 || (vector2 = player3.getEyeLocation().toVector().subtract(location.toVector())).lengthSquared() < 1.0E-4 || !((d2 = vector.dot(vector2.normalize())) > d)) continue;
            d = d2;
            player2 = player3;
        }
        return player2;
    }
}

