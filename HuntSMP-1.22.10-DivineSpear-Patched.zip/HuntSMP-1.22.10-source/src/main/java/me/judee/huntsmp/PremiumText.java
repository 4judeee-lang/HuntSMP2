/*
 * Decompiled with CFR 0.152.
 */
package me.judee.huntsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.ChatColor;

final class PremiumText {
    private PremiumText() {
    }

    static Component mini(String text, int startRgb, int endRgb) {
        return PremiumText.gradient(text, startRgb, endRgb, false);
    }

    static Component gradient(String text, int startRgb, int endRgb) {
        return PremiumText.gradient(text, startRgb, endRgb, false);
    }

    private static Component gradient(String text, int startRgb, int endRgb, boolean mini) {
        if (text == null || text.isEmpty()) {
            return Component.empty();
        }
        int[] points = text.codePoints().toArray();
        TextComponent result = Component.empty();
        for (int index = 0; index < points.length; ++index) {
            double progress = points.length == 1 ? 0.0 : (double)index / (double)(points.length - 1);
            int color = PremiumText.interpolate(startRgb, endRgb, progress);
            Component glyph = Component.text((String)new String(Character.toChars(points[index]))).color(TextColor.color((int)color));
            result = result.append(glyph);
        }
        return result.decoration(TextDecoration.ITALIC, false);
    }

    static Component menuTitle(String legacy) {
        String text = PremiumText.cleanLegacy(legacy).toUpperCase();
        if (text.isBlank()) {
            return Component.empty();
        }
        int[] palette = PremiumText.legacyPalette(legacy);
        return PremiumText.mini(text, palette[0], palette[1]);
    }

    static Component menuLore(String legacy) {
        String text = PremiumText.cleanLegacy(legacy);
        if (text.isBlank()) {
            return Component.empty();
        }
        return PremiumText.mini(text, 15133168, 9410213);
    }

    static String legacyStyled(String legacy) {
        String text = PremiumText.cleanLegacy(legacy);
        if (text.isBlank()) {
            return "";
        }
        int[] palette = PremiumText.legacyPalette(legacy);
        return PremiumText.legacy(text, palette[0], palette[1]);
    }

    private static String cleanLegacy(String legacy) {
        String translated = ChatColor.translateAlternateColorCodes((char)'&', (String)(legacy == null ? "" : legacy));
        String stripped = ChatColor.stripColor((String)translated);
        return stripped == null ? "" : stripped.replace("\u2022", "|").replace("\u2014", "-").replace("\u2013", "-").replace("\u00d7", "x");
    }

    private static int[] legacyPalette(String legacy) {
        String value;
        String string = value = legacy == null ? "" : legacy.toLowerCase();
        if (value.contains("&c") || value.contains("&4")) {
            return new int[]{0xFF9A9A, 13120083};
        }
        if (value.contains("&d") || value.contains("&5")) {
            return new int[]{15906815, 7877552};
        }
        if (value.contains("&b") || value.contains("&3")) {
            return new int[]{12056831, 2858951};
        }
        if (value.contains("&a") || value.contains("&2")) {
            return new int[]{13041586, 3908699};
        }
        if (value.contains("&6") || value.contains("&e")) {
            return new int[]{0xFFF0AA, 12946216};
        }
        return new int[]{16316924, 10265522};
    }

    static String legacy(String text, int startRgb, int endRgb) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        int[] points = text.codePoints().toArray();
        StringBuilder result = new StringBuilder(points.length * 15);
        for (int index = 0; index < points.length; ++index) {
            double progress = points.length == 1 ? 0.0 : (double)index / (double)(points.length - 1);
            String hex = String.format("%06X", PremiumText.interpolate(startRgb, endRgb, progress));
            result.append('\u00a7').append('x');
            for (char digit : hex.toCharArray()) {
                result.append('\u00a7').append(digit);
            }
            result.appendCodePoint(points[index]);
        }
        return result.toString();
    }

    static String legacyMini(String text, int startRgb, int endRgb) {
        return PremiumText.legacy(text, startRgb, endRgb);
    }

    private static int interpolate(int start, int end, double progress) {
        int red = PremiumText.mix(start >> 16 & 0xFF, end >> 16 & 0xFF, progress);
        int green = PremiumText.mix(start >> 8 & 0xFF, end >> 8 & 0xFF, progress);
        int blue = PremiumText.mix(start & 0xFF, end & 0xFF, progress);
        return red << 16 | green << 8 | blue;
    }

    private static int mix(int start, int end, double progress) {
        return (int)Math.round((double)start + (double)(end - start) * progress);
    }
}

