# Divine Spear — audit fixes

Source status unchanged from `reference/SOURCE_STATUS.txt`: most of this project is
CFR-decompiled and cleaned up, not original source pulled from a repo. Treat these
patches as reviewed-but-untested until you've built and played with them.

## 1. Stun-lock fix (`DivineSpearFeature.java`)

**Bug:** `onSpearHit` re-rolled the 60% stun chance on every hit, including hits
against a victim who was already stunned. Since a stunned victim is easy to keep
hitting, a lucky early stun could be continuously refreshed — a permanent lock with
no counterplay for the victim.

**Fix:** Added `stunImmuneUntil`, a 1-second grace window granted the moment a stun
ends (via a new `clearStun` helper used by both the lazy `isStunned` expiry check and
the tick-based cleanup). `onSpearHit` now treats an already-stunned or still-immune
victim the same as a missed roll — sparks only, no re-application.

**What to test:** land a stun, keep meleeing the victim for the full 3s + a bit
longer, confirm they aren't stun-locked past the original 3 seconds and get a real
window to respond once immunity ends.

## 2. Saturation-free lunge fix

**Bug:** The passive only clamped saturation from dropping *below whatever it
already was* at lunge time. If saturation was already near 0 (common — it's usually
the first stat to burn down), vanilla exhaustion drains food level instead once
saturation is exhausted, so the lunge silently still cost the player food.

**Fix:** Added `foodLevelFloor`, recorded alongside `saturationFloor` at lunge time
and enforced for the same 1.5s protection window in `tick()`.

**What to test:** drop your saturation near 0 (sprint around, don't eat), then lunge
repeatedly and confirm food level doesn't drop during the protection window.

## Not changed, flagged for awareness

- `managedFlight` bookkeeping in `onDoubleJump` briefly desyncs from the actual
  `allowFlight` state in the "already used" and "on cooldown" branches (it doesn't
  call `managedFlight.remove(id)` there). It self-heals on the next tick and isn't a
  gameplay bug, but if you build anything else on top of `managedFlight`, know it's
  not always accurate mid-flight-toggle.
- Granting `player.setAllowFlight(true)` to survival players (even briefly, even
  managed) can trip some anti-cheat plugins (NoCheatPlus and similar) into flagging
  fly-hacks on servers that don't allowlist this pattern. Worth checking your
  anti-cheat config if players start getting false-flagged.
