# HuntSMP 1.22.10 — Recovered Source

This project was recovered from the exact compiled file:

`HuntSMP-1.22.10-DivineSpear-Altar.jar`

## Source status

- `DivineSpearFeature.java` is the exact pre-compilation source used for the Divine Spear feature.
- `DivineSpearHuntCommand.java` is the exact pre-compilation source used for the 1.22.10 `/hunt altar spear` command bridge.
- The remaining Java files were decompiled from the exact 1.22.10 class files with CFR 0.152.
- Original comments, formatting, local-variable names, and some generic type information cannot always be recovered from bytecode.
- The exact compiled JAR, its SHA-256, complete file inventory, and `javap` bytecode listings are included under `original/` and `reference/`.

## Layout

- `src/main/java/` — recovered Java source
- `src/main/resources/` — exact `plugin.yml`, `config.yml`, and embedded resource-pack files
- `original/` — exact 1.22.10 JAR
- `reference/bytecode/` — disassembly for every class, including inner classes
- `pom.xml` — reconstructed Java 21 Maven build definition

## Build

```bash
mvn clean package
```

The reconstructed Maven file targets Paper 1.21.11 and ProtocolLib 5.4.0. Because most of the project was recovered from bytecode rather than the original repository, some decompiler cleanup may be required before a clean rebuild. The original 1.22.10 JAR is included for comparison.

## Original plugin metadata

- Main class: `me.judee.huntsmp.IntegratedHuntPlugin`
- Version: `1.22.10`
- Author: `4judee`
- Soft dependency: `ProtocolLib`
