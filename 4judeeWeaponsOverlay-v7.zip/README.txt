4judee HuntSMP weapon overlay v7

This is an overlay, not a replacement for the full HuntSMP pack.
It changes only:
- hunt:crimson_blade -> Valhakyra
- hunt:lightning_bolt -> Phantomguard Partisan
- hunt:drill_pickaxe -> Talonpick

All other HuntSMP textures remain supplied by the original full pack.
